package bici.tipo;

import static bici.gui.LettoreImmagini.leggiImmagineBici;

import java.awt.Image;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import bici.sim.Coordinate;
import bici.sim.GeneratoreCasuale;
import bici.sim.Zona;

public class Gialla extends AbstractBici{
	private GeneratoreCasuale gen;
	 private List<Coordinate> pos;
	static private int progId=0;
	private Random g;
	static final private Image IMMAGINE_BICI_Gialla = leggiImmagineBici(java.awt.Color.yellow);
	public Gialla(Zona zona) {
		super(zona,IMMAGINE_BICI_Gialla,progId++);
		this.gen= new GeneratoreCasuale();
		this.pos= gen.generaNposizioniGialla(4);
		
		this. g= new Random();
	}

	
	public static int getProgId() {
		return progId;
	}


	public static void setProgId(int progId) {
		Gialla.progId = progId;
	}


	@Override
	public Coordinate decidiProssimaDestinazione() {
		
		
		int val= g.nextInt(4);//* genero numero casuale da 0 a 3
		
		return this.pos.get(val);
	}


	public List<Coordinate> getPos() {
		return pos;
	}


	public void setPos(List<Coordinate> pos) {
		this.pos = pos;
	}

}
