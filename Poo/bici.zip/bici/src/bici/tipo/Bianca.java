package bici.tipo;

import static bici.gui.LettoreImmagini.leggiImmagineBici;
import static bici.sim.GeneratoreCasuale.posizioneCasuale;

import java.awt.Image;
import java.util.Set;

import bici.sim.Coordinate;
import bici.sim.Direzione;
import bici.sim.Percorso;
import bici.sim.Zona;

/**
 * Modella le fasi del ciclo di vista di una bicicletta {@link Bianca}.
 * <B>(VEDI DOMANDA 2)</B>
 */
public class Bianca extends AbstractBici{
	
	static final private Image IMMAGINE_BICI_BIANCA = leggiImmagineBici(java.awt.Color.WHITE);

static private int progId =0;
	public Bianca(Zona zona) {		
	
		super(zona,IMMAGINE_BICI_BIANCA,progId++);
	}

	
	


	public static int getProgId() {
		return progId;
	}





	public static void setProgId(int progId) {
		Bianca.progId = progId;
	}





	@Override
	public Coordinate decidiProssimaDestinazione() {
		return posizioneCasuale();
	}

	

	


}
