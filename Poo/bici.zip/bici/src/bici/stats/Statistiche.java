package bici.stats;

import java.util.*;

import bici.sim.Coordinate;
import bici.sim.Percorso;
import bici.sim.Zona;
import bici.tipo.AbstractBici;
import bici.tipo.Bianca;

public class Statistiche {

	synchronized public void stampaFinale(Zona zona) {
		final Set<Percorso> percorsi = zona.getPercorsi();

		System.out.println(percorsi.size() + " percorsi collezionati." );
		System.out.println(zona.getPercorsi());
		System.out.println();

		// (VEDI DOMANDA 3)
		System.out.println("Percorsi di ciascuna bicicletta:");
		final Map<AbstractBici,List<Percorso>> bici2percorsi = percorsiPerBici(percorsi);
		stampaPercorsiPerBici(bici2percorsi);
		System.out.println();

		// (VEDI DOMANDA 4)
		System.out.println("Classifica finale delle posizioni piu' battute:");
		final SortedMap<Coordinate,Integer> pos2utilizzi = utilizzi(bici2percorsi);
		stampaUtilizzi(pos2utilizzi);
		System.out.println();
	}

	/**
	 * <B>DA COMPLETARE (VEDI DOMANDA 3)</B>
	 * @param percorsi - insieme dei percorsi collezionati durante la simulazione
	 * @return una mappa che riporti per ogni bici (di qualsiasi tipo)
	 *         la lista dei percorsi coperti
	 */
	public Map<AbstractBici, List<Percorso>> percorsiPerBici(Set<Percorso> percorsi) {
		Map<AbstractBici, List<Percorso>>pb=new HashMap<>();
		for(Percorso p: percorsi) {
			if(!pb.containsKey(p.getBici())) {
				 ArrayList<Percorso>c = new ArrayList<>();
				 c.add(p);
						 pb.put(p.getBici(),c );
			}
			else {
				 List<Percorso>c = new ArrayList<>();
				 c=pb.get(p.getBici());
				 c.add(p);
				pb.put(p.getBici(), c);
			}
		}
		return pb;
	}

	/**
	 * <EM>N.B. UTILE PER STAMPARE RISULTATI DOMANDA 3</EM>
	 * @param bici2percorsi
	 */
	private void stampaPercorsiPerBici(final Map<AbstractBici, List<Percorso>> bici2percorsi) {
		for(AbstractBici bici : bici2percorsi.keySet()) {
			List<Percorso> percorsi = bici2percorsi.get(bici);
			System.out.println("La bicicletta "+bici+" ha coperto "+( percorsi!=null ? percorsi.size() : 0 ) +" corse");
		}
	}
	
	/**
	 * <B>DA COMPLETARE (VEDI DOMANDA 4)</B>
	 * 	@param bici2percorsi - insiemi dei percorsi collezionati durante la simulazione
	 *                         e raggruppati per bici
	 * @return una mappa ordinata decrescente in cui figurano come chiavi 
	 *         le posizioni piu' battute come origine o destinazione di un 
	 *         percorso, come valori il numero di tali percorsi
	 */
	public SortedMap<Coordinate,Integer> utilizzi(Map<AbstractBici, List<Percorso>> bici2percorsi) {
		class ComparatorePercorsi implements Comparator<Coordinate>{

//		
			@Override
			public int compare(Coordinate o1, Coordinate o2) {
				
				if(o1.getX()-o2.getX()==0) {
					return o1.getY()-o2.getY();
				}
				else
				return o1.getX()-o2.getX();
			}
		}
			SortedMap<Coordinate,Integer> u =new TreeMap<Coordinate,Integer>(new ComparatorePercorsi());
			for(AbstractBici b: bici2percorsi.keySet()) {
				for(Percorso p: bici2percorsi.get(b)) {
					Coordinate origine= p.getOrigine();
					Coordinate destinazione= p.getDestinazione();
					if(!u.containsKey(origine)) {
						u.put(origine, 1);
					}
					if(!u.containsKey(destinazione)) {
						u.put(destinazione, 1);
					}
					 if(u.containsKey(origine)){
						int val=u.get(origine)+1;
						u.put(origine, val);
					}
					 if(u.containsKey(destinazione)){
							int val=u.get(destinazione)+1;
							u.put(destinazione, val);
						}
				}
		}
			class ComparatoreQuantita implements Comparator<Coordinate>{
				private SortedMap<Coordinate,Integer> u3;
				public ComparatoreQuantita(SortedMap<Coordinate, Integer> u2) {
					this. u3=u2; 
				}
				@Override
				public int compare(Coordinate o1, Coordinate o2) {
					Integer v1=u3.get(o1);
					Integer v2=u3.get(o2);
					if(v1-v2==0) {
						return 1;
					}
					else 
					return v1-v2;
			
					
				}
			}
			SortedMap<Coordinate,Integer> finale =new TreeMap<Coordinate,Integer>(new ComparatoreQuantita(u));
		finale.putAll(u);
			return finale;
	}
	
	/**
	 * <EM>N.B. UTILE PER STAMPARE RISULTATI DOMANDA 4</EM>
	 * @param classifica delle posizioni piu' usate
	 */
	private void stampaUtilizzi(SortedMap<Coordinate,Integer> classifica) {
		int i = 0;
		for(Map.Entry<Coordinate, Integer> entry : classifica.entrySet()) {
			final Coordinate posizione = entry.getKey();
			final Integer numeri = entry.getValue();
			System.out.println(i+") "+posizione+" con "+numeri+" utilizzi");
			i++;
		}
	}

}
