package car.stats;

public interface CalcolatoreMax {

	public int max(int[][] m);

}
