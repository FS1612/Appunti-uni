package car.auto;

import java.awt.Image;
import java.util.Objects;
import java.util.Set;

import car.sim.Coordinate;
import car.sim.Direzione;
import car.sim.Tragitto;
import car.sim.Zona;
import static car.sim.GeneratoreCasuale.posizioneCasuale;
public abstract class Auto {
private Image img;
	public Image getImg() {
	return img;
}
public void setImg(Image img) {
	this.img = img;
}
	private int id;

	private Zona zona;

	private Coordinate posizione; // posizione corrente

	private Direzione direzione;  // direzione corrente

	private Coordinate origine;
	
	private Coordinate destinazione;
	public int getId() {
		return id;
	}
	public Zona getZona() {
		return zona;
	}
	public Coordinate getPosizione() {
		return posizione;
	}
	public Direzione getDirezione() {
		return direzione;
	}
	public Coordinate getOrigine() {
		return origine;
	}
	public Coordinate getDestinazione() {
		return destinazione;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setZona(Zona zona) {
		this.zona = zona;
	}
	public void setPosizione(Coordinate posizione) {
		this.posizione = posizione;
	}
	public void setDirezione(Direzione direzione) {
		this.direzione = direzione;
	}
	public void setOrigine(Coordinate origine) {
		this.origine = origine;
	}
	public void setDestinazione(Coordinate destinazione) {
		this.destinazione = destinazione;
	}
	private boolean destinazioneRaggiunta() {
		return this.getPosizione().equals(this.destinazione);
	}
	private void direzionaVerso(Coordinate dest) {
		final Direzione verso = Direzione.verso(this.getPosizione(),dest);
		final Set<Direzione> possibili = getPossibiliDirezioni();
		if (possibili.contains(verso)) 
			this.setDirezione(verso);
		else this.setDirezione(Direzione.scegliAcasoTra(possibili));
	}
	private void eseguiSpostamento() {
		this.setPosizione(this.getPosizione().trasla(this.getDirezione()));
	}
	private Set<Direzione> getPossibiliDirezioni() {
		return this.getZona().getPossibiliDirezioni(this.getPosizione());
	}
	@Override
	public int hashCode() {
		return this.getId();
	}

	@Override
	public boolean equals(Object o) {
		final Auto that = (Auto)o;
		return Objects.equals(this.getId(), that.getId());
	}
	@Override
	public String toString() {
		return getClass().getSimpleName()+getId();
	}

	public void simula(int passo) {
		/* destinazione iniziale gia' fissata? */
		if (getDestinazione()==null) {
			setDestinazione(decidiProssimaDestinazione());
		} else if (destinazioneRaggiunta()) {
			/* tieni traccia del tragitto percorso */
			final Tragitto tragitto = new Tragitto(this,getOrigine(),getDestinazione());
			this.getZona().add(tragitto);
			setOrigine(getDestinazione());
			setDestinazione(decidiProssimaDestinazione());
		}
		direzionaVerso(this.destinazione);
		eseguiSpostamento();
	}
	protected abstract Coordinate decidiProssimaDestinazione();
	public Auto(Zona zona,int id,Image img) {
		final Coordinate posizioneIniziale = posizioneCasuale();
		this.posizione = posizioneIniziale;
		this.origine = posizioneIniziale;
		this.destinazione = null;
		this.direzione = null;
		this.setZona(zona);
		this.setId(id);
		this.setImg(img);
	}

}
