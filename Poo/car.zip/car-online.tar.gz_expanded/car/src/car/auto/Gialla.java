package car.auto;

import static car.gui.LettoreImmagini.leggiImmagineVettura;

import java.awt.Image;
import java.util.List;
import java.util.Random;

import car.sim.Coordinate;
import car.sim.GeneratoreCasuale;
import car.sim.Zona;

public class Gialla extends Auto {
	private List<Coordinate> pos;
	private Random r;
	private GeneratoreCasuale gc;
	static final private Image IMMAGINE_VETTURA_Gialla = leggiImmagineVettura(java.awt.Color.yellow);

private static int id=0;

	public Gialla(Zona zona) {
		super(zona, id++, IMMAGINE_VETTURA_Gialla);
		gc=new GeneratoreCasuale();
		this.pos=gc.generaNposizioniCasualiGialla(10);
		this.r=new Random();
	}

	@Override
	protected Coordinate decidiProssimaDestinazione() {
		int val =r.nextInt(10);
		return this.pos.get(val);
	}

}
