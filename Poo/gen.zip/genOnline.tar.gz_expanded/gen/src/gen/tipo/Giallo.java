package gen.tipo;

import static gen.gui.CostantiGUI.RISORSA_IMMAGINE_GIALLO;
import static gen.gui.LettoreImmagini.leggiImmagineOggetto;
import static gen.sim.GeneratoreCasuale.generaNumeroSinoA;

import java.awt.Image;
import java.util.LinkedList;
import java.util.List;


import gen.sim.Ambiente;

import gen.sim.Direzione;

public class Giallo extends Animale{

	static final private Image IMMAGINE_GIALLA = leggiImmagineOggetto(RISORSA_IMMAGINE_GIALLO);

	static private int progId;

	private Animale obiettivo;    // per un incontro (ora VEDI domanda 2a) od un incontro (poi, VEDI domanda 2bcd)
	
	
	
	public Giallo(Ambiente ambiente) {		
		super(ambiente,progId++, IMMAGINE_GIALLA);
	}
	
	
	public void simula(int passo) {
		int anno=super.getEta();
		super.setEta(anno+1);

		/* target gia' deciso? */
		if (this.getObiettivo()==null || isObiettivoRaggiunto()) {
			this.setObiettivo(decidiProssimoObiettivo());
		}
		
		final Direzione versoObiettivo = direzionaVerso(this.getObiettivo().getPosizione());
		this.setDirezione(versoObiettivo);
		
		this.setPosizione(super.calcolaNuovaPosizione());
	}
	
	
	protected Animale decidiProssimoObiettivo() {
		/* scegli un obiettivo casualmente */
		// Sugg.: al momento sono tutti della stessa specie, ma dopo DOMANDA 2bcd e' ancora vero? */
		final List<Animale> all = this.getAmbiente().getAllAnimali();
		final List<Animale> DiversoTipo = new LinkedList<>();
		for(Animale a :all) {
			if(!a.getClass().equals(this.getClass())) {
				
				DiversoTipo.add(a);
			}
		}
		if(!DiversoTipo.isEmpty())
			return DiversoTipo.get(generaNumeroSinoA(DiversoTipo.size()));
		else
		return this;
	}
	
	
	

	@Override
	public Giallo creaClone() {
		return new Giallo(this.getAmbiente());
		
	}


	public Animale getObiettivo() {
		return obiettivo;
	}


	public void setObiettivo(Animale obiettivo) {
		this.obiettivo = obiettivo;
	}


	@Override
	public boolean isObiettivoRaggiunto() {
		return this.getPosizione().equals(this.getObiettivo().getPosizione());
		
	}


}
