package gen.tipo;

import static gen.gui.CostantiGUI.RISORSA_IMMAGINE_VERDE;
import static gen.gui.LettoreImmagini.leggiImmagineOggetto;
import static gen.sim.GeneratoreCasuale.generaNumeroSinoA;
import static gen.sim.CostantiSimulazione.MIN_ETA_RIPRODUZIONE;
import java.awt.Image;
import java.util.LinkedList;
import java.util.List;

import gen.sim.Ambiente;
import gen.sim.Direzione;

public class Verde extends Animale {
	static private int progId=0;
	private Animale obiettivo;
	static final private Image img = leggiImmagineOggetto(RISORSA_IMMAGINE_VERDE);
	public Verde(Ambiente ambiente) {
		super(ambiente, progId++, img);
		
	}

	@Override
	public Verde creaClone() {
		return new Verde(this.getAmbiente());
	
	}

	@Override
	public void simula(int passo) {
		int anno=super.getEta();
		super.setEta(anno+1);

		/* target gia' deciso? */
		if (this.getObiettivo()==null || isObiettivoRaggiunto()) {
			this.setObiettivo(decidiProssimoObiettivo());
		}
		
		final Direzione versoObiettivo = direzionaVerso(this.getObiettivo().getPosizione());
		this.setDirezione(versoObiettivo);
		
		this.setPosizione(super.calcolaNuovaPosizione());
	}

	@Override
	protected Animale decidiProssimoObiettivo() {
		if(super.getEta()<=MIN_ETA_RIPRODUZIONE) 
			return decidiProssimoObiettivoGiallo();
		return decidiProssimoObiettivoBianco();
		
	}
	protected Animale decidiProssimoObiettivoGiallo() {
		final List<Animale> all = this.getAmbiente().getAllAnimali();
		final List<Animale> DiversoTipo = new LinkedList<>();
		for(Animale a :all) {
			if(!a.getClass().equals(this.getClass())) {
				
				DiversoTipo.add(a);
			}
		}
		if(!DiversoTipo.isEmpty())
			return DiversoTipo.get(generaNumeroSinoA(DiversoTipo.size()));
			return this;
	}
	protected Animale decidiProssimoObiettivoBianco() {
		final List<Animale> all = this.getAmbiente().getAllAnimali();
		final List<Animale> StessoTipo = new LinkedList<>();
		for(Animale a :all) {
			if(a.getClass().equals(Bianco.class)) {
				
				StessoTipo.add(a);
			}
		}
		if(StessoTipo.isEmpty())
			return StessoTipo.get(generaNumeroSinoA(StessoTipo.size()));
		else
		return this;
		
		
	}
	@Override
	public boolean isObiettivoRaggiunto() {
		return this.getPosizione().equals(this.getObiettivo().getPosizione());
		
	}
	public Animale getObiettivo() {
		return obiettivo;
	}


	public void setObiettivo(Animale obiettivo) {
		this.obiettivo = obiettivo;
	}
}
