package gen.tipo;

import static gen.sim.GeneratoreCasuale.posizioneCasuale;

import java.awt.Image;
import java.util.Set;

import gen.sim.Ambiente;
import gen.sim.Coordinate;
import gen.sim.Direzione;
import gen.sim.Genere;

public abstract class Animale {
	private Ambiente ambiente;

	private Coordinate posizione; // posizione corrente

	private Direzione direzione;  // direzione corrente
	
	
		
	private Genere genere;
	
	private int eta;
	
	private int id = 0;
	private  Image img ;
	public Animale(Ambiente ambiente,int id,Image img) {		
		this.ambiente = ambiente;
		this.posizione = posizioneCasuale();
		this.eta = 0;
		
		this.direzione = null;
		this.id = id;
		this.genere = Genere.casuale();
		this.img=img;
	}
	
	public Ambiente getAmbiente() {
		return this.ambiente;
	}

	public void setPosizione(Coordinate nuova) {
		this.posizione = nuova;
	}

	public Coordinate getPosizione() {
		return this.posizione;
	}

	public Direzione getDirezione() {
		return this.direzione;
	}

	public void setDirezione(Direzione nuova) {
		this.direzione = nuova;
	}

	
	
	public int getEta() {
		return this.eta;
	}
	
	public Genere getGenere() {
		return this.genere;
	}
	public abstract Animale creaClone() ;
	public abstract boolean isObiettivoRaggiunto();

	public Coordinate calcolaNuovaPosizione() {
		return (this.getPosizione().trasla(this.getDirezione()));
	}

	public Set<Direzione> getPossibiliDirezioni() {
		return this.getAmbiente().getPossibiliDirezioni(this.getPosizione());
	}

	public Image getImmagine() {
		return img;
	}
	
	/**
	 * <B>DA CORREGGERE (VEDI DOMANDA 2)</B> 
	 * @return un id progressivo (per tipologia) associato a
	 *         questo oggetto
	 */
	public int getId() {
		return this.id;
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName()+getId() + ":"+getGenere().name().charAt(0)+" "+getEta();
	}

	public void setEta(int eta) {
		this.eta = eta;
	}
	public abstract void simula(int passo);
	protected abstract Animale decidiProssimoObiettivo();
	protected  Direzione direzionaVerso(Coordinate dest) {
		final Direzione verso = Direzione.verso(this.getPosizione(),dest);
		final Set<Direzione> possibili = this.getPossibiliDirezioni();
		if (possibili.contains(verso)) 
			return verso;
		else return Direzione.scegliAcasoTra(possibili);
	}
	
}
