package gen.tipo;

import static gen.gui.CostantiGUI.RISORSA_IMMAGINE_ROSSO;
import static gen.gui.LettoreImmagini.leggiImmagineOggetto;
import static gen.sim.GeneratoreCasuale.generaNumeroSinoA;

import java.awt.Image;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import gen.sim.Ambiente;
import gen.sim.Coordinate;
import gen.sim.Direzione;

public class Rosso extends Animale {
	static final private Image img = leggiImmagineOggetto(RISORSA_IMMAGINE_ROSSO);

	static private int progId;

	private Animale obiettivo;
	public Rosso(Ambiente ambiente) {
		super(ambiente, progId++, img);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Animale creaClone() {
		return new Rosso(this.getAmbiente());
	}

	@Override
	public boolean isObiettivoRaggiunto() {
		return this.getPosizione().equals(this.getObiettivo().getPosizione());
	}

	@Override
	public void simula(int passo) {
		int anno=super.getEta();
		super.setEta(anno+1);

		/* target gia' deciso? */
		if (this.getObiettivo()==null || isObiettivoRaggiunto()) {
			this.setObiettivo(decidiProssimoObiettivo());
		}
		
		final Direzione versoObiettivo = direzionaVerso(this.getObiettivo().getPosizione());
		this.setDirezione(versoObiettivo);
		
		this.setPosizione(super.calcolaNuovaPosizione());
	}

	@Override
	protected Animale decidiProssimoObiettivo() {
		final List<Animale> all = this.getAmbiente().getAllAnimali();
		final List<Animale> TipoDiverso = new LinkedList<>();
		for(Animale a: all) {
			if(!a.getClass().equals(Rosso.class)) {
				TipoDiverso.add(a);
			}
		}
		final Coordinate attuali=super.getPosizione();
		Collections.sort(TipoDiverso, new Comparator<Animale>() {

			@Override
			public int compare(Animale o1, Animale o2) {
				Coordinate co1=o1.getPosizione();
				Coordinate co2=o2.getPosizione();
				return (int) (Coordinate.distanza(co2, attuali)-Coordinate.distanza(co1, attuali));
			}
			
		});
		if(!TipoDiverso.isEmpty())
			return TipoDiverso.get(0);
			return this;
		
	}

	public Animale getObiettivo() {
		return obiettivo;
	}

	public void setObiettivo(Animale obiettivo) {
		this.obiettivo = obiettivo;
	}

}
