package gen.tipo;


import static gen.gui.CostantiGUI.RISORSA_IMMAGINE_BIANCO;
import static gen.gui.LettoreImmagini.leggiImmagineOggetto;
import static gen.sim.GeneratoreCasuale.generaNumeroSinoA;


import java.awt.Image;
import java.util.LinkedList;
import java.util.List;


import gen.sim.Ambiente;

import gen.sim.Direzione;


public class Bianco extends Animale {
	
	static final private Image IMMAGINE_BIANCA = leggiImmagineOggetto(RISORSA_IMMAGINE_BIANCO);

	static private int progId;
	private Animale obiettivo;
	
	
	
	
	public Bianco(Ambiente ambiente) {		
		super(ambiente,progId++, IMMAGINE_BIANCA);
	}
	
	
	public void simula(int passo) {
		int anno=super.getEta();
		super.setEta(anno+1);

		/* target gia' deciso? */
		if (this.getObiettivo()==null || isObiettivoRaggiunto()) {
			this.setObiettivo(decidiProssimoObiettivo());
		}
		
		final Direzione versoObiettivo = direzionaVerso(this.getObiettivo().getPosizione());
		this.setDirezione(versoObiettivo);
		
		this.setPosizione(super.calcolaNuovaPosizione());
	}
	
	
	protected Animale decidiProssimoObiettivo() {
		/* scegli un obiettivo casualmente */
		// Sugg.: al momento sono tutti della stessa specie, ma dopo DOMANDA 2bcd e' ancora vero? */
		final List<Animale> all = this.getAmbiente().getAllAnimali();
		final List<Animale> StessoTipo = new LinkedList<>();
		for(Animale a :all) {
			if(a.getClass().equals(Bianco.class)) {
				
				StessoTipo.add(a);
			}
		}
		if(!StessoTipo.isEmpty())
			return StessoTipo.get(generaNumeroSinoA(StessoTipo.size()));
		else
		return null;
		
	}
	
	public Bianco creaClone() {
		return new Bianco(this.getAmbiente());
	}


	public Animale getObiettivo() {
		return obiettivo;
	}


	public void setObiettivo(Animale obiettivo) {
		this.obiettivo = obiettivo;
	}


	@Override
	public boolean isObiettivoRaggiunto() {
		return this.getPosizione().equals(this.getObiettivo().getPosizione());
		
	}
	


	
	
}
