package battlefield;

public abstract class Robot {
	private Position posizione;
	private int longevita;
	private String tipo;
	public Robot(Position p,String tipo) {
		this.posizione = p;
		this.longevita = 0 ;
		this.setTipo(tipo);
	}

	public Position getPosizione() {
		return this.posizione;
	}
	
	public int incrementaLongevita() {
		return ++this.longevita;
	}
	
	public int getLongevita() {
		return this.longevita;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	
	


}
