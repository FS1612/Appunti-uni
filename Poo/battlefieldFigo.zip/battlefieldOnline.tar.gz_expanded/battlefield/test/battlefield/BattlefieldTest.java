package battlefield;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/* Modificare la classe Position affinche' 
 * il primo test abbia successo (vedi DOMANDA 1) 
 */
public class BattlefieldTest {
	
	private Battlefield field;
	Walker w1;
	Walker w2;
	Chaser c;
	@Before
	public void setUp() throws Exception {
		this.field = new Battlefield(2);
		this.c=new Chaser(new Position(2,2));
		this.w1=new Walker(new Position(3,2));
		this.w2=new Walker(new Position(4,4));
		this.field.addChaser(c);
		this.field.addWalker(w1);
		this.field.addWalker(w2);
	}

	@Test
	public void testAddWalker() {
		assertEquals(2, this.field.getAllWalkers().size());
		this.field.addWalker(new Walker(new Position(0,0)));
		assertEquals(3, this.field.getAllWalkers().size());
	}
	
	@Test
	public void testRaggruppaRobotDiDueTipiDiversi() {

		
		assertEquals(3,field.getField().size());
		assertEquals(2,field.raggruppaRobotPerTipo().size());
		assertEquals("{class battlefield.Walker=[battlefield.Walker@4034c28c, battlefield.Walker@14ec4505], class battlefield.Chaser=[battlefield.Chaser@e50a6f6]}",field.raggruppaRobotPerTipo().toString());
	}

}
