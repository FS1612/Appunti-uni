package battlefield;

import static org.junit.Assert.*;

import org.junit.*;

public class RobotOrdinatiPerPosizioneTest {

	private Battlefield field;
	private Battlefield field1;
	Walker w1;
	Walker w2;
	Chaser c;
	@Before
	public void setUp() throws Exception {
		this.field = new Battlefield(2);
		this.field1 = new Battlefield(2);
		this.c=new Chaser(new Position(2,2));
		this.w1=new Walker(new Position(3,2));
		this.w2=new Walker(new Position(2,4));
		this.field1.addChaser(c);
		

	}
	@Test
	public void testCampoVuoto() {
		assertEquals("[]",this.field.getRobotOrdinatiPerPosizione().toString());
	}
	@Test
	public void testCampo1Robot() {
		assertEquals(1,this.field1.getField().size());
		assertEquals(1,this.field1.getRobotOrdinatiPerPosizione().size());
		assertEquals("[battlefield.Chaser@23282c25]",this.field1.getRobotOrdinatiPerPosizione().toString());
	}
	
	@Test
	public void testCampo2RobotXdiversa() {
		this.field1.addWalker(w1);
		assertEquals(2,this.field1.getField().size());
		assertEquals(2,this.field1.getRobotOrdinatiPerPosizione().size());
		assertEquals("[battlefield.Chaser@4b168fa9, battlefield.Walker@1a84f40f]",this.field1.getRobotOrdinatiPerPosizione().toString());
	}
	@Test
	public void testCampo2RobotXUgualeYdiversa() {
		this.field1.addWalker(w2);
		assertEquals(2,this.field1.getField().size());
		assertEquals(2,this.field1.getRobotOrdinatiPerPosizione().size());
		assertEquals("[battlefield.Chaser@14ec4505, battlefield.Walker@53ca01a2]",this.field1.getRobotOrdinatiPerPosizione().toString());
	}
	@Test
	public void testCampo4Robot() {
		this.field1.addWalker(w2);
		this.field1.addWalker(w1);
		this.field1.addChaser(new Chaser(new Position(0,0)));
		assertEquals(4,this.field1.getField().size());
		assertEquals(4,this.field1.getRobotOrdinatiPerPosizione().size());
		assertEquals("[battlefield.Chaser@7920ba90, battlefield.Chaser@6b419da, battlefield.Walker@3b2da18f, battlefield.Walker@5906ebcb]",this.field1.getRobotOrdinatiPerPosizione().toString());
	}
}
