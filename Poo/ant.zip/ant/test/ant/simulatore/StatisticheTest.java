package ant.simulatore;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import ant.Cibo;
import ant.Coordinate;
import ant.formica.Aggressiva;
import ant.formica.Esploratrice;
import ant.formica.Formica;
import ant.formica.Inseguitrice;

@SuppressWarnings("unused")
public class StatisticheTest {

	private Simulatore simulatore;

	private Statistiche stats;	
	
	final private Coordinate origine = new Coordinate(0, 0);
	final private Coordinate pos_0_1 = new Coordinate(0,1);
	final private Coordinate pos_1_0 = new Coordinate(1,0);
	final private Coordinate pos_1_1 = new Coordinate(1,1);
	final private Coordinate pos_2_0 = new Coordinate(2,0);
	final private Coordinate pos_0_2 = new Coordinate(0,2);
	final private Coordinate pos_2_1 = new Coordinate(2,1);
	final private Coordinate pos_1_2 = new Coordinate(1,2);
	
	private Esploratrice esploratrice;
	private Inseguitrice inseguitrice;
	private Aggressiva aggressiva;
	
	@Before
	public void setUp() throws Exception {
		this.stats = new Statistiche();
		this.simulatore = new Simulatore();
		this.esploratrice = this.simulatore.creaEsploratrice();
		this.inseguitrice = this.simulatore.creaInseguitrice();
		this.aggressiva = this.simulatore.creaAggressiva();

	}

	
	private Cibo creaCiboRaccoltoDaEsploratrice() {
		final Cibo cibo = new Cibo(this.origine);
		cibo.setRaccoglitrice(this.simulatore.creaEsploratrice());	
		return cibo;
	}

	private Cibo creaCiboRaccoltoDaInseguitrice() {
		final Cibo cibo = new Cibo(this.origine);
		cibo.setRaccoglitrice(this.simulatore.creaInseguitrice());	
		return cibo;
	}
	
	private Cibo creaCiboRaccoltoDaAggressiva() {
		final Cibo cibo = new Cibo(this.origine);
		cibo.setRaccoglitrice(this.simulatore.creaInseguitrice());	
		return cibo;
	}
//
//	@Test
//	public void testRaccoltoPerFormica() {
//		Cibo ciboEsploratrice = new Cibo(this.origine);
//		Cibo ciboEsploratrice2 = new Cibo(this.pos_0_1);
//		Cibo ciboEsploratrice3 = new Cibo(this.pos_0_2);
//		Cibo ciboInseguitrice = new Cibo(this.pos_1_1);
//		Cibo ciboInseguitrice2 = new Cibo(this.pos_1_0);
//		Cibo ciboAggressiva = new Cibo(this.pos_1_2);
//		ciboAggressiva.setRaccoglitrice(aggressiva);
//		ciboInseguitrice.setRaccoglitrice(inseguitrice);
//		ciboInseguitrice2.setRaccoglitrice(inseguitrice);
//		ciboEsploratrice.setRaccoglitrice(esploratrice);
//		ciboEsploratrice2.setRaccoglitrice(esploratrice);
//		ciboEsploratrice3.setRaccoglitrice(esploratrice);
//		
//		Set<Cibo> raccoltoEsploratrice = new HashSet<Cibo>();
//		raccoltoEsploratrice.add(ciboEsploratrice);
//		raccoltoEsploratrice.add(ciboEsploratrice2);
//		raccoltoEsploratrice.add(ciboEsploratrice3);
//		
//		Set<Cibo> raccoltoInseguitrice = new HashSet<Cibo>();
//		raccoltoInseguitrice.add(ciboInseguitrice);
//		raccoltoInseguitrice.add(ciboInseguitrice2);
//
//		Set<Cibo> raccoltoAggressiva = new HashSet<Cibo>();
//		raccoltoAggressiva.add(ciboAggressiva);
//		
//		Set<Cibo> cibo = new HashSet<Cibo>();
//		cibo.addAll(raccoltoAggressiva);
//		cibo.addAll(raccoltoInseguitrice);
//		cibo.addAll(raccoltoEsploratrice);
//		
//		Map<Formica, Integer> formica2Raccolto = this.stats.raccoltoPerFormica(cibo);
//		assertEquals(3, formica2Raccolto.size());
//		assertEquals(1, raccoltoAggressiva.size());
//		assertEquals(2, raccoltoInseguitrice.size());
//		assertEquals(3, raccoltoEsploratrice.size());
//		assertEquals(new Integer(1), formica2Raccolto.get(this.aggressiva));
//		assertEquals(new Integer(2), formica2Raccolto.get(this.inseguitrice));
//		assertEquals(new Integer(3), formica2Raccolto.get(this.esploratrice));
//	}
//	
//	@Test
//	public void testRaccoltoPerTipoDiFormica() {
//		Set<Cibo> ciboAggressiva = new HashSet<Cibo>();
//		Cibo ca = this.creaCiboRaccoltoDaAggressiva();
//		ca.setRaccoglitrice(aggressiva);
//		ciboAggressiva.add(ca);
//		
//		Set<Cibo> ciboEsploratrice = new HashSet<Cibo>();
//		Cibo ce = this.creaCiboRaccoltoDaEsploratrice();
//		ce.setRaccoglitrice(esploratrice);
//		ciboEsploratrice.add(ce);
//		
//		Set<Cibo> ciboInseguitrice = new HashSet<Cibo>();
//		Cibo ci = this.creaCiboRaccoltoDaInseguitrice();
//		ci.setRaccoglitrice(inseguitrice);
//		ciboInseguitrice.add(ci);
//		
//		Map<Class<? extends Formica>, Set<Cibo>> formica2cibo = new HashMap<Class<? extends Formica>, Set<Cibo>>();
//		formica2cibo.put(ca.getRaccoglitrice().getClass(), ciboAggressiva);
//		formica2cibo.put(ce.getRaccoglitrice().getClass(), ciboEsploratrice);
//		formica2cibo.put(ci.getRaccoglitrice().getClass(), ciboInseguitrice);
//		
//		assertEquals(3, formica2cibo.size());
//		assertEquals(1, formica2cibo.get(ca.getRaccoglitrice().getClass()).size());
//		assertEquals(1, formica2cibo.get(ce.getRaccoglitrice().getClass()).size());
//		assertEquals(1, formica2cibo.get(ci.getRaccoglitrice().getClass()).size());
//		assertEquals(ciboAggressiva, formica2cibo.get(ca.getRaccoglitrice().getClass()));
//		assertEquals(ciboEsploratrice, formica2cibo.get(ce.getRaccoglitrice().getClass()));
//		assertEquals(ciboInseguitrice, formica2cibo.get(ci.getRaccoglitrice().getClass()));
//
//	}
	@Test
	public void soloInseguitrice() {
		Cibo cibo1=this.creaCiboRaccoltoDaInseguitrice();
		Set<Cibo> set=Collections.singleton(cibo1);
		assertEquals(Collections.singletonMap(cibo1.getRaccoglitrice(), 1),this.stats.raccoltoPerFormica(set));
	}
	@Test
	public void soloEsploratrice() {
		Cibo cibo1=this.creaCiboRaccoltoDaEsploratrice();
		Set<Cibo> set=Collections.singleton(cibo1);
		assertEquals(Collections.singletonMap(cibo1.getRaccoglitrice(), 1),this.stats.raccoltoPerFormica(set));
	}
	@Test
	public void _2Formiche2cibi() {
		Cibo cibo1=this.creaCiboRaccoltoDaEsploratrice();
		Cibo cibo2=this.creaCiboRaccoltoDaInseguitrice();
		Set<Cibo> set=new HashSet<>(Arrays.asList(cibo1,cibo2));
		Map <Formica,Integer>test= new HashMap<>();
		test.put(cibo1.getRaccoglitrice(), Integer.valueOf(1));
		test.put(cibo2.getRaccoglitrice(), Integer.valueOf(1));
		assertEquals(test,this.stats.raccoltoPerFormica(set));
	}
	@Test
	public void _2Formiche3cibi() {
		Cibo cibo1=this.creaCiboRaccoltoDaEsploratrice();
		Cibo cibo2=this.creaCiboRaccoltoDaInseguitrice();
		Cibo cibo3=this.creaCiboRaccoltoDaEsploratrice();
		cibo3.setRaccoglitrice(cibo1.getRaccoglitrice());
		Set<Cibo> set=new HashSet<>(Arrays.asList(cibo1,cibo2,cibo3));
		Map <Formica,Integer>test= new HashMap<>();
		test.put(cibo1.getRaccoglitrice(), Integer.valueOf(1));
		test.put(cibo2.getRaccoglitrice(), Integer.valueOf(1));
		test.put(cibo3.getRaccoglitrice(), Integer.valueOf(1));
		assertEquals(test,this.stats.raccoltoPerFormica(set));
	}
}
