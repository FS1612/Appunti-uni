package ant;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class AmbienteTest {
	
	Ambiente senzaOstacoli;
	Ambiente ostacoloIn3_3;
	Ambiente circondatoInBassoASinistra;

	@Before
	public void setUp() throws Exception {
		this.senzaOstacoli = new Ambiente(10);
		this.senzaOstacoli.rimuoviOgniOstacolo(10);
		this.ostacoloIn3_3 = new Ambiente(10);
		this.ostacoloIn3_3.rimuoviOgniOstacolo(10);
		this.ostacoloIn3_3.aggiungiOstacolo(3,3);
		this.circondatoInBassoASinistra = new Ambiente(10);
		this.circondatoInBassoASinistra.rimuoviOgniOstacolo(10);
		this.circondatoInBassoASinistra.aggiungiOstacolo(2,1);
		this.circondatoInBassoASinistra.aggiungiOstacolo(2,2);
		this.circondatoInBassoASinistra.aggiungiOstacolo(1,2);
	}

	@Test
	public void testGetPossibiliDirezioni_senzaOstacoli() {
		assertEquals(8, this.senzaOstacoli.getPossibiliDirezioni(3,3).size());
		assertEquals(3, this.senzaOstacoli.getPossibiliDirezioni(1,1).size());
	}
	
	@Test
	public void testGetPossibiliDirezioni_ostacoloIn3_3() {
		assertEquals(7, this.ostacoloIn3_3.getPossibiliDirezioni(3, 4).size());
		assertEquals(8, this.ostacoloIn3_3.getPossibiliDirezioni(4, 4).size());
	}

	@Test
	public void testGetPossibiliDirezioni_circondatoInBassoASinistra() {
		assertEquals(0, this.circondatoInBassoASinistra.getPossibiliDirezioni(1,1).size());
		assertEquals(8, this.circondatoInBassoASinistra.getPossibiliDirezioni(4, 4).size());
	}
}
