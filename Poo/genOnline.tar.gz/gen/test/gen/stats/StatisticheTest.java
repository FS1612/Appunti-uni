package gen.stats;

import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import gen.stats.Statistiche;

public class StatisticheTest {

	@SuppressWarnings("unused")
	private Statistiche stats;

	@Before
	public void setUp() {
		this.stats = new Statistiche();
	}
	
	@Test
	public void testScontriPerAnimale() {
		// DA COMPLETARE ( VEDI DOMANDA 3 )
		fail("DA COMPLETARE");
	}

}
