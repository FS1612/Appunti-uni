import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Parco {
	private static final int NUM_INIZIALE_ANIMALI = 2200;
	private static final double PROBABILITA_RAPACE = 0.2;

	private int dimensione;
	private Map<Posizione, Roditore> posizione2roditore;
	private Map<Posizione, Rapace> posizione2rapace;

	public Parco(int dimensione){
		this.dimensione = dimensione;
		this.posizione2roditore = new TreeMap<Posizione, Roditore>();
		this.posizione2rapace = new TreeMap<Posizione, Rapace>();
		this.popolaTerritorio();
	}

	public Roditore getRoditore(Posizione posizione){
		return posizione2roditore.get(posizione);
	}

	public Rapace getRapace(Posizione posizione){
		return posizione2rapace.get(posizione);
	}

	public void eliminaRoditore(Roditore roditore) {
		this.posizione2roditore.remove(roditore.getPosizione());
	}

	public void eliminaRapace(Rapace rapace) {
		this.posizione2rapace.remove(rapace.getPosizione());
	}

	public void setRoditore(Roditore roditore, Posizione posizione) {
		if (this.getRoditore(posizione)==null){
			this.posizione2roditore.put(posizione, roditore);
			roditore.setPosizione(posizione);
		}
	}

	public void setRapace(Rapace rapace, Posizione posizione) {
		if (this.getRapace(posizione)==null){
			this.posizione2rapace.put(posizione, rapace);
			rapace.setPosizione(posizione);
		}
	}

	public Collection<Roditore> getRoditori(){
		return this.posizione2roditore.values();
	}

	public Collection<Rapace> getRapaci(){
		return this.posizione2rapace.values();
	}

	public void muovi(Roditore roditore, Posizione nuovaPosizione) {
		this.eliminaRoditore(roditore);
		this.setRoditore(roditore, nuovaPosizione);
	}

	public void muovi(Rapace rapace, Posizione nuovaPosizione) {
		this.eliminaRapace(rapace);
		this.setRapace(rapace, nuovaPosizione);
	}

	public List<Posizione> adiacenti(Posizione posizione) {
		List<Posizione> adiacenti = new LinkedList<Posizione>();
		int x = posizione.getX();
		int y = posizione.getY();

		for(int i = -1; i<2; i++) {
			for(int j = -1; j<2; j++) {
				adiacenti.add(new Posizione(x+i, y+j));
				}
			}
		Iterator<Posizione> it = adiacenti.iterator();
		while(it.hasNext()){
			Posizione p = it.next();
			if ((p.getX()<0) || (p.getX()>=this.dimensione) || (p.getY()<0) ||
					(p.getY()>=this.dimensione) || (p.equals(posizione)))
				it.remove();
		}
		Collections.shuffle(adiacenti);
		return adiacenti;
	}

	public Posizione posizioneLiberaVicino(Posizione posizione) {
		for(Posizione p : this.adiacenti(posizione)) {
			if (this.isLibera(p)) {
				return p;
			}
		}
		return null;
	}

	public boolean isLibera(Posizione posizione) {
			if ((this.getRoditore(posizione)==null) &&
					(this.getRapace(posizione)==null)) {
				return true;
			} else
		return false;
	}

	public int getDimensione() {
		return this.dimensione;
	}

	private void popolaTerritorio(){

		int numeroAnimali = 0;

		while (numeroAnimali < NUM_INIZIALE_ANIMALI) {
			int x = (int)(Math.random()*this.dimensione);
			int y = (int)(Math.random()*this.dimensione);
			Posizione posizione = new Posizione(x, y);
			if (this.isLibera(posizione)) {
				if(Math.random() < PROBABILITA_RAPACE) {
					Rapace nuovoAnimale = new Rapace();
					this.setRapace(nuovoAnimale, posizione);
				} else {
					Roditore nuovoAnimale = new Roditore();
					this.setRoditore(nuovoAnimale, posizione);
				}
				numeroAnimali++;
			}
		}
	}

}
