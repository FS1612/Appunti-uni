package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.IoConsole;
import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.comandi.Comandi;
import it.uniroma3.diadia.comandi.ComandoPosa;
import it.uniroma3.diadia.giocatore.Borsa;
import it.uniroma3.diadia.giocatore.Giocatore;

public class ComandoPosaTest {
	private static final String NOME_STANZA_TEST = "Test";
	private static final String POSA = "AttrezzoTest";
	private Partita partita;
	private Comandi comandoPosa;
	private Stanza stanzaVuota;
	private Stanza stanzaAttrezzoPresente;
	
	private Attrezzo attrezzoTest;
	private Borsa borsa;
	private Giocatore giocatore;
	

	@Before
	public void setUp() {
		this.borsa=new Borsa();
		stanzaVuota=new Stanza(NOME_STANZA_TEST);
		stanzaAttrezzoPresente=new Stanza(NOME_STANZA_TEST);
		this.comandoPosa = new ComandoPosa();
		this.comandoPosa.SetIO(new IoConsole());
		this.partita = new Partita();
		this.attrezzoTest=new Attrezzo("AttrezzoTest",1);
		this.stanzaAttrezzoPresente.addAttrezzo(this.attrezzoTest);
		
		this.giocatore=new Giocatore();
		this.partita.SetGiocatore(this.giocatore);
		this.giocatore.SetBorsa(this.borsa);
		
	}
	
	@Test
	public void testStanzaVuota() {
		this.partita.setStanzaCorrente(stanzaVuota);
		this.borsa.addAttrezzo(attrezzoTest);
		comandoPosa.setParametro(POSA);
		comandoPosa.esegui(this.partita);
		assertEquals("Test\n"
				+ "Uscite: \n"
				+ "Attrezzi nella stanza: AttrezzoTest (1kg) ",this.partita.getStanzaCorrente().getDescrizione());
	}
	@Test
	public void testStanzaAttrezzoPresente() {
		this.partita.setStanzaCorrente(stanzaAttrezzoPresente);
		this.borsa.addAttrezzo(attrezzoTest);
		comandoPosa.setParametro(POSA);
		comandoPosa.esegui(this.partita);
		assertEquals("Test\n"
				+ "Uscite: \n"
				+ "Attrezzi nella stanza: AttrezzoTest (1kg) AttrezzoTest (1kg) ",this.partita.getStanzaCorrente().getDescrizione());	
	}
	
}
