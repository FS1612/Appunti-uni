package test;


import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.giocatore.Giocatore;

public class TestGiocatore {
Giocatore giocatore;
Attrezzo attrezzo1;

	@Before
	public void setUp() throws Exception {
		giocatore=new Giocatore();
		attrezzo1=new Attrezzo("attrezzo1",1);
		
	}

	@Test
	public void testGetBorsaVuota() {
		assertTrue(this.giocatore.GetBorsa().isEmpty());
	}
	@Test
	public void testGetBorsa1oggetto() {
		this.giocatore.GetBorsa().addAttrezzo(attrezzo1);
		
		assertTrue(this.giocatore.GetBorsa().hasAttrezzo("attrezzo1"));
	}
}
