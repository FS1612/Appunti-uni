package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.IoConsole;
import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.comandi.Comandi;
import it.uniroma3.diadia.comandi.ComandoPrendi;
import it.uniroma3.diadia.giocatore.Borsa;
import it.uniroma3.diadia.giocatore.Giocatore;

public class ComandoPrendiTest {
	private static final String NOME_STANZA_TEST = "Test";
	private static final String PRENDI = "AttrezzoTest";
	private Partita partita;
	private Comandi comandoPrendi;
	private Stanza stanzaTest;
//	private Stanza StanzaVuota;
	private Attrezzo attrezzoTest;
	private Borsa borsaVuota;
//	private Borsa borsaAttrezzo;
	private Borsa borsaPiena;
	private Giocatore giocatore;
	@Before
	public void setUp() {
		this.borsaVuota=new Borsa();
		this.borsaPiena=new Borsa();
		stanzaTest=new Stanza(NOME_STANZA_TEST);
		this.comandoPrendi = new ComandoPrendi();
		this.comandoPrendi.SetIO(new IoConsole());
		this.partita = new Partita();
		this.attrezzoTest=new Attrezzo("AttrezzoTest",1);;

		this.giocatore=new Giocatore();
		this.partita.SetGiocatore(this.giocatore);
	}
	
	@Test
	public void testBorsaVuotaAttrezzoPresente() {
		this.partita.setStanzaCorrente(stanzaTest);
		this.stanzaTest.addAttrezzo(attrezzoTest);
		this.giocatore.SetBorsa(borsaVuota);
		this.comandoPrendi.setParametro(PRENDI);
		this.comandoPrendi.esegui(this.partita);
		assertEquals("Contenuto borsa (1kg/10kg): AttrezzoTest (1kg) ",this.borsaVuota.toString());
		
	}
	@Test
	public void testBorsaVuotaAttrezzoNonPresente() {
		this.partita.setStanzaCorrente(stanzaTest);
		this.giocatore.SetBorsa(borsaVuota);
		this.comandoPrendi.setParametro(PRENDI);
		this.comandoPrendi.esegui(this.partita);
		assertEquals("Borsa vuota",this.borsaVuota.toString());
	}
	

}
