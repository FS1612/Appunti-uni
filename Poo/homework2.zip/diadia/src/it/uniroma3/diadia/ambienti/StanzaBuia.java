package it.uniroma3.diadia.ambienti;

public class StanzaBuia extends Stanza {
private String oggettoFigo;

	public StanzaBuia(String oggetto,String nome) {
		super(nome);
		this.oggettoFigo=oggetto;
		
	}
	@Override
public String getDescrizione() {
	if(super.hasAttrezzo(oggettoFigo)) 
	return super.getDescrizione();
	
	else  
		return "non si vede nulla";
	
	
}
}
