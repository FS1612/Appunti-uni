
package  it.uniroma3.diadia;
import it.uniroma3.diadia.ambienti.Labirinto;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.giocatore.Borsa;
import it.uniroma3.diadia.giocatore.Giocatore;

/**
 * Questa classe modella una partita del gioco
 *
 * @author  docente di POO
 * @see Stanza
 * @version base
 */

public class Partita {
 Labirinto lab;
 Giocatore giocatore;

	private boolean finita;

	
	public Partita(){
		lab=new Labirinto();
		giocatore =new Giocatore();

		this.finita = false;

	}

	public Stanza getStanzaVincente() {

		return this.lab.GetStanzaVincente();
	}

	public void setStanzaCorrente(Stanza stanzaCorrente) {

		this.lab.SetStanzaCorrente(stanzaCorrente); 
	}

	public Stanza getStanzaCorrente() {

		return this.lab.GetStanzaCorrente();
	}
	
	/**
	 * Restituisce vero se e solo se la partita e' stata vinta
	 * @return vero se partita vinta
	 */
	public boolean vinta() {
		return this.lab.GetVinta()
;	}
	
	

	/**
	 * Restituisce vero se e solo se la partita e' finita
	 * @return vero se partita finita
	 */
	public boolean isFinita() {
		 
		 return (finita || vinta() || (this.giocatore.GetCfu() == 0));
//		
		
	}

	/**
	 * Imposta la partita come finita
	 *
	 */
	public void setFinita() {
		this.finita = true;
	}

	public int getCfu() {
		return this.giocatore.GetCfu();
	}

	public void setCfu(int cfu) {
		this.giocatore.SetCfu(cfu); 	
	}	
	public Giocatore GetGiocatore() {
		return this.giocatore;
	}
	public void SetStanzaVincente(Stanza v) {
		this.lab.SetStanzaVincente(v);;
	}
	public void SetGiocatore(Giocatore giocatore) {
		this.giocatore=giocatore;
	}
	public void SetBorsa(Borsa borsa) {
		this.giocatore.SetBorsa(borsa);;
	}
}
