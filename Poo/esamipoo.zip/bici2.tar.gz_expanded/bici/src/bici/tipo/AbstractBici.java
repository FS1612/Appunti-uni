package bici.tipo;

import static bici.sim.GeneratoreCasuale.posizioneCasuale;

import java.awt.Image;
import java.util.Set;

import bici.sim.Coordinate;
import bici.sim.Direzione;
import bici.sim.Percorso;
import bici.sim.Zona;

public abstract class AbstractBici {
	private Zona zona;
	private Coordinate posizione;
	private Coordinate origine;
	private Coordinate destinazione;
	private Direzione direzione;
	private int id=0;
	private Image img;
	public Direzione getDirezione() {
		return direzione;
	}
	public void setDirezione(Direzione direzione) {
		this.direzione = direzione;
	}
	public Zona getZona() {
		return zona;
	}
	public Coordinate getPosizione() {
		return posizione;
	}
	public Coordinate getOrigine() {
		return origine;
	}
	public Coordinate getDestinazione() {
		return destinazione;
	}
	public void setZona(Zona zona) {
		this.zona = zona;
	}
	public void setPosizione(Coordinate posizione) {
		this.posizione = posizione;
	}
	public void setOrigine(Coordinate origine) {
		this.origine = origine;
	}
	public void setDestinazione(Coordinate destinazione) {
		this.destinazione = destinazione;
	}
	public AbstractBici(Zona zona,Image img,int num) {
		final Coordinate posizioneIniziale = posizioneCasuale();
		this.zona=zona;
		this.posizione = posizioneIniziale;
		this.origine = posizioneIniziale;
		this.destinazione = null;
		this.direzione = null;
		this.img=img;
		this.id=num;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public abstract Coordinate decidiProssimaDestinazione();
	public boolean destinazioneRaggiunta() {
		return this.getPosizione().equals(this.destinazione);
	}
	public void eseguiSpostamento() {
		this.setPosizione(this.getPosizione().trasla(this.getDirezione()));
	}
	public Set<Direzione> getPossibiliDirezioni() {
		return this.getZona().getPossibiliDirezioni(this.getPosizione());
	}
	public void direzionaVerso(Coordinate dest) {
		final Direzione verso = Direzione.verso(this.getPosizione(),dest);
		final Set<Direzione> possibili = getPossibiliDirezioni();
		if (possibili.contains(verso)) 
			this.setDirezione(verso);
		else this.setDirezione(Direzione.scegliAcasoTra(possibili));
	}

	public Image getImg() {
		return img;
	}
	public void setImg(Image img) {
		this.img = img;
	}
	public String toString() {
		return getClass().getSimpleName();
	}
	public void simula(int passo) {
		int passoIniziale = -1;
		/* destinazione iniziale gia' fissata? */
		if (getDestinazione()==null) {
			setDestinazione(decidiProssimaDestinazione());
			passoIniziale = passo;
		} else if (destinazioneRaggiunta()) {
			/* registra il percorso coperto */ 
			final Percorso percorso = new Percorso(this,getOrigine(),getDestinazione());
			percorso.setPassoIniziale(passoIniziale);
			percorso.setPassoFinale(passo);
			this.getZona().add(percorso);
			setOrigine(getDestinazione()); 
			setDestinazione(decidiProssimaDestinazione());			
		}
		direzionaVerso(getDestinazione());
		eseguiSpostamento();
}
	@Override
	public int hashCode() {
		
		return this.getDestinazione().hashCode()*this.getDirezione().hashCode()*this.getOrigine().hashCode()*this.getPosizione().hashCode()*this.getImg().hashCode()*this.getId();
	}
	@Override
	public boolean equals(Object obj) {
		AbstractBici b=(AbstractBici) obj;
		return this.getId()==b.getId()&&this.getImg().equals(b.getImg())&&this.getZona().equals(b.getZona())&&this.getDestinazione().equals(b.getDestinazione())&&this.getPosizione().equals(b.getPosizione())&&this.origine.equals(b.getOrigine());
	}
	
}
