package bici.stats;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import bici.sim.Coordinate;
import bici.sim.Direzione;
import bici.sim.Percorso;
import bici.sim.Zona;
import bici.tipo.AbstractBici;
import bici.tipo.Bianca;
import bici.tipo.Gialla;

public class StatisticheTest {
private Percorso bianca;
private Percorso gialla;
private Percorso gialla1;
private Zona z;
private Gialla g1;
private Gialla g;
private Bianca b;
private Set<Percorso>p;
	@SuppressWarnings("unused")
	private Statistiche stats;

	@Before
	public void setUp() {
		this.stats = new Statistiche();
		this.g=new Gialla(z);
		this.g1=new Gialla(z);
		this.b=new Bianca(z);
		this.g.setOrigine(new Coordinate(0,0));
		this.g.setPosizione(new Coordinate(0,0));
		this.g.setDirezione(Direzione.NORD);
		this.g.setDestinazione(new Coordinate(5,5));
		this.g1.setOrigine(new Coordinate(1,0));
		this.g1.setPosizione(new Coordinate(0,0));
		this.g1.setDirezione(Direzione.NORD);
		this.g1.setDestinazione(new Coordinate(5,5));
		this.b.setOrigine(new Coordinate(1,0));
		this.b.setPosizione(new Coordinate(0,0));
		this.b.setDirezione(Direzione.NORD);
		this.b.setDestinazione(new Coordinate(5,5));
		this.bianca=new Percorso(b,new Coordinate(0,0),new Coordinate(1,1));
		this.gialla=new Percorso(g,new Coordinate(3,3),new Coordinate(5,5));
		
		this.p=new HashSet<>();
		this.p.add(bianca);
		this.p.add(gialla);
		
	}
	
	@Test
	public void testPercorsoPerBici() {
		this.gialla1=new Percorso(g,new Coordinate(3,0),new Coordinate(0,5));
		this.p.add(gialla1);
		Map<AbstractBici, List<Percorso>> sol=new HashMap<>();
		List<Percorso>pb= new ArrayList<>();
		pb.add(bianca);
		List<Percorso>pg= new ArrayList<>();
		pg.add(gialla);
		pg.add(gialla1);
		sol.put(pb.get(0).getBici(), pb);
		sol.put(pg.get(0).getBici(), pg);
//		assertEquals(sol,this.stats.percorsiPerBici(p));
		assertEquals(1,this.stats.percorsiPerBici(p).get(b).size());
		assertEquals(2,this.stats.percorsiPerBici(p).get(g).size());
	}
	@Test
	public void testPercorsoPerBiciDiverse() {
		this.gialla1=new Percorso(g1,new Coordinate(3,0),new Coordinate(0,5));
		this.p.add(gialla1);
		Map<AbstractBici, List<Percorso>> sol=new HashMap<>();
		List<Percorso>pb= new ArrayList<>();
		pb.add(bianca);
		List<Percorso>pg= new ArrayList<>();
		pg.add(gialla);
		List<Percorso>pg1= new ArrayList<>();
		pg1.add(gialla1);
		sol.put(pb.get(0).getBici(), pb);
		sol.put(pg.get(0).getBici(), pg);

		assertEquals(1,this.stats.percorsiPerBici(p).get(b).size());
		assertEquals(1,this.stats.percorsiPerBici(p).get(g).size());
		assertEquals(1,this.stats.percorsiPerBici(p).get(g1).size());
	}
}
