package bici.tipo;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import bici.sim.Coordinate;
import bici.sim.GeneratoreCasuale;
import bici.sim.Zona;

public class GiallaTest {
	GeneratoreCasuale gc;
	Gialla g;
	Zona z;
	
	@Before
	public void setUp() {
		this.gc = new GeneratoreCasuale();
		this.g=new Gialla(z);
	}
	
	@Test
	public void testSingolaPosizione() {
		Coordinate c = g.decidiProssimaDestinazione();
		assertTrue(c.getX()<=10);
		assertTrue(c.getY()<=10);
	}
	
	@Test
	public void testPosizioniMultiple() {
		List<Coordinate> lc = new ArrayList<>();
		for(int i=0;i<20;i++) 
			lc.add(g.decidiProssimaDestinazione());
		for(int i=0;i<4;i++) {
			assertTrue(lc.get(i).getX()<=10);
			assertTrue(lc.get(i).getY()<=10);
		}
	}
	
}