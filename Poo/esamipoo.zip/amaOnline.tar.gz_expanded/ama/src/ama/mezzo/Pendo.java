package ama.mezzo;

import static ama.costanti.CostantiGUI.IMMAGINE_CAMION_BIANCO;

import java.awt.Image;

import ama.Citta;
import ama.Posizione;

public class Pendo extends AbstractPolitica {
private static int  ind=0;
private Citta citta;
private boolean fine;//* booleano che indica se ho toccato il muro � true se lo toccas

	public Pendo(Citta citta) {
		super(ind++);
		this.citta = citta;
		this.fine =false;

	}
	//*verifico se, data una posizione di partenza, effettuando il movimento verso destra o verso sinistra tocco il muro
private boolean Arrivato(Posizione p) {
	Posizione arrivo1=p.traslazioneUnitaria(1, 0);
	Posizione arrivo2=p.traslazioneUnitaria(-1, 0);
	return citta.sulBordo(arrivo2)||citta.sulBordo(arrivo1);
}

	@Override
	public Posizione decidiDirezione(Posizione corrente) {
		 Posizione posArrivo=corrente;
		
		if(!Arrivato(corrente)&&!fine) {
			posArrivo=corrente.traslazioneUnitaria(1, 0);
		}else if(Arrivato(corrente)&&!fine) {
			fine=true;
			posArrivo=corrente.traslazioneUnitaria(-1, 0);
		}
		else if(!Arrivato(corrente)&&fine) {
			fine=true;
			posArrivo=corrente.traslazioneUnitaria(-1, 0);
		}
		else if(Arrivato(corrente)&&fine) {
			fine=false;
			posArrivo=corrente.traslazioneUnitaria(1, 0);
		}
		
		
		return posArrivo;
	}

	@Override
	public Image getImmagine() {
		return IMMAGINE_CAMION_BIANCO;
	
	}

}
