package ama.mezzo;
import static ama.costanti.CostantiGUI.IMMAGINE_CAMION_VERDE;

import java.awt.Image;
import java.util.Random;


import ama.Posizione;
public abstract class AbstractPolitica {

	
	private int id;

	final private Random rnd;
	
	public AbstractPolitica(int progId) {
		
		this.setId( progId);
		this.rnd = new Random();
	}

	
	public Random getRnd() {
		return rnd;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	public int getId() {
		return this.id;
	}
	public abstract Posizione decidiDirezione(Posizione corrente);
	public int deltaCasuale() {
		return this.rnd.nextInt(3)-1;
	}
	public abstract Image getImmagine() ;
	public String toString() {
		return getClass().getSimpleName()+getId();
	}
}
