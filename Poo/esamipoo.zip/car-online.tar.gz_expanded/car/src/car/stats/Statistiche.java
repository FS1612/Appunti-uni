package car.stats;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import car.auto.Auto;
import car.auto.Bianca;
import car.sim.Coordinate;
import car.sim.Tragitto;
import car.sim.Zona;

public class Statistiche {

	synchronized public void stampaFinale(Zona zona) {
		final List<Tragitto> tragitti = zona.getTragitti();

		System.out.println(tragitti.size() + " tragitti collezionati." );
		System.out.println(zona.getTragitti());
		System.out.println();

		// (VEDI DOMANDA 3)
		System.out.println("Percorsi di ciascuna vettura:");
		final Map<Auto, Set<Tragitto>> auto2tragitti = tragittoPerAuto(tragitti);
		stampaTragittiPerAuto(auto2tragitti);
		System.out.println();

		// (VEDI DOMANDA 4)
		System.out.println("Classifica finale delle posizioni piu' battute:");
		final SortedMap<Coordinate,Integer> pos2utilizzi = utilizzi(tragitti);
		stampaUtilizzi(pos2utilizzi);
		System.out.println();
	}

	/**
	 * <B>DA COMPLETARE (VEDI DOMANDA 3)</B>
	 * @param tragitti - lista dei tragitti collezionati durante la simulazione
	 * @return una mappa che riporti per ogni auto (di qls tipo)
	 *         l'insieme dei tragitti che ha percorso
	 */
	public Map<Auto, Set<Tragitto>> tragittoPerAuto(List<Tragitto> tragitti) {
		Map<Auto, Set<Tragitto>> tragitto=new HashMap<>();
		for (Tragitto t:tragitti) {
			if(!tragitto.containsKey(t.getAuto())) {
				Set<Tragitto>st= new HashSet<>();
				st.add(t);
				tragitto.put(t.getAuto(), st);
			}
			else {
				Set<Tragitto>st= new HashSet<>();
				st=tragitto.get(t.getAuto());
				st.add(t);
				tragitto.put(t.getAuto(), st);
			}
		}
		return tragitto;
	}

	/**
	 * <EM>N.B. UTILE PER STAMPARE RISULTATI DOMANDA 3</EM>
	 * @param auto2tragitti
	 */
	private void stampaTragittiPerAuto(final Map<Auto, Set<Tragitto>> auto2tragitti) {
		for(Auto auto : auto2tragitti.keySet()) {
			Set<Tragitto> tragitti = auto2tragitti.get(auto);
			System.out.println("L'auto "+auto+" ha fatto "+( tragitti!=null ? tragitti.size() : 0 ) +" corse");
		}
	}
	
	/**
	 * <B>DA COMPLETARE (VEDI DOMANDA 4)</B>
	 * 	@param tragitti - lista dei tragitti collezionati durante la simulazione
	 * @return una mappa ordinata decrescente in cui figurano come chiavi 
	 *         le posizioni piu'battute come origine o destinazione di un 
	 *         tragitto, come valori il numero di tali tragitti
	 */
	public SortedMap<Coordinate,Integer> utilizzi(List<Tragitto> tragitti) {
		class ComparatoreCoordinate implements Comparator<Coordinate>{

			@Override
			public int compare(Coordinate o1, Coordinate o2) {
				if(o1.getX()==o2.getY()) {
					return o1.getY()-o2.getY();
				}
				else 
				return o1.getX()-o2.getX();
			}
		}
		SortedMap<Coordinate,Integer> u=new TreeMap<>(new ComparatoreCoordinate()); 
		for(Tragitto t:tragitti) {
			Coordinate origine= t.getOrigine();
			Coordinate destinazione= t.getDestinazione();
			if(!u.containsKey(origine)) {
				u.put(origine, 1);
			}
			if(!u.containsKey(destinazione)) {
				u.put(destinazione, 1);
			}
			if(u.containsKey(origine)) {
				int val= u.get(t.getOrigine())+1;
				u.put(origine, val);
			}
			if(u.containsKey(destinazione)) {
				int val= u.get(t.getDestinazione())+1;
				u.put(destinazione, val);
				
			}
		}
		class ComparatoreQuantita implements Comparator<Coordinate>{
private SortedMap<Coordinate, Integer> u;
			public ComparatoreQuantita(SortedMap<Coordinate, Integer> u) {
				this.u=u;
			}

			@Override
			public int compare(Coordinate o1, Coordinate o2) {
				
				return this.u.get(o1)-this.u.get(o2);
			}
			
		}
		
		SortedMap<Coordinate,Integer>finale = new TreeMap<>(new ComparatoreQuantita(u));
		finale.putAll(u);
		return finale;
	}
	
	/**
	 * <EM>N.B. UTILE PER STAMPARE RISULTATI DOMANDA 4</EM>
	 * @param classifica delle posizioni piu' usate
	 */
	private void stampaUtilizzi(SortedMap<Coordinate,Integer> classifica) {
		int i = 0;
		for(Map.Entry<Coordinate, Integer> entry : classifica.entrySet()) {
			final Coordinate posizione = entry.getKey();
			final Integer numeri = entry.getValue();
			System.out.println(i+") "+posizione+" con "+numeri+" utilizzi");
			i++;
		}
	}

}
