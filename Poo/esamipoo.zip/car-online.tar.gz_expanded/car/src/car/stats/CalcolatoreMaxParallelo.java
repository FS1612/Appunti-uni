package car.stats;

public class CalcolatoreMaxParallelo implements CalcolatoreMax {

	@Override
	public int max(int[][] m) {
		// DA COMPLETARE 
		// (SOLO PER STUDENTI CHE SOSTENGONO ESAME DA 9 CFU)
		// VEDI DOMANDA 6
		return 0;
	}

}
