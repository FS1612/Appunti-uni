package prop.stats;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import prop.sim.Contatto;
import prop.sim.Simulatore;

/**
 * <B>DA COMPLETARE (VEDI DOMANDA 3)</B>
 */
public class Statistiche {

	synchronized public void stampaFinale(Simulatore simulatore) {
		final List<Contatto> contatti = simulatore.getContatti();

		System.out.println(contatti.size() + " contatti rilevati." );
		System.out.println(simulatore.getContatti());
		System.out.println();

		final Map<Integer,Set<Contatto>> mappa = produciStatistiche(simulatore.getContatti());
		System.out.println("Contatti per persona:");
		stampaStatistiche(mappa);
		System.out.println();
	}

	public Map<Integer, Set<Contatto>> produciStatistiche(List<Contatto> contatti) {
		class comparatore implements Comparator<Integer>{
			Map<Integer, Set<Contatto>>m;

			public comparatore(Map<Integer, Set<Contatto>> risultato) {
				m=risultato;
			}

			@Override
			public int compare(Integer o1, Integer o2) {
				
				return m.get(o2).size()-m.get(o1).size();
			}
			
		}
		Map<Integer,Set<Contatto>> risultato=new HashMap<>();
		for(Contatto c: contatti) {
			Integer passo=c.getPassoSimulazione();
			if(risultato.containsKey(passo)) {
				Set<Contatto> r=risultato.get(passo);
				r.add(c);
				risultato.put(passo, r);
			}
			else {
				Set<Contatto> r=new HashSet<>();
				r.add(c);
				risultato.put(passo, r);
			}
		}
		Map<Integer,Set<Contatto>> risultatoFinale=new TreeMap<>(new comparatore(risultato));
		risultatoFinale.putAll(risultato);
		return risultatoFinale;
	}

	
	

	/**
	 * <EM>N.B. UTILE PER STAMPARE RISULTATI DOMANDA 3</EM>
	 */
	private void stampaStatistiche(final Map<Integer, Set<Contatto>> mappa) {
		for(Object key : mappa.keySet()) {
			final Set<Contatto> l = mappa.get(key);
			System.out.print(key + " è stato coinvolto in :");
			for(Contatto c : l) 
				System.out.print(c.toString() + " ");
			System.out.println();
		}
	}
}
