package prop.pers;

import static prop.gui.CostantiGUI.RISORSA_IMMAGINE_BIANCO;
import static prop.gui.LettoreImmagini.leggiImmagineOggetto;

import java.awt.Image;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import prop.gui.CostantiGUI;
import prop.gui.LettoreImmagini;
import prop.sim.Ambiente;
import prop.sim.Contatto;
import prop.sim.Coordinate;
import prop.sim.GeneratoreCasuale;

public class NonPredicatore extends Persona{

	static final private Image IMMAGINE_BIANCA = leggiImmagineOggetto(RISORSA_IMMAGINE_BIANCO);
	static private int progId=0;
	
	
	private Coordinate posizione;
	private int Id=0;    

	public NonPredicatore(Ambiente ambiente) {		
		super (ambiente,IMMAGINE_BIANCA);
		this.posizione = GeneratoreCasuale.posizioneCasuale();
		this.setId(progId++);
	}

	

	public void mossa() {
		
		List<Coordinate> adiacenti = new LinkedList<>(this.getAmbiente().adiacentiA(this.getPosizione()));	
		double dist = 0;
		
		Coordinate cc = null;
		for(Coordinate c : adiacenti) {
			if(Coordinate.distanza(c, this.getAmbiente().getpredicatorePiuVicino(this.getPosizione()))>dist) {
				dist = Coordinate.distanza(c, this.getAmbiente().getpredicatorePiuVicino(this.getPosizione()));
				cc = c;
			}
		}
		this.setPosizione(cc);
		
		
}
		

		
	

	

	public void avvenuto(Contatto contatto) {
		Set <Persona>coinvolti=contatto.getCoinvolti();
		for(Persona p:coinvolti) {
			if(p.getClass().equals(Predicatore.class)) {
				if(GeneratoreCasuale.siVerificaEventoDiProbabilita(CostantiGUI.PROBABILITA_CONVERSIONE)) {
					Image img_giallo=LettoreImmagini.leggiImmagineOggetto(CostantiGUI.RISORSA_IMMAGINE_GIALLO);
					this.setIMMAGINE(img_giallo);
				}
			}
		}
	}



	public static int getProgId() {
		return progId;
	}



	public static void setProgId(int progId) {
		NonPredicatore.progId = progId;
	}
	@Override
	public String toString() {
		return NonPredicatore.class.getSimpleName()+getId();
	}



	public int getId() {
		return Id;
	}



	public void setId(int id) {
		Id = id;
	}


	

}
