package prop.pers;




import java.awt.Image;

import prop.sim.Ambiente;
import prop.sim.Contatto;
import prop.sim.Coordinate;
import prop.sim.GeneratoreCasuale;

public abstract class Persona {
	 private Image IMMAGINE;
	
	


	private Ambiente ambiente;
	private Coordinate posizione;    // posizione corrente
	public Persona(Ambiente a,Image img) {
		this.ambiente = a;
		this.posizione = GeneratoreCasuale.posizioneCasuale();
		
		setIMMAGINE(img);
	}

	

	public Ambiente getAmbiente() {
		return this.ambiente;
	}

	

	

	public Coordinate getPosizione() {
		return this.posizione;
	}

	public void setPosizione(Coordinate nuova) {
		this.posizione = nuova;
	}

	public abstract void mossa();

	

	public void avvenuto(Contatto contatto) {
		// ( VEDI DOMANDA 2b ) 
		// Metodo invocato ogni qual volta avviene un Contatto con questa
	}



	public Image getIMMAGINE() {
		return IMMAGINE;
	}
	


	public void setIMMAGINE(Image iMMAGINE) {
		IMMAGINE = iMMAGINE;
	}

}


