package prop.pers;

import static prop.gui.CostantiGUI.*;
import static prop.gui.LettoreImmagini.leggiImmagineOggetto;

import java.awt.Image;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import prop.sim.Ambiente;
import prop.sim.Coordinate;
import prop.sim.GeneratoreCasuale;

public class Predicatore extends Persona{

	static final private Image IMMAGINE_ROSSA = leggiImmagineOggetto(RISORSA_IMMAGINE_ROSSO);
	 private static int progId;
	private Coordinate posizione;    // posizione corrente
	private int Id=0;
	
	public Predicatore(Ambiente ambiente) {		
		super(ambiente,IMMAGINE_ROSSA);
		this.posizione = GeneratoreCasuale.posizioneCasuale();
		this.setId(progId++);
		
	}
	public void mossa() {
		List<Coordinate> adiacenti = new LinkedList<>(this.getAmbiente().adiacentiA(this.getPosizione()));
		Coordinate def=new Coordinate(0,0);
		double dist=0;
		List<Persona> tutte=this.getAmbiente().getAllPersone();
		for(Persona p: tutte) {
			
			Coordinate c1=this.getPosizione();
			Coordinate c2=p.getPosizione();
			if(Coordinate.distanza(c1, c2)>dist&&!this.getClass().equals(p.getClass())) {
				dist=Coordinate.distanza(c1, c2);
				def=c2;
			}
		}
		
		Coordinate cc = null;
		for (Coordinate a:adiacenti) {
			
		double dist1=Coordinate.distanza(this.getPosizione(), def);
			if(Coordinate.distanza(a,def)<dist1) {
				dist1=Coordinate.distanza(a,def);
//				this.setPosizione(a);
				cc=a;
			}
		}
		this.setPosizione(cc);

	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	@Override
	public String toString() {
		return Predicatore.class.getSimpleName()+getId();
	}

	

}
