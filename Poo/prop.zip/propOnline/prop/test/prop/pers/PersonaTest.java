package prop.pers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import prop.pers.NonPredicatore;
import prop.pers.Predicatore;
import prop.sim.Ambiente;

/** 
 * Suggerimento: Controllare che questi test abbiano successo sia
 * prima che dopo aver operato le modifiche suggerite<BR/>
 * RIVEDERE {@link #testIdProgressiviPerSani()}<BR/>
 * COMPLETARE {@link #testIdProgressiviPerSaniEInfetti()}<BR/>
 * <B>(VEDI DOMANDA 2)</B>
 */
public class PersonaTest {

	private Ambiente ambiente;
	NonPredicatore Np1;
	NonPredicatore Np2;
	NonPredicatore Np3;
	Predicatore P1;
	@Before
	public void setUp() throws Exception {
		this.ambiente = new Ambiente();
				
	}

	@Test
	public void testIdProgressiviPerPersoneStessoTipo() {
		// DA RIVEDERE VEDI DOMANDA 2a
		this.Np1=new NonPredicatore(this.ambiente);
		this.Np2=new NonPredicatore(this.ambiente);

		assertEquals("Gli id sono progressivi base 0", 0, Np1.getId());
		assertEquals("Gli id sono progressivi base 0", 1, Np2.getId());
		NonPredicatore.setProgId(0);
	}

	@Test
	public void testIdProgressiviPerPersoneTipoDiverso() {
		this.Np3=new NonPredicatore(this.ambiente);
		this.P1=new Predicatore(this.ambiente);
		
		assertEquals("Gli id sono progressivi base 0", 0, Np3.getId());
		assertEquals("Gli id sono progressivi base 0", 0, P1.getId());
	}

}
