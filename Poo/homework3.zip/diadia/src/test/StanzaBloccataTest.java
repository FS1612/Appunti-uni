package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.ambienti.StanzaBloccata;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class StanzaBloccataTest {
Stanza stanza;
StanzaBloccata bloccata;
Attrezzo spada;
	@Before
	public void setUp() throws Exception {
		stanza= new Stanza("stanza");
		bloccata= new StanzaBloccata("bloccata","sud","spada");
		spada= new Attrezzo("spada",3);
		stanza.impostaStanzaAdiacenteMappa("nord", bloccata);
	}

	@Test
	public void DescrizioneConSbloccante() {
		bloccata.addAttrezzoListe(spada);
		assertEquals("bloccata\n"
				+ "Uscite:  \n"
				+ "Attrezzi nella stanza: spada (3kg)",bloccata.getDescrizione());
	}
	@Test
	public void DescrizioneSenzaSbloccante() {
		
		assertEquals("stanza bloccata",bloccata.getDescrizione());
	}

}
