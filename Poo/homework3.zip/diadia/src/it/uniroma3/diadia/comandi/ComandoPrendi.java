package it.uniroma3.diadia.comandi;

import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class ComandoPrendi implements Comandi {



private String parametro;
private String Nome ="Prendi";
private IO io;
	public ComandoPrendi() {
		// TODO Auto-generated constructor stub
	}


	/***********************************lista*************************/
	
	@Override
	public void esegui(Partita partita) {
		
		
		Stanza StanzaCorrente=partita.getStanzaCorrente();
		
		if(StanzaCorrente.hasAttrezzoListe(parametro)) {
			Attrezzo Darimuovere=StanzaCorrente.getAttrezzoListe(parametro);
			
			
	if(	partita.GetGiocatore().GetBorsa().addAttrezzoLista(Darimuovere)) {
		StanzaCorrente.removeAttrezzoListe(Darimuovere);
	}
	
		
		this.io.mostraMessaggio("Cfu Attuali:"+"\t"+partita.getCfu()+"\n"+"ti trovi in:"+"\n"+StanzaCorrente
				+"\n"+partita.GetGiocatore().GetBorsa().toString());
		}
		else {
		this.io.mostraMessaggio("Attrezzo "+this.parametro+ " non presente nella stanza, scegli uno strumento valido");
 	   this.io.mostraMessaggio("Cfu Attuali:"+"\t"+partita.getCfu()+"\n"+"ti trovi in:"+"\n"+StanzaCorrente
				+"\n"+partita.GetGiocatore().GetBorsa().toString());
		}
		}
	
	/***********************************lista*************************/
	@Override
	public void setParametro(String parametro) {
		this.parametro=parametro;

	}

	@Override
	public String getNome() {
		
		return this.Nome;
	}

	@Override
	public String getParametro() {
		
		return this.parametro;
	}

	@Override
	public void SetIO(IO Io) {
		this.io=Io;

	}

}
