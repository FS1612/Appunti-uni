package it.uniroma3.diadia.comandi;

import it.uniroma3.diadia.IO;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.ambienti.StanzaBloccata;

public class ComandoVai implements Comandi {
 private String direzione;
	private IO io;
	private  String NOME="vai";

	@Override
	public void esegui(Partita partita) {
		Stanza StanzaCorrente =partita.getStanzaCorrente();
		Stanza Prossima=null;
		
	if(this.direzione==null) {
		this.io.mostraMessaggio("dove vuoi andare?");
		return;
	}
	
	Prossima=StanzaCorrente.getStanzaAdiacenteMappa(this.direzione);
	

	if(Prossima==null) {
		this.io.mostraMessaggio(partita.getStanzaCorrente().getDescrizione());
		this.io.mostraMessaggio("Non Puoi Andare li: direzione inesistente"+"\n"+partita.getStanzaCorrente().getDescrizione());
		
	}
	else if(Prossima.getDescrizione().equals("stanza bloccata")){
		StanzaBloccata Stanzabloccata =(StanzaBloccata) Prossima;
		this.io.mostraMessaggio(Stanzabloccata.getDescrizione());
		io.mostraMessaggio("Ti trovi ancora in:"+"\n"+partita.getStanzaCorrente().getDescrizione()+
				"\n"+"Hai "+partita.GetGiocatore().GetCfu()+" cfu"+"\n"+partita.GetGiocatore().GetBorsa().toString());
	}
	
	else {
		partita.setStanzaCorrente(Prossima);
		
		int cfu=partita.GetGiocatore().GetCfu();
		partita.GetGiocatore().SetCfu(cfu-1);
		io.mostraMessaggio("Ti trovi in:"+"\n"+partita.getStanzaCorrente().getDescrizione()+
				"\n"+"Hai "+partita.GetGiocatore().GetCfu()+" cfu"+"\n"+partita.GetGiocatore().GetBorsa().toString());
		
	}
		
	}

	@Override
	public void setParametro(String parametro) {
		this.direzione=parametro;
		
	}

	
	public String getNome() {
		
		return this.NOME;
	}

	
	public String getParametro() {
		
		return this.direzione;
	}
	
	public void SetIO(IO Io) {
		this.io=Io;
		
	}

}
