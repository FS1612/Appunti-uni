package it.uniroma3.diadia.comandi;

import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.Partita;

public class ComandoAiuto implements Comandi {
private IO io;
private String parametro;
private String NOME= "aiuto";
static final private String[] elencoComandi = {"vai", "aiuto", "fine","prendi","posa"+"guarda"};
	public ComandoAiuto() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void esegui(Partita partita) {
		this.io.mostraMessaggio("comandi a disposizione : " );
		for(int i=0; i< elencoComandi.length; i++) 
			this.io.mostraMessaggio(elencoComandi[i]+" ");
			this.io.mostraMessaggio("\n");
	}

	@Override
	public void setParametro(String parametro) {
		this.parametro=parametro;

	}

	@Override
	public String getNome() {
		
		return this.NOME;
	}

	@Override
	public String getParametro() {
		
		return this.parametro;
	}

	@Override
	public void SetIO(IO Io) {
		this.io=Io;

	}

}
