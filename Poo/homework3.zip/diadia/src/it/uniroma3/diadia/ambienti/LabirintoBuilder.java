package it.uniroma3.diadia.ambienti;

import java.util.Iterator;
import java.util.LinkedList;



import it.uniroma3.diadia.attrezzi.Attrezzo;

public class LabirintoBuilder implements Labirinto {
	private Stanza Ingresso;
	private Stanza Fine;
	private Stanza Corrente;
	private LinkedList<Stanza> labirintoCostruito;
	public LabirintoBuilder() {
		CreaStanze();
	}

	@Override
	public void CreaStanze() {
		labirintoCostruito= new LinkedList<Stanza>();

	}
	
	public LabirintoBuilder AddIniziale(String i) {
		
		this.Ingresso=new Stanza(i);
		this.Corrente=Ingresso;
		this.labirintoCostruito.add(Ingresso);
		return this;
	}
public LabirintoBuilder AddFinale(String f) {
		
		this.Fine=new Stanza(f);

		this.labirintoCostruito.add(Fine);
		return this;
	}
public LabirintoBuilder addAttrezzo(String nomeAttrezzo,int peso) {
	if(labirintoCostruito.isEmpty() ) 
		this.Fine.addAttrezzoListe(new Attrezzo(nomeAttrezzo,peso));
	else 
			labirintoCostruito.get(labirintoCostruito.size()-1).addAttrezzoListe(new Attrezzo(nomeAttrezzo,peso));
	return this;
	}
public LabirintoBuilder addStanza(String nomeStanza) {
	Stanza nuovaStanza=new Stanza(nomeStanza);
	labirintoCostruito.add(nuovaStanza);

	return this;
}
public LabirintoBuilder addAdiacenza(String nomeStanza, String nomeAdiacenza, String direzione) {
	
	this.GetStanza(nomeStanza);
	
	int index=labirintoCostruito.indexOf(this.GetStanza(nomeStanza));
	

	Stanza stanza= labirintoCostruito.get(index);
	index=labirintoCostruito.indexOf(this.GetStanza(nomeAdiacenza));

	Stanza stanzaAdiacente=labirintoCostruito.get(index);
	if(stanza!=null && stanzaAdiacente!=null) {
		stanza.impostaStanzaAdiacenteMappa(direzione, stanzaAdiacente);
		stanzaAdiacente.impostaStanzaAdiacenteMappa(getDirezioneOpposta(direzione), stanza);
	}

		
		
		

	
	
	return this;

}
private String getDirezioneOpposta(String direzione) {
	if(direzione=="nord")
		return "sud";
	if(direzione=="sud")
		return "nord";
	if(direzione=="est")
		return "ovest";
	return "est";
}
	@Override
	public Stanza GetStanzaIniziale() {
		
		return this.Ingresso;
	}

	@Override
	public void SetStanzaIniziale(Stanza c) {
		this.Ingresso=c;

	}

	@Override
	public void SetStanzaCorrente(Stanza c) {
		this.Corrente=c;

	}

	@Override
	public Stanza GetStanzaCorrente() {
		
		return this.Corrente;
	}

	@Override
	public void SetStanzaVincente(Stanza v) {
		this.Fine=v;

	}

	@Override
	public Stanza GetStanzaVincente() {
		
		return this.Fine;
	}
	public LabirintoBuilder AddStanzaMagica(String m,int soglia) {
		Stanza magica =new StanzaMagica(m,soglia);
		this.labirintoCostruito.add(magica);
		return this;
	}
	public LabirintoBuilder AddStanzaBloccata(String m,String direzione, String attrezzo) {
		Stanza Bloccata =new StanzaBloccata(m,direzione, attrezzo);
		this.labirintoCostruito.add(Bloccata);
		return this;
	}
	public LabirintoBuilder AddStanzaBuia(String oggetto,String nome) {
		Stanza Buia =new StanzaBuia(oggetto, nome);
		this.labirintoCostruito.add(Buia);
		return this;
	}
	public Labirinto GetLabirinto() {
		return this; //* perche solo this?
	}
	public Stanza GetStanza(String s) {
		Stanza ricercata=null;
		Iterator<Stanza> it= labirintoCostruito.iterator();
		while(it.hasNext()) {
			Stanza Corrente=it.next();
			if(Corrente.getNome().equals(s)) {
				ricercata=Corrente;
			}
		}
		return ricercata;
	}

}
