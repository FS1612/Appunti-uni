package it.uniroma3.diadia.ambienti;

public interface Labirinto {
public void CreaStanze();
public Stanza GetStanzaIniziale();
public void SetStanzaIniziale(Stanza c);
public void SetStanzaCorrente(Stanza c);
public Stanza GetStanzaCorrente();
public void SetStanzaVincente(Stanza v);
public Stanza GetStanzaVincente();
}
