/**
 * 
 */
package it.uniroma3.diadia.ambienti;

import it.uniroma3.diadia.attrezzi.Attrezzo;

/**
 * @author francesco
 *
 */
public class LabirintoPredefinito implements Labirinto{
	private Stanza StanzaIniziale;
	
	private Stanza stanzaCorrente;
	private Stanza stanzaVincente;
	public LabirintoPredefinito () {

		CreaStanze();
	}

	@Override
	public void CreaStanze() {
		/* crea stanze del labirinto */
		Stanza atrio = new Stanza("Atrio");
		Stanza aulaN11 = new Stanza("Aula N11");
		Stanza aulaN10 = new Stanza("Aula N10");
		Stanza laboratorio = new Stanza("Laboratorio Campus");
		Stanza biblioteca = new Stanza("Biblioteca");
		/**********************************per test***********************************************/
		StanzaBloccata prezzemolo =new StanzaBloccata("prezzemolo","sud","dinamite");
		/* collega le stanze */
		atrio.impostaStanzaAdiacenteMappa("nord", biblioteca);
		atrio.impostaStanzaAdiacenteMappa("est", aulaN11);
		atrio.impostaStanzaAdiacenteMappa("sud", aulaN10);
		atrio.impostaStanzaAdiacenteMappa("ovest", laboratorio);
		aulaN11.impostaStanzaAdiacenteMappa("est", laboratorio);
		aulaN11.impostaStanzaAdiacenteMappa("ovest", atrio);
		aulaN10.impostaStanzaAdiacenteMappa("nord", atrio);
		aulaN10.impostaStanzaAdiacenteMappa("est", aulaN11);
		aulaN10.impostaStanzaAdiacenteMappa("ovest", laboratorio);
		laboratorio.impostaStanzaAdiacenteMappa("est", atrio);
		laboratorio.impostaStanzaAdiacenteMappa("ovest", aulaN11);
		biblioteca.impostaStanzaAdiacenteMappa("sud", atrio);
		/* pone gli attrezzi nelle stanze */
		Attrezzo lanterna =new Attrezzo("lanterna",10);
		Attrezzo osso =new Attrezzo("osso",1);
		
		Attrezzo attrezzo1 =new Attrezzo("attrezzo1",4);
		Attrezzo attrezzo2 =new Attrezzo("attrezzo2",14);
		
		
		
		aulaN10.addAttrezzoListe(lanterna);

		atrio.addAttrezzoListe(osso);
		atrio.addAttrezzoListe(attrezzo1);
		atrio.addAttrezzoListe(attrezzo2);
		// il gioco comincia nell'atrio
		stanzaCorrente = atrio;  
		stanzaVincente = biblioteca;
		StanzaIniziale=atrio;
	}

	public Stanza GetStanzaIniziale() {
		return this.StanzaIniziale;
	}
	public void SetStanzaIniziale(Stanza c) {
		 this.StanzaIniziale=c;
	}
	
	public void SetStanzaCorrente(Stanza c) {
		 this.stanzaCorrente=c;
	}
	public Stanza GetStanzaCorrente() {
		return this.stanzaCorrente;
	}
	public void SetStanzaVincente(Stanza v) {
		 this.stanzaVincente=v;
	}
	public Stanza GetStanzaVincente() {
		return this.stanzaVincente;
	}
	public boolean GetVinta() {
		return this.GetStanzaCorrente()== this.GetStanzaVincente();
		
	}


	
}
