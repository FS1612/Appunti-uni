package it.uniroma3.diadia.ambienti;

public class StanzaBloccata extends Stanza{

	private String DirezioneBloccata;
	private String AttrezzoSblocco;
	public StanzaBloccata(String nome, String direzione, String attrezzo) {
		super(nome);
		this.DirezioneBloccata=direzione;
		this.AttrezzoSblocco=attrezzo;
	}
@Override
public Stanza getStanzaAdiacente(String direzione) {

	if(!CalcolaDirezione( direzione).equals(DirezioneBloccata))
    	return super.getStanzaAdiacenteMappa(direzione);
    else
    	
    return  this;
}
@Override
public String getDescrizione() {
	if(super.hasAttrezzoListe(AttrezzoSblocco)) 
		return super.getDescrizione();
	else  
	return "stanza bloccata";
}
private String CalcolaDirezione(String dir) {
	String risultato=new String();
	if(dir.equals("nord")) {
		risultato="sud"; 
	}
	else if(dir.equals("sud")) {
		risultato="nord"; 
	}
	else if(dir.equals("est")) {
		risultato="ovest"; 
	}
	if(dir.equals("ovest")) {
		risultato="est"; 
	}
	return risultato;
}
}
