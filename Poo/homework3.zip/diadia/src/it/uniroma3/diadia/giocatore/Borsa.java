/**
 * 
 */
package it.uniroma3.diadia.giocatore;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.attrezzi.ComparatorePerPeso;
import it.uniroma3.diadia.attrezzi.ComparatorePrimaPesoPoiNome;
import it.uniroma3.diadia.attrezzi.ComparatoreperNome;

/**
 * @author francesco
 *
 */
public class Borsa {
	public final static int DEFAULT_PESO_MAX_BORSA = 10;

	private int numeroAttrezzi;
	private int pesoMax;
	private List <Attrezzo>AttrezziLista =new ArrayList <Attrezzo>(); 
	public Borsa() {
		this(DEFAULT_PESO_MAX_BORSA);
	}
	public Borsa(int pesoMax) {
		
		this.pesoMax = pesoMax;

		this.numeroAttrezzi = 0;
	}

	public int getPesoMax() {
		return pesoMax;
	}

	public boolean isEmpty() {
		return this.numeroAttrezzi == 0;
	}

	/********************************************************Liste******************************/
	public boolean addAttrezzoLista(Attrezzo attrezzo) {
		if (this.getPesoListe() + attrezzo.getPeso() > this.getPesoMax())
			return false;	
		else 
			this.numeroAttrezzi++;
		
		return this.AttrezziLista.add(attrezzo);
	}
	public Attrezzo getAttrezzoLista(String nomeAttrezzo) {
		
		 Iterator <Attrezzo> it =this.AttrezziLista.iterator();
		 while(it.hasNext()) {
			 Attrezzo Trovato =it.next();
			 if(Trovato.getNome().equals(nomeAttrezzo)) {
				 return Trovato;
			 }
		 }
		return null;
	}
	public boolean hasAttrezzoLista(String nomeAttrezzo) {
		
		return this.getAttrezzoLista(nomeAttrezzo)!=null;
	}
	
	
	
	public Attrezzo removeAttrezzoLista(String nomeAttrezzo) {
		Attrezzo c = null;
		Attrezzo a=this.getAttrezzoLista(nomeAttrezzo);
		
		if(AttrezziLista.contains(a)) {
			c=a;
			AttrezziLista.remove(a);
			this.numeroAttrezzi--;
				}
			

		return c;
	}
	public String toString() {
		StringBuilder s = new StringBuilder();
		if (!this.isEmpty()) {
			s.append("Contenuto borsa ("+this.getPesoListe()+"kg/"+this.getPesoMax()+"kg): ");
			Iterator <Attrezzo> it =this.AttrezziLista.iterator();
		while(it.hasNext()) {
				Attrezzo Corrente =it.next();
				s.append(Corrente.toString());

			s.append("\s");

			}
		}
		else 
			s.append("Borsa vuota");
		return s.toString();
	}
	public int getPesoListe() {
		int peso = 0;
		Iterator <Attrezzo> it =this.AttrezziLista.iterator();
		while(it.hasNext()) {
			Attrezzo Corrente =it.next();
			peso += Corrente.getPeso();
		}
			
		return peso;
	}
	List<Attrezzo> getContenutoOrdinatoPerPeso(){
		
	ComparatorePerPeso comp=new ComparatorePerPeso();
	Collections.sort(this.AttrezziLista,comp);
	return this.AttrezziLista;
	}
	public SortedSet<Attrezzo> getContenutoOrdinatoPerNome(){
		ComparatoreperNome comp=new ComparatoreperNome();
		TreeSet<Attrezzo> setOrdinato= new TreeSet<Attrezzo>(comp);//* ordina gli oggetti in base all'ordinamento scelto da un comparatore passato come secondo parametro
		setOrdinato.addAll(this.AttrezziLista);
		return setOrdinato;
	}
	public SortedSet<Attrezzo> getSortedSetOrdinatoPerPeso(){
		ComparatorePrimaPesoPoiNome comp=new ComparatorePrimaPesoPoiNome();
		TreeSet<Attrezzo> tmpSortedSet=new TreeSet<Attrezzo>(comp);
		tmpSortedSet.addAll(this.AttrezziLista);
		return tmpSortedSet;
	
	}
	public Map<Integer,Set<Attrezzo>> getContenutoRaggruppatoPerPeso(){
		Set<Attrezzo> tmp;
		ComparatoreperNome comp=new ComparatoreperNome();
		Map<Integer,Set<Attrezzo>> contenuto;
		contenuto= new HashMap<Integer,Set<Attrezzo>>();
		for(Attrezzo attrezzo:this.AttrezziLista) {
			if(contenuto.containsKey(attrezzo.getPeso())){
				tmp=contenuto.get(attrezzo.getPeso());
				tmp.add(attrezzo);
			}
			else {
				tmp=new TreeSet<Attrezzo>(comp);
				tmp.add(attrezzo);
				contenuto.put(attrezzo.getPeso(), tmp);
			}
		}
		
		return contenuto;
	}
	private String FormattaStringheListeOggetti() {
		StringBuilder s= new StringBuilder();
		Iterator<Attrezzo> it= getContenutoOrdinatoPerPeso().iterator();
		s.append("[ ");
		while(it.hasNext()) {
			Attrezzo a=it.next();
			s.append(a.getNome());
			if(it.hasNext()) {
				s.append(", ");
			}
			else {
				s.append(" ");
			}
		}
		s.append("] ");
		return s.toString();
	}
	private String FormattaStringaSortedSet(SortedSet<Attrezzo> set) {
		StringBuilder s= new StringBuilder();
		Iterator<Attrezzo> it= set.iterator();
		s.append("{ ");
		while(it.hasNext()) {
			Attrezzo a=it.next();
			s.append(a.getNome());
			if(it.hasNext()) {
				s.append(", ");
			}
			else {
				s.append(" ");
			}
		}
		s.append("} ");
		return s.toString();
	}
	private String FormattaStringaMappe() {
		StringBuilder s= new StringBuilder();
		Map<Integer,Set<Attrezzo>> contenuto;
		
		contenuto=this.getContenutoRaggruppatoPerPeso();
Iterator<Map.Entry<Integer,Set<Attrezzo>>> it=contenuto.entrySet().iterator();
		while(it.hasNext()) {
			s.append("(");
			Map.Entry<Integer,Set<Attrezzo>> b = it.next();
			if(b.getKey()!=null) {
				s.append(b.getKey()+", ");
				int start=b.getValue().toString().indexOf("(", 2);
				int fine= b.getValue().toString().indexOf(")");
				String DaRimuovere=b.getValue().toString().substring(start, fine+1);
				String app=b.getValue().toString().replace("[", "").replace("]", "")
						.replace(DaRimuovere, "");
				s.append("{ "+app+"}");
			}
			s.append(" )");
			if(it.hasNext()) {
				s.append(" ; ");
				
			}
			else {
				s.append("");
			}
		}
			return s.toString();
		}
	public String DescrizioneListe() {
		StringBuilder s = new StringBuilder();
		if (!this.isEmpty()) {
			s.append("Contenuto borsa ("+this.getPesoListe()+"kg/"+this.getPesoMax()+"kg): ");
			
			s.append(FormattaStringheListeOggetti());

			s.append("\s");

			}
		
		else 
			s.append("Borsa vuota");
		return s.toString();
	}
	public String DescrizioneMappe() {
		StringBuilder s = new StringBuilder();
		if (!this.isEmpty()) {
			s.append("Contenuto borsa ("+this.getPesoListe()+"kg/"+this.getPesoMax()+"kg): ");
			

//			s.append(FormattaStringaSortedSet(getContenutoOrdinatoPerNome()));
			
			s.append(FormattaStringaMappe());
			s.append("\s");
			}
		
		else 
			s.append("Borsa vuota");
		return s.toString();
	}
	public String DescrizioneSet() {
		StringBuilder s = new StringBuilder();
		if (!this.isEmpty()) {
			s.append("Contenuto borsa ("+this.getPesoListe()+"kg/"+this.getPesoMax()+"kg): ");
			s.append(FormattaStringaSortedSet(getContenutoOrdinatoPerNome()));
			s.append("\s");
			}
		
		else 
			s.append("Borsa vuota");
		return s.toString();
	}
}
