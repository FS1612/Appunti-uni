package esame;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Cartella {
	private String nome;
	private String dataCreazione;
	private Map<String, PermessoAccesso> permessi;
	private Set<Documento> documenti;
		
	public Cartella(String nome, String dataCreazione, PermessoAccesso permessoAccesso) {
		this.nome = nome;
		this.dataCreazione = dataCreazione;
		this.permessi = new HashMap<String, PermessoAccesso>();
		this.permessi.put(permessoAccesso.getNome(), permessoAccesso);
		this.documenti = new HashSet<Documento>();
	}

	public String getDataCreazione() {
		return this.dataCreazione;
	}

	public String getNome() {
		return this.nome;
	}

	public int getDimensione() {
		int dimensioni = 0;
		// codice omesso: completare
		return dimensioni;
	}

	public PermessoAccesso getPermessoAccesso(String nomePermesso) {
		return this.permessi.get(nomePermesso);
	}
	
	public boolean addDocumento(Documento documento) {
		return this.documenti.add(documento);
	}
			
	/*	
	public List<Archivio> archiviCreatiIl(String data) {
		// codice omesso: domanda 5. 
	}
	*/
}
