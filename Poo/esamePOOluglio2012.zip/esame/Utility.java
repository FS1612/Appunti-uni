package esame;

import java.util.List;
import java.util.Map;

public class Utility {

	static public Map<Utente, List<Documento>> utente2docs(List<Documento> docs, String nomePermesso) {
		// codice omesso: domanda 4
		return null;
	}

}
