package esame;

import java.util.HashMap;
import java.util.Map;

public class Documento {
	private String nome;
	private int dimensione;
	private String dataCreazione;
	private Map<String, PermessoAccesso> permessi;
	
	public Documento(String nome, int dimensione, String dataCreazione, PermessoAccesso permessoAccesso) {
		this.nome = nome;
		this.dimensione = dimensione;
		this.dataCreazione = dataCreazione;
		this.permessi = new HashMap<String, PermessoAccesso>();
		this.permessi.put(permessoAccesso.getNome(), permessoAccesso);
	}

	public String getDataCreazione() {
		return this.dataCreazione;
	}

	public String getNome() {
		return this.nome;
	}

	public PermessoAccesso getPermessoAccesso(String nomePermesso) {
		return this.permessi.get(nomePermesso);
	}

	
	public int getDimensione() {
		return this.dimensione;
	}
		
	
	/*	
	public List<Archivio> archiviCreatiIl(String data) {
		// codice omesso: domanda 5. 
	}
	*/

}
