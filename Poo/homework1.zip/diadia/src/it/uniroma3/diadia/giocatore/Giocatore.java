/**
 * 
 */
package it.uniroma3.diadia.giocatore;

/**
 * @author francesco
 *
 */
public class Giocatore {
Borsa borsa;
private int cfu;
private int cfuMax = 20;
public Giocatore() {
	borsa = new Borsa();
	this.cfu=cfuMax;
}
public void SetCfu(int c) {
	this.cfu=c;
}
public int GetCfu() {
	return this.cfu;
}
public Borsa GetBorsa() {
	return this.borsa;
}
}
