package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class TestStanza {
private Stanza stanza1; 
private Stanza stanza2; 
private Stanza stanza3; 
private Stanza stanza4; 
private Stanza stanza5; 
private Stanza stanza6; 
private Stanza stanza7;
private Stanza stanza8;
private Stanza stanza9;
private Stanza stanza10;
private Attrezzo zappa;
private Attrezzo vanga;
private Attrezzo martello;
private Attrezzo piccone;
private Attrezzo spazzola;

	@Before
	public void setUp() throws Exception {
		 stanza1=new Stanza("stanza1"); 
		 stanza2=new Stanza("stanza2"); 
		 stanza3=new Stanza("stanza3"); 
		 stanza4=new Stanza("stanza4"); 
		 stanza5=new Stanza("stanza5"); 
		 stanza6=new Stanza("stanza6");
		 stanza7=new Stanza("stanza7");
		 stanza8=new Stanza("stanza8");
		 stanza9=new Stanza("stanza9");
		 stanza10=new Stanza("stanza10");
		 zappa= new Attrezzo("zappa",3);
		 vanga= new Attrezzo("vanga",10);
		 martello= new Attrezzo("martello",20);
		 piccone = new Attrezzo("piccone",60);
		 spazzola=new Attrezzo ("spazzola",5);
		 stanza3.addAttrezzo(vanga);
		 stanza4.addAttrezzo(zappa);
		 stanza5.addAttrezzo(martello);
		 stanza6.addAttrezzo(piccone);
		 stanza7.addAttrezzo(spazzola);
		 stanza9.impostaStanzaAdiacente("est", stanza1);
		 stanza10.impostaStanzaAdiacente("ovest",stanza9);
		 stanza10.impostaStanzaAdiacente("est",stanza8);
		 stanza10.impostaStanzaAdiacente("sud",stanza7);
		 stanza10.impostaStanzaAdiacente("nord",stanza3);
	}
		
	@Test
	public void StanzaToString() {

		assertEquals("stanza1\n"
				+ "Uscite: \n"
				+ "Attrezzi nella stanza: ",stanza1.toString());
	}
	@Test
	public void StanzaGetDescrizione() {
		
		assertEquals("stanza2\n"
				+ "Uscite: \n"
				+ "Attrezzi nella stanza: ",stanza2.getDescrizione());
	}
	@Test
	public void StanzaGetDescrizioneConAttrezzi() {
		
		assertEquals("stanza3\n"
				+ "Uscite: \n"
				+ "Attrezzi nella stanza: vanga (10kg) ",stanza3.getDescrizione());
	}
	@Test
	public void StanzaGetDescrizioneConDirezioni() {
		stanza3.impostaStanzaAdiacente("est", stanza2);
		assertEquals("stanza3\n"
				+ "Uscite:  est\n"
				+ "Attrezzi nella stanza: vanga (10kg) ",stanza3.getDescrizione());
	}
	@Test
public void StanzaGetAttrezzi() {
		
		assertEquals( this.zappa ,stanza4.getAttrezzo("zappa"));
	}
	@Test
	public void StanzaGetAttrezziAttrezzoSbagliato() {
			
			assertEquals( null,stanza4.getAttrezzo("piccone"));
		}
	@Test
public void StanzaRemoveAttrezzo() {
		
		assertTrue( stanza5.removeAttrezzo(martello)==true);
	}
	@Test
	public void StanzaRemoveAttrezzosenzaAttrezzo() {
			
			assertFalse( stanza6.removeAttrezzo(martello)==true);
		}
	@Test
	public void StanzaHasAttrezzo() {
			
			assertTrue( stanza7.hasAttrezzo("spazzola"));
		}
	@Test
	public void StanzaHasAttrezzoConAttrezzoSbagliato() {
		
		assertFalse( stanza7.hasAttrezzo("piccone"));
	}
	@Test
	public void StanzaSetAdiacenza() {
		stanza8.impostaStanzaAdiacente("ovest", stanza9);
		assertEquals(stanza9,stanza8.getStanzaAdiacente("ovest"));
	}
	@Test
	public void StanzaSetAdiacenzaStanzaNull() {
		stanza8.impostaStanzaAdiacente("ovest", null);
		assertEquals(null,stanza8.getStanzaAdiacente("ovest"));
	}
	@Test
	public void StanzaSetAdiacenzaDirezioneInesistente() {
		stanza10.impostaStanzaAdiacente("nord-ovest", stanza5);
		assertEquals(null,stanza10.getStanzaAdiacente("nord-ovest"));
	}
	
	
}
