package test;

import static org.junit.Assert.assertEquals;


import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.ambienti.Labirinto;
import it.uniroma3.diadia.ambienti.Stanza;

public class TestLabirinto {

	@Before
	public void setUp() throws Exception {
//		Labirinto lab=new Labirinto();
//		Stanza atrio = new Stanza("Atrio");
//		lab.SetStanzaFinale(atrio);
	}

	@Test
	public void SetStanzaIniziale() {
		Labirinto lab=new Labirinto();
		Stanza atrio = new Stanza("Atrio");
		lab.SetStanzaIniziale(atrio);
		assertEquals(atrio,lab.GetStanzaIniziale());
		}
	
	@Test
	public void SetStanzaFinale() {
		Labirinto lab=new Labirinto();
		Stanza sala = new Stanza("Sala");
		lab.SetStanzaVincente(sala);
		assertEquals(sala,lab.GetStanzaVincente());
		
	}
	
}
