/**
 * 
 */
package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.Stanza;

/**
 * @author francesco
 *
 */
public class TestPartita {
	Partita partita;
private Stanza stanza1;
private Stanza stanza2;

private int cfu1;
private int cfu2;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		partita=new Partita();
		stanza1=new Stanza("stanza1");
		stanza2=new Stanza("stanza2");
	
		cfu2=0;
		cfu1=20;
		this.partita.SetStanzaVincente(stanza1);
	}

	@Test
	public void GetStanzaVincente() {
		
		
		assertEquals(stanza1,this.partita.getStanzaVincente());
	}
	@Test
	public void GetStanzaCorrente() {
		this.partita.setStanzaCorrente(stanza1);
		assertEquals(stanza1,this.partita.getStanzaCorrente());
	}
	@Test 
	public void VittoriaPerStanza() {
		this.partita.setStanzaCorrente(stanza1);
		assertTrue(this.partita.vinta());
	}
	@Test
	public void Vittoria0Cfu() {
		this.partita.setCfu(cfu2);
		assertTrue(this.partita.isFinita());
	}
	@Test
	public void Vittoria0CfuStanzaDiversa() {
		this.partita.setCfu(cfu2);
		this.partita.setStanzaCorrente(stanza2);
		assertTrue(this.partita.isFinita());
	}
	@Test
	public void Vittoria20CfuStanzaCorrente() {
		this.partita.setCfu(cfu1);
		this.partita.setStanzaCorrente(stanza1);
		assertTrue(this.partita.isFinita());
	}
	@Test
	public void Vittoria0CfuStanzaCorrente() {
		this.partita.setCfu(cfu2);
		this.partita.setStanzaCorrente(stanza1);
		assertTrue(this.partita.isFinita());
	}
	@Test
	public void VittoriaPerQuit() {
		this.partita.setFinita();
		
		assertTrue(this.partita.isFinita());
	}
}
