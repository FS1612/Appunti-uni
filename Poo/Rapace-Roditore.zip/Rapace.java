import java.util.List;

public class Rapace {
	private static int PESO_RAPACE = 5;
	private int anni;
	private int peso;
	private Posizione posizione;
	private static double PROBABILITA_RIPRODUZIONE = 0.45;
	private int cibo;

	public Rapace(){
		this(PESO_RAPACE);
	}

	private Rapace(int peso){
		this.peso = peso;
		this.cibo = 2;
		this.anni = 0;
	}

	public void agisci(Parco parco) {
		if (this.isMorto()) {
			parco.eliminaRapace(this);
			return;
		}
		this.riproduci(parco);

		Posizione nuovaPosizione;
		Roditore roditore;
		roditore = trovaRoditore(parco);
		if (roditore != null) {
			this.incrementaCibo(1);
			parco.eliminaRoditore(roditore);
			nuovaPosizione = roditore.getPosizione();
		} else {
			Rapace rapace;
			rapace = rapacePiuDebole(parco);
			if (rapace != null) {
				this.incrementaCibo(1);
				parco.eliminaRapace(rapace);
				nuovaPosizione = rapace.getPosizione();
			} else {
					this.incrementaCibo(-1);
					nuovaPosizione = parco.posizioneLiberaVicino(this.getPosizione());
			}
		}
		if (nuovaPosizione!=null){
			parco.muovi(this, nuovaPosizione);
		}
		this.invecchia();
	}

	private Roditore trovaRoditore(Parco parco) {
		List<Posizione> adiacenti = parco.adiacenti(this.getPosizione());
		for(Posizione p : adiacenti) {
			Roditore r = parco.getRoditore(p);
			if ((r!=null) && (this.getPeso()>r.getPeso())) {
				return r;
			}
		}
		return null;
	}

	private Rapace rapacePiuDebole(Parco parco) {
		List<Posizione> adiacenti = parco.adiacenti(this.getPosizione());
		for(Posizione p : adiacenti) {
			Rapace s = parco.getRapace(p);
			if ((s!=null) && (this.getPeso()>s.getPeso())) {
				return s;
			}
		}
		return null;
	}

	public void riproduci(Parco parco) {
		Double random = Math.random();
		Posizione pos = parco.posizioneLiberaVicino(this.posizione);

		if ((pos!= null) && (PROBABILITA_RIPRODUZIONE > random)) {
			Rapace figlio = this.creaFiglio();
			parco.setRapace(figlio, pos);
		}
	}

	public Rapace creaFiglio() {
		return new Rapace();
	}

	public void setPosizione(Posizione posizione){
		this.posizione = posizione;
	}

	public Posizione getPosizione() {
		return this.posizione;
	}

	public int getPeso() {
		return this.peso;
	}

	public int getAnni() {
		return this.anni;
	}

	public boolean isMorto(){
		return (this.cibo==0)||(this.anni==5);
	}

	public void invecchia(){
		this.anni++;
	}

	public void incrementaCibo(int cibo){
		this.cibo+=cibo;
	}
}

