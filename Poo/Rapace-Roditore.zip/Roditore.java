public class Roditore {
	private static int PESO_RODITORE = 2;
	private int anni;
	private int peso;
	private Posizione posizione;
	private static double PROBABILITA_RIPRODUZIONE = 0.45;
	private int cibo;

	public Roditore(){
		this(PESO_RODITORE);
	}

	private Roditore(int peso){
		this.peso = peso;
		this.cibo = 2;
		this.anni = 0;
	}

	public void agisci(Parco parco) {
		if (this.isMorto()) {
			parco.eliminaRoditore(this);
			return;
		}
		this.riproduci(parco);

		Posizione nuovaPosizione;
		nuovaPosizione = parco.posizioneLiberaVicino(this.getPosizione());
		if (nuovaPosizione!=null){
			this.incrementaCibo(1);
			parco.muovi(this, nuovaPosizione);
		} else {
			this.incrementaCibo(-1);
		}
		this.invecchia();
	}

	public void riproduci(Parco parco) {
		Double random = Math.random();
		Posizione posizioneFiglio = parco.posizioneLiberaVicino(this.posizione);

		if ((posizioneFiglio!= null) && (PROBABILITA_RIPRODUZIONE > random)) {
			Roditore figlio = this.creaFiglio();
			parco.setRoditore(figlio, posizioneFiglio);
		}
	}

	public Roditore creaFiglio() {
		return new Roditore();
	}

	public void setPosizione(Posizione posizione){
		this.posizione = posizione;
	}

	public Posizione getPosizione() {
		return this.posizione;
	}

	public int getPeso() {
		return this.peso;
	}

	public int getAnni() {
		return this.anni;
	}

	public boolean isMorto(){
		return (this.cibo==0)||(this.anni==5);
	}

	public void invecchia(){
		this.anni ++;
	}

	public void incrementaCibo(int cibo){
		this.cibo+=cibo;
	}
}

