package ama.simulatore;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import ama.Posizione;
import ama.mezzo.Mezzo;
import ama.rifiuto.Carta;
import ama.rifiuto.Rifiuto;
import ama.rifiuto.Vetro;

public class StatisticheTest {

	private Simulatore simulatore;

	private Statistiche stats;	
	private Set<Rifiuto> rifiuti;
	private Map<Mezzo, Integer> mappaMezzo;
	private Map <Class<?>,Integer> mappaPolitica;
	final static private Posizione ORIGINE = new Posizione(0, 0);
	
	@Before
	public void setUp() throws Exception {
		this.stats = new Statistiche();
		this.simulatore = new Simulatore();
		this.rifiuti=new HashSet<>();
		this.mappaMezzo=new HashMap<>();
		this.mappaPolitica= new HashMap<>();
	}

	/* N.B. E' POSSIBILE USARE I  METODI CHE SEGUONO (E CREARNE DI SIMILARI) 
	 * PER VELOCIZZARE IL TESTING RELATIVO ALLE DOMANDE 3 E SUCCESSIVE */
	private Vetro creaVetroRaccoltoDaBrowniano() {
		final Vetro rifiuto = new Vetro(ORIGINE);
		rifiuto.setRaccoltoDa(this.simulatore.creaBrowniano());	
		return rifiuto;
	}
	private Carta creaCartaRaccoltoDaPendo() {
		final Carta rifiuto = new Carta(ORIGINE);
		rifiuto.setRaccoltoDa(this.simulatore.creaPendo());	
		return rifiuto;
	}
	
	private Vetro creaVetroRaccoltoDaChaser() {
		final Vetro rifiuto = new Vetro(ORIGINE);
		rifiuto.setRaccoltoDa(this.simulatore.creaChaser());	
		return rifiuto;
	}
	private Carta creaCartaRaccoltoDaBrowniano() {
		final Carta rifiuto = new Carta(ORIGINE);
		rifiuto.setRaccoltoDa(this.simulatore.creaBrowniano());	
		return rifiuto;
	}
	
	/* N.B. E' POSSIBILE USARE I METODI SOPRA (E CREARNE DI SIMILARI) 
	 * PER VELOCIZZARE IL TESTING RELATIVO ALLE DOMANDE 3 E SUCCESSIVE */
	
	@Test
	public void testRaccoltoPerMezzo() {
		Rifiuto r=creaVetroRaccoltoDaChaser();	
		Rifiuto b=creaVetroRaccoltoDaBrowniano();
		this.rifiuti.add(r);
		this.rifiuti.add(b);
		this.mappaMezzo.put(r.getRaccoglitore(), 1);
		this.mappaMezzo.put(b.getRaccoglitore(), 1);

		
		assertTrue(this.stats.raccoltoPerMezzo(rifiuti).equals(mappaMezzo));
		this.rifiuti.clear();
		this.mappaMezzo.clear();
		
	}

	
	@Test
	public void testRaccoltoPerPolitica() {
Rifiuto r=creaVetroRaccoltoDaChaser();
		
		Rifiuto b=creaVetroRaccoltoDaBrowniano();
		
		this.rifiuti.add(r);
		
		this.rifiuti.add(b);	
		this.mappaPolitica.put(r.getRaccoglitore().getPolitica().getClass(), 1);
		this.mappaPolitica.put(b.getRaccoglitore().getPolitica().getClass(), 1);
		assertTrue(this.stats.raccoltoPerPolitica(rifiuti).equals(mappaPolitica));
		this.rifiuti.clear();
		this.mappaPolitica.clear();
	}
	
	@Test
	public void testPoliticaOrdinataPerRaccolto() {
		Rifiuto r=creaVetroRaccoltoDaChaser();
		List <Class<?>>ord= new ArrayList<>();
		Rifiuto b=creaVetroRaccoltoDaBrowniano();
	
		this.rifiuti.add(r);
		
		this.rifiuti.add(b);	
		this.mappaPolitica.put(b.getRaccoglitore().getPolitica().getClass(), 1);
		this.mappaPolitica.put(r.getRaccoglitore().getPolitica().getClass(), 2);
		ord.add(r.getRaccoglitore().getPolitica().getClass());
		ord.add(b.getRaccoglitore().getPolitica().getClass());
		assertEquals(2,this.stats.ordinaPolitichePerRaccolta(mappaPolitica).size());
		assertEquals( ord,this.stats.ordinaPolitichePerRaccolta(mappaPolitica));
		this.rifiuti.clear();
		this.mappaPolitica.clear();
	}	
	
	@Test
	public void testPoliticaOrdinataPerRaccolto3PoliticheDiversoval() {
		Rifiuto r=creaVetroRaccoltoDaChaser();
		List <Class<?>>ord= new ArrayList<>();
		Rifiuto b=creaVetroRaccoltoDaBrowniano();
		Rifiuto c=creaCartaRaccoltoDaPendo();
		this.rifiuti.add(r);
		this.rifiuti.add(c);
		this.rifiuti.add(b);
		this.mappaPolitica.put(r.getRaccoglitore().getPolitica().getClass(), 3);
		this.mappaPolitica.put(b.getRaccoglitore().getPolitica().getClass(), 2);
		this.mappaPolitica.put(c.getRaccoglitore().getPolitica().getClass(), 1);
		ord.add(r.getRaccoglitore().getPolitica().getClass());
		ord.add(b.getRaccoglitore().getPolitica().getClass());
		ord.add(c.getRaccoglitore().getPolitica().getClass());
		assertEquals( ord,this.stats.ordinaPolitichePerRaccolta(mappaPolitica));
		this.rifiuti.clear();
		this.mappaPolitica.clear();
	}	
	@Test
	public void testPoliticaOrdinataPerRaccolto2PoliticheUguli() {
		
		List <Class<?>>ord= new ArrayList<>();
		Rifiuto b=creaVetroRaccoltoDaBrowniano();
		Rifiuto c=creaCartaRaccoltoDaBrowniano();
		
		this.rifiuti.add(c);
		this.rifiuti.add(b);
		
		this.mappaPolitica.put(b.getRaccoglitore().getPolitica().getClass(), 2);
		this.mappaPolitica.put(c.getRaccoglitore().getPolitica().getClass(), 1);
		ord.add(c.getRaccoglitore().getPolitica().getClass());
		assertEquals( ord,this.stats.ordinaPolitichePerRaccolta(mappaPolitica));
		this.rifiuti.clear();
		this.mappaPolitica.clear();
	}	
}
