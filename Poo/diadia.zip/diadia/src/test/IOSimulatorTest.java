package test;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.DiaDia;
import it.uniroma3.diadia.IOSimulator;
import it.uniroma3.diadia.ambienti.DirezioniValide;
import it.uniroma3.diadia.ambienti.LabirintoPredefinito;
import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.comandi.*;
public class IOSimulatorTest {
	private DiaDia session;
	private IOSimulator io;

	private static final String ERRORE_TEST = "Errore";
	private static final String OUTPUT_AIUTO="comandi a disposizione : vai aiuto fine prendi posa guarda interagisci saluta \n"
			+ "Comando non valido";
	private static final String OUTPUT_INIZIALE=DiaDia.MESSAGGIO_BENVENUTO;
	private static final String OUTPUT_FINALE=ComandoTermina.MessaggioFine;
	

	private static final String OUTPUT_DIREZIONE_INESISTENTE=ComandoVai.OUTPUT_DIREZIONE_INESISTENTE;
	private static final String OUTPUT_VAI_SENZA_DIREZIONE=ComandoVai.OUTPUT_VAI_SENZA_DIREZIONE;
	private static final String OUTPUT_NON_PRESENTE=ComandoPosa.OUTPUT_NON_TROVATO;
	private static final String OUTPUT_POSATO=ComandoPosa.OUTPUT_POSATO;

	private static final String OUTPUT_SUCCESSO_PRENDI=ComandoPrendi.OUTPUT_SUCCESSO;
	private static final String OUTPUT_NON_TROVATO_PRENDI=ComandoPrendi.OUTPUT_NON_TROVATO_PRENDI;
	private static final String OUTPUT_PRENDI_SENZA_PARAMETRO=ComandoPrendi.OUTPUT_PRENDI_SENZA_PARAMETRO;
	private static final String OUTPUT_VITTORIA=DiaDia.OUTPUT_VITTORIA;


	private static final String FINE ="fine";
	private static final String VAI ="vai ";
	private static final String GUARDA ="guarda ";
	private static final String AIUTO ="aiuto ";
	private static final String POSA ="posa ";
	private static final String PRENDI ="prendi ";

	private String outputStanza;
	private String outputBorsa;


	@Before
	public void setUp() {
		this.io=new IOSimulator();
		session=new DiaDia(new LabirintoPredefinito(),io);
		this.io.setPartita(this.session.getPartita());
	}
	@Test
	public void testSimulazioneSempliceFine() throws Exception {

		List<String> simulazione= new ArrayList<String>();
		simulazione.add(FINE);
		this.start(simulazione);
		
		assertEquals(ERRORE_TEST,OUTPUT_INIZIALE+"Comando non valido", this.io.getOutput());
	}
	@Test
	public void testSimulazioneSempliceGuarda() throws Exception {

		List<String> simulazione= new ArrayList<String>();
		simulazione.add(GUARDA);
		simulazione.add(FINE);
		this.start(simulazione);
		assertEquals(ERRORE_TEST,"Stato Partita :\n"
				+ "con 0 mosse hai raggiunto: \n"
				+ "Atrio\n"
				+ "Uscite: EST, OVEST, NORD, SUD \n"
				+ "Attrezzi nella stanza: osso (1kg) attrezzo1 (4kg) attrezzo2 (14kg)\n"
				+ "nella stanza non � presente alcun personaggio\n"
				+ "con 20 cfu\n"
				+ "Borsa vuotaComando non valido",outputIntroSkipped());
	}
	@Test
	public void testSimulazioneSempliceNonValido() throws Exception {
		List<String> simulazione= new ArrayList<String>();
		simulazione.add("nonvalid");
		simulazione.add(FINE);
		this.start(simulazione);
		assertEquals(ERRORE_TEST,("Comando non validoComando non valido"),outputIntroSkipped());
	}
	@Test
	public void testSimulazioneSempliceAiuto() throws Exception {
		List<String> simulazione= new ArrayList<String>();
		simulazione.add(AIUTO);
		simulazione.add(FINE);
		this.start(simulazione);
		assertEquals(ERRORE_TEST,(OUTPUT_AIUTO),outputIntroSkipped());
	}
	@Test
	public void testSimulazioneSemplicePosaConParametroEAttrezzoInBorsa() throws Exception {
		Attrezzo attrezzo=new Attrezzo("chiave",1);
		this.session.getPartita().GetGiocatore().GetBorsa().addAttrezzoLista(attrezzo);
		List<String> simulazione= new ArrayList<String>();
		simulazione.add(POSA+"chiave");
		simulazione.add(FINE);
		this.start(simulazione);
		assertEquals(ERRORE_TEST,"Cfu Attuali:	20\n"
				+ "ti trovi in:\n"
				+ "Atrio\n"
				+ "Uscite: EST, OVEST, NORD, SUD \n"
				+ "Attrezzi nella stanza: osso (1kg) attrezzo1 (4kg) attrezzo2 (14kg)\n"
				+ "nella stanza non � presente alcun personaggio\n"
				+ "Contenuto borsa (1kg/10kg): chiave (1kg) Comando non valido",outputIntroSkipped());
	}
	
	@Test
	public void testSimulazioneSemplicePosaSenzaParametro() throws Exception {
		List<String> simulazione= new ArrayList<String>();
		simulazione.add(POSA);
		simulazione.add(FINE);
		this.start(simulazione);
		assertEquals(ERRORE_TEST,"Oggetto non trovato in borsaCfu Attuali:	20\n"
				+ "ti trovi in:\n"
				+ "Atrio\n"
				+ "Uscite: EST, OVEST, NORD, SUD \n"
				+ "Attrezzi nella stanza: osso (1kg) attrezzo1 (4kg) attrezzo2 (14kg)\n"
				+ "nella stanza non � presente alcun personaggio\n"
				+ "Borsa vuotaComando non valido", outputIntroSkipped());
	}
	@Test
	public void testSimulazioneSemplicePrendiConParametroEAttrezzoNONInBorsa() throws Exception {
		Attrezzo attrezzo=new Attrezzo("chiave",1);
		this.session.getPartita().getStanzaCorrente().addAttrezzo(attrezzo);
		List<String> simulazione= new ArrayList<String>();
		simulazione.add(PRENDI+"chiave");
		simulazione.add(FINE);
		this.start(simulazione);
		assertEquals(ERRORE_TEST,"Attezzo non presente nella stanzaComando non valido",outputIntroSkipped());
	}
	@Test
	public void testSimulazioneSemplicePrendiConParametroEAttrezzoInBorsa() throws Exception {
		Attrezzo attrezzo=new Attrezzo("chiave",1);
		this.session.getPartita().getStanzaCorrente().addAttrezzo(attrezzo);
		this.session.getPartita().GetGiocatore().GetBorsa().addAttrezzoLista(attrezzo);
		List<String> simulazione= new ArrayList<String>();
		simulazione.add(PRENDI+"chiave");
		simulazione.add(FINE);
		this.start(simulazione);
		assertEquals(ERRORE_TEST,"Attezzo non presente nella stanzaComando non valido", outputIntroSkipped());
	}
	@Test
	public void testSimulazioneSemplicePrendiSenzaParametro() throws Exception {
		List<String> simulazione= new ArrayList<String>();
		simulazione.add(PRENDI);
		simulazione.add(FINE);
		this.start(simulazione);
		assertEquals(ERRORE_TEST,"Attezzo non presente nella stanzaComando non valido",outputIntroSkipped());
	}
	@Test
	public void testSimulazioneSempliceVaiConParametroErrato() throws Exception {
		List<String> simulazione= new ArrayList<String>();
		simulazione.add(VAI+"prima");
		simulazione.add(FINE);
		this.start(simulazione);
		assertEquals(ERRORE_TEST,"Dove vuoi andare?Comando non valido",outputIntroSkipped());
	}
	@Test
	public void testSimulazioneSempliceVaiSenzaParametro() throws Exception {
		List<String> simulazione= new ArrayList<String>();
		simulazione.add(VAI);
		simulazione.add(FINE);
		this.start(simulazione);
		assertEquals(ERRORE_TEST,("Atrio\n"
				+ "Uscite: EST, OVEST, NORD, SUD \n"
				+ "Attrezzi nella stanza: osso (1kg) attrezzo1 (4kg) attrezzo2 (14kg)\n"
				+ "nella stanza non � presente alcun personaggioNon Puoi Andare li: direzione inesistenteComando non valido"),outputIntroSkipped());
	}
//	@Test 
//	public void testSimulazioneSempliceVaiConParametroEsatto() throws Exception {
//		List<String> simulazione= new ArrayList<String>();
//		simulazione.add(VAI+DirezioniValide.SUD.toString());
//		simulazione.add(FINE);
//		int i=0;
//		
//		
//		this.start(simulazione);
//		assertEquals(ERRORE_TEST,(outputSpostamento(i++)+OUTPUT_FINALE),outputIntroSkipped());
//	}
//	@Test 
//	public void testSimulazioneDoppioVaiConParametroEsatto() throws Exception {
//		List<String> simulazione= new ArrayList<String>();
//		simulazione.add(VAI+DirezioniValide.SUD.toString());
//		simulazione.add(VAI+DirezioniValide.NORD.toString());
//		simulazione.add(FINE);
//		int i=0;
//		this.start(simulazione);
//		assertEquals(ERRORE_TEST,(outputSpostamento(i++)+outputSpostamento(i++)+
//				OUTPUT_FINALE),outputIntroSkipped());
//
//	}
	@Test 
	public void testSimulazioneAttrezzoCambiaStanza() throws Exception {
		List<String> simulazione= new ArrayList<String>();
		simulazione.add(PRENDI+"osso");
		simulazione.add(VAI+"est");
		simulazione.add(POSA+"osso");
		simulazione.add(GUARDA);
		simulazione.add(FINE);
		int i=0;
		this.start(simulazione);
		assertEquals(ERRORE_TEST,"Attrezzo messo in borsaTi trovi in:\n"
				+ "Aula N11\n"
				+ "Uscite: EST, OVEST \n"
				+ "Attrezzi nella stanza:\n"
				+ "nella stanza non � presente alcun personaggio\n"
				+ "Hai 19 cfu\n"
				+ "Contenuto borsa (1kg/10kg): osso (1kg) Cfu Attuali:	20\n"
				+ "ti trovi in:\n"
				+ "Atrio\n"
				+ "Uscite: EST, OVEST, NORD, SUD \n"
				+ "Attrezzi nella stanza: osso (1kg) attrezzo1 (4kg) attrezzo2 (14kg)\n"
				+ "nella stanza non � presente alcun personaggio\n"
				+ "Contenuto borsa (1kg/10kg): chiave (1kg) Cfu Attuali:	19\n"
				+ "ti trovi in:\n"
				+ "Aula N11\n"
				+ "Uscite: EST, OVEST \n"
				+ "Attrezzi nella stanza:\n"
				+ "nella stanza non � presente alcun personaggio\n"
				+ "Contenuto borsa (1kg/10kg): osso (1kg) Stato Partita :\n"
				+ "con 1 mosse hai raggiunto: \n"
				+ "Aula N11\n"
				+ "Uscite: EST, OVEST \n"
				+ "Attrezzi nella stanza: osso (1kg)\n"
				+ "nella stanza non � presente alcun personaggio\n"
				+ "con 19 cfu\n"
				+ "Borsa vuotaComando non valido",outputIntroSkipped());
	}
	@Test 
	public void testSimulazioneVittoria() throws Exception {
		List<String> simulazione= new ArrayList<String>();
		simulazione.add(VAI+"sud");
		simulazione.add(VAI+"nord");
		simulazione.add(VAI+"nord");
		int i=0;
		this.start(simulazione);
		assertEquals(ERRORE_TEST,"Ti trovi in:\n"
				+ "Aula N10\n"
				+ "Uscite: NORD, EST, OVEST \n"
				+ "Attrezzi nella stanza: lanterna (10kg)\n"
				+ "nella stanza non � presente alcun personaggio\n"
				+ "Hai 19 cfu\n"
				+ "Borsa vuotaTi trovi in:\n"
				+ "Atrio\n"
				+ "Uscite: EST, OVEST, NORD, SUD \n"
				+ "Attrezzi nella stanza: osso (1kg) attrezzo1 (4kg) attrezzo2 (14kg)\n"
				+ "nella stanza non � presente alcun personaggio\n"
				+ "Hai 18 cfu\n"
				+ "Borsa vuotaTi trovi in:\n"
				+ "Biblioteca\n"
				+ "Uscite: SUD \n"
				+ "Attrezzi nella stanza:\n"
				+ "nella stanza non � presente alcun personaggio\n"
				+ "Hai 17 cfu\n"
				+ "Borsa vuotaHai vinto!",outputIntroSkipped());

	}

	@Test 
	public void testSimulazioneComandiErrati() throws Exception {
		List<String> simulazione= new ArrayList<String>();
		simulazione.add("blip");
		simulazione.add("blop");
		simulazione.add("bleep");
		simulazione.add(FINE);
		this.start(simulazione);
		assertEquals(ERRORE_TEST,"Comando non validoComando non validoComando non validoComando non valido",outputIntroSkipped());
	}

	
	
	private void start(List<String> simulazione) throws Exception {
		this.io.setInput(simulazione);
		session.gioca();
	}
	public String outputIntroSkipped() {
		return this.io.getOutput().substring(OUTPUT_INIZIALE.length());
	}
	public String outputSpostamento(int i) {
		return	this.session.getPartita().getPercorso(i);
	}
	private String outputGuarda() {
		outputStanza="Stanza corrente: "+this.session.getPartita().getStanzaCorrente().getDescrizione();
		outputBorsa="Informazioni partita: "+this.session.getPartita().GetGiocatore().toString();


		return outputStanza+"\n"+outputBorsa;
	}

}