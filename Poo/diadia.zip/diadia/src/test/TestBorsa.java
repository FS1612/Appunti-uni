package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.giocatore.Borsa;

public class TestBorsa {
	Borsa borsa;
	Borsa borsa2;
	Attrezzo attrezzo1;
	Attrezzo attrezzo2;
	Attrezzo attrezzo3;
	Attrezzo attrezzo4;
	Attrezzo attrezzo5;
	Attrezzo attrezzo6;
	Attrezzo attrezzo7;
	Attrezzo attrezzo8;
	Attrezzo attrezzo9;
	Attrezzo attrezzo10;
	Attrezzo attrezzo11;
	@Before
	public void setUp() throws Exception {
		borsa =new Borsa();
		borsa2 =new Borsa();
		attrezzo1=new Attrezzo("attrezzo1",1);
		attrezzo2=new Attrezzo("attrezzo2",1);
		attrezzo3=new Attrezzo("attrezzo3",1);
		attrezzo4=new Attrezzo("attrezzo4",1);
		attrezzo5=new Attrezzo("attrezzo5",1);
		attrezzo6=new Attrezzo("attrezzo6",1);
		attrezzo7=new Attrezzo("attrezzo7",1);
		attrezzo8=new Attrezzo("attrezzo8",1);
		attrezzo9=new Attrezzo("Attrezzo9",1);
		attrezzo10=new Attrezzo("attrezzo10",1);
		attrezzo11=new Attrezzo("attrezzo12",5);
		borsa2.addAttrezzoLista(attrezzo1);
		borsa2.addAttrezzoLista(attrezzo2);
		borsa2.addAttrezzoLista(attrezzo3);
		borsa2.addAttrezzoLista(attrezzo4);
		borsa2.addAttrezzoLista(attrezzo5);
		borsa2.addAttrezzoLista(attrezzo6);
		borsa2.addAttrezzoLista(attrezzo7);
		borsa2.addAttrezzoLista(attrezzo8);
		borsa2.addAttrezzoLista(attrezzo9);
		borsa.addAttrezzoLista(attrezzo1);
	}

	@Test
	public void testAggiugiUnAttrezzoBorsaVuota() {
		
		assertTrue(borsa.hasAttrezzoLista("attrezzo1"));
	}
	@Test
	public void testAggiugiUnAttrezzoBorsaCon9Elementi() {
		borsa2.addAttrezzoLista(attrezzo10);
		assertEquals("Contenuto borsa (10kg/10kg): attrezzo1 (1kg) attrezzo2 (1kg) attrezzo3 (1kg) attrezzo4 (1kg) attrezzo5 (1kg) attrezzo6 (1kg) attrezzo7 (1kg) attrezzo8 (1kg) Attrezzo9 (1kg) attrezzo10 (1kg) ",borsa2.toString());
	}
	@Test
	public void testAggiugiUnAttrezzoBorsaCon10Elementi() {
		borsa2.addAttrezzoLista(attrezzo10);
		borsa2.addAttrezzoLista(attrezzo11);
		assertFalse(borsa2.addAttrezzoLista(attrezzo11));
		assertEquals("Contenuto borsa (10kg/10kg): attrezzo1 (1kg) attrezzo2 (1kg) attrezzo3 (1kg) attrezzo4 (1kg) attrezzo5 (1kg) attrezzo6 (1kg) attrezzo7 (1kg) attrezzo8 (1kg) Attrezzo9 (1kg) attrezzo10 (1kg) ",borsa2.toString());
	}
	@Test
	public void testAggiugiUnAttrezzoBorsaCon9ElementiLimitatainpeso() {
		
		borsa2.addAttrezzoLista(attrezzo11);
		assertFalse(borsa2.addAttrezzoLista(attrezzo11));
		assertEquals("Contenuto borsa (9kg/10kg): attrezzo1 (1kg) attrezzo2 (1kg) attrezzo3 (1kg) attrezzo4 (1kg) attrezzo5 (1kg) attrezzo6 (1kg) attrezzo7 (1kg) attrezzo8 (1kg) Attrezzo9 (1kg) ",borsa2.toString());
	}
	 
	
	@Test 
	public void RimuoviAttrezzoBorsaPienaStrumentoinesistente() {
		borsa2.removeAttrezzoLista("attrezzo11");
		assertEquals(null,borsa2.removeAttrezzoLista("attrezzo11"));
		assertEquals("Contenuto borsa (9kg/10kg): attrezzo1 (1kg) attrezzo2 (1kg) attrezzo3 (1kg) attrezzo4 (1kg) attrezzo5 (1kg) attrezzo6 (1kg) attrezzo7 (1kg) attrezzo8 (1kg) Attrezzo9 (1kg) ",borsa2.toString());
	}
	@Test
	public void GetAttrezzo() {
		assertEquals(attrezzo1,borsa.getAttrezzoLista("attrezzo1"));
	}
	@Test
	public void GetAttrezzonullo() {
		assertEquals(null,borsa.getAttrezzoLista("attrezzo2"));
	}
	@Test
	public void Rimuovi1Attrezzo() {
		borsa.removeAttrezzoLista("attrezzo1");
		assertEquals(true,borsa.isEmpty());
	}
	@Test
	public void TestaStampaListe () {
		assertEquals("Contenuto borsa (9kg/10kg): [ attrezzo1, attrezzo2, attrezzo3, attrezzo4, attrezzo5, attrezzo6, attrezzo7, attrezzo8, Attrezzo9 ]  ", borsa2.DescrizioneListe());
	}
	@Test
	public void TestaStampaMappe () {
		assertEquals("Contenuto borsa (9kg/10kg): (1, { Attrezzo9 , attrezzo1 , attrezzo2 , attrezzo3 , attrezzo4 , attrezzo5 , attrezzo6 , attrezzo7 , attrezzo8 } ) ", borsa2.DescrizioneMappe());
	}
	@Test
	public void TestaStampaSet () {
		assertEquals("Contenuto borsa (9kg/10kg): { Attrezzo9, attrezzo1, attrezzo2, attrezzo3, attrezzo4, attrezzo5, attrezzo6, attrezzo7, attrezzo8 }  ", borsa2.DescrizioneSet());
	}
}
