package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.ambienti.StanzaBuia;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class StanzaBuiaTest {
private StanzaBuia stanzabuia;
private Stanza stanza;
private Attrezzo illuminante;
	@Before
	public void setUp() throws Exception {
		illuminante=new Attrezzo ("illuminante",4);
		stanzabuia=new StanzaBuia("illuminante", "stanzabuia");
		stanza= new Stanza ("stanza");
		stanza.impostaStanzaAdiacente("est", stanzabuia);
		
	}

	@Test
	public void testDescrizioneConIlluminante() {
		stanzabuia.addAttrezzoListe(illuminante);
		assertEquals("stanzabuia\n"
				+ "Uscite:  \n"
				+ "Attrezzi nella stanza: illuminante (4kg)\n"
				+ "nella stanza non � presente alcun personaggio",stanzabuia.getDescrizione());
	}
	@Test
	public void testDescrizioneSenzaIlluminante() {
		
		assertEquals("non si vede nulla",stanzabuia.getDescrizione());
	}
}
