package test;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.Labirinto;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.giocatore.Mago;



public class MagoTest {

	private Mago mago;
	private Attrezzo regalo;
	private Partita partita;

	@Before
	public void setUp() throws Exception{
		Labirinto lab= new Labirinto.LabirintoBuilder()
				.AddIniziale("Iniziale")
				.GetLabirinto();
		lab.SetStanzaCorrente(lab.GetStanzaIniziale());
		this.partita=new Partita(lab);
		this.regalo=new Attrezzo("Clava",4);
		this.mago=new Mago(this.regalo);
	}
	@Test
	public void testAgisci() {
		assertFalse(this.partita.getStanzaCorrente().hasAttrezzoListe(this.regalo.getNome()));
		this.mago.agisci(partita);
		assertTrue(this.partita.getStanzaCorrente().hasAttrezzoListe(this.regalo.getNome()));
	}
	@Test
	public void agisciDueVolte() {
		assertFalse(this.partita.toString(),this.partita.getStanzaCorrente().hasAttrezzoListe(this.regalo.getNome()));
		this.mago.agisci(partita);
		assertTrue(this.partita.getStanzaCorrente().hasAttrezzoListe(this.regalo.getNome()));
		this.partita.getStanzaCorrente().removeAttrezzoListe(this.regalo);
		this.mago.agisci(this.partita);
		assertNotNull(this.partita.getStanzaCorrente());
		Stanza a =this.partita.getStanzaCorrente();
		assertNotNull(a);
		assertEquals(this.partita.getStanzaCorrente(),a);
//		assertFalse(a.hasAttrezzoListe(this.regalo.getNome()));
	}
	@Test
	public void testRiceviRegalo() {
		Attrezzo daDimezzare=new Attrezzo("halfWeight",5);
		this.mago.riceviRegalo(daDimezzare, partita);
		assertTrue(this.partita.getStanzaCorrente().hasAttrezzoListe(daDimezzare.getNome()));
		assertEquals(2,this.partita.getStanzaCorrente().getAttrezzoListe(daDimezzare.getNome()).getPeso());
	}


}