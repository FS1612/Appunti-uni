package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.ambienti.StanzaMagica;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class StanzaMagicaTest {
	private StanzaMagica stanzaMagica;
	private Attrezzo attrezzo;
	private Attrezzo attrezzo1;
	private Attrezzo attrezzo2;

	private Attrezzo bacchetta;
	
	@Before
	public void setUp() {
		stanzaMagica= new StanzaMagica("Magicaa", 3);
		attrezzo= new Attrezzo("attrezzo",2);
		attrezzo1= new Attrezzo("attrezzo1",1);
		attrezzo2= new Attrezzo("attrezzo2",1);
		bacchetta= new Attrezzo("bacchetta",3);
	}
	@Test
	public void testAddAttrezzo() {
		
		stanzaMagica.addAttrezzoListe(attrezzo);
		assertEquals("Magicaa\n"
				+ "Uscite:\s\s\n"
				+ "Attrezzi nella stanza: attrezzo (2kg)\n"
				+ "nella stanza non � presente alcun personaggio",  stanzaMagica.getDescrizione());
	}
	@Test
	public void testAddAttrezzoSuperandoLaSoglia() {
		stanzaMagica.addAttrezzoListe(attrezzo);
		stanzaMagica.addAttrezzoListe(attrezzo1);
		stanzaMagica.addAttrezzoListe(attrezzo2);
		stanzaMagica.addAttrezzoListe(bacchetta);
		assertEquals("Magicaa\n"
				+ "Uscite:\s\s\n"
				+ "Attrezzi nella stanza: attrezzo (2kg) attrezzo1 (1kg) attrezzo2 (1kg) attehccab (6kg)\n"
				+ "nella stanza non � presente alcun personaggio",  stanzaMagica.getDescrizione());
	}

}
