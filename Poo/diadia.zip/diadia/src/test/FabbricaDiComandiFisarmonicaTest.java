package test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.IoConsole;
import it.uniroma3.diadia.comandi.Comandi;
import it.uniroma3.diadia.comandi.FabbricaDiComandiFisarmonica;

public class FabbricaDiComandiFisarmonicaTest {
	private FabbricaDiComandiFisarmonica fabbricaDiComandi;

	@Before
	public void setUp() throws Exception {
		this.fabbricaDiComandi = new FabbricaDiComandiFisarmonica();
	}

	@Test
	public void testAiuto() {
		testaNomeParametroComando("aiuto", "aiuto",null);
	}
	
	@Test
	public void testVai() {
		testaNomeParametroComando("vai","vai", "nord");
	}
	
	@Test
	public void testFine() {
		testaNomeParametroComando("fine","fine",  null);
	}
	
	@Test
	public void testPrendi() {
		testaNomeParametroComando("prendi","Prendi", "osso");
	}
	
	@Test
	public void testPosa() {
		testaNomeParametroComando("posa","Posa",  "osso");
	}	

	@Test
	public void testComandoVuoto() {
		testaNomeParametroComando("","non valido", null);
	}	
	
	@Test
	public void testComandoNonValido() {
		testaNomeParametroComando("invalid","non valido", null);
	}	
	private void testaNomeParametroComando(String nomeComando, String comandoAtteso, String parametroDaFornire) {
		Comandi comando = this.fabbricaDiComandi.costruisciComando(nomeComando, new IoConsole());
		if (parametroDaFornire != null) 
			comando.setParametro(parametroDaFornire);
		assertEquals(comandoAtteso, comando.getNome());
		assertEquals(parametroDaFornire, comando.getParametro());
	}


}
