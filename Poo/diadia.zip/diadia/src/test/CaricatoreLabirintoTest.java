package test;
import static org.junit.Assert.assertEquals;


import java.io.StringReader;

import org.junit.Test;

import it.uniroma3.diadia.ambienti.CaricatoreLabirinto;
import it.uniroma3.diadia.ambienti.DirezioniValide;
import it.uniroma3.diadia.ambienti.FormatoFileNonValidoException;
import it.uniroma3.diadia.ambienti.Labirinto;

public class CaricatoreLabirintoTest {
	private static final String DESCRIZIONE_LABIRINTO
	="Stanze:\n"
			+"N10\n"
			+"Biblioteca\n"
			+"Magiche:\n"
			+"N1\n"
			+"Buie:\n"
			+"Sgabuzzino\n"
			+"torcia\n"
			+"Bloccate:\n"
			+"DS1\n"

			+"est\n"
			+"dinamite\n"
			+"Personaggi:\n"
			+"Cane\n"
			+"N1\n"
			+"Biscotto 1\n"
//			+"Mago\n"	
//			+"Sgabuzzino\n"
//			+"torcia 4\n"
			
			+"Estremi:\n"
			+"N10\n"
			+"Biblioteca\n"
			+"Attrezzi:\n"
			+"Osso 5 N10\n"
			+"torcia 2 Sgabuzzino\n"
			+"Uscite:\n"
			+"N10 nord Biblioteca\n"
			+"Biblioteca sud N10\n"
			+"N10 sud N1\n"
			+"N1 nord N10\n";
		
	@Test
	public void testCarica() throws FormatoFileNonValidoException{
		CaricatoreLabirinto caricatore= new CaricatoreLabirinto(new StringReader(DESCRIZIONE_LABIRINTO));
		caricatore.carica();
		Labirinto labirinto=caricatore.getLabirinto();
		assertEquals("N10", labirinto.GetStanzaIniziale().getNome());
		assertEquals("Biblioteca", labirinto.GetStanzaVincente().getNome());

		assertEquals("N10",labirinto.GetStanzaVincente().getStanzaAdiacenteMappa(DirezioniValide.SUD).getNome());
		
	}
}
