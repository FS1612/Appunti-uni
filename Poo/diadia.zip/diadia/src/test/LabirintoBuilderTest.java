package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.ambienti.DirezioniValide;
import it.uniroma3.diadia.ambienti.Labirinto;
import it.uniroma3.diadia.ambienti.Labirinto.LabirintoBuilder;
import it.uniroma3.diadia.ambienti.Stanza;

//public class LabirintoBuilderTest {
//
//		private Labirinto labirinto;
//		private Labirinto monolocale;
//		private Labirinto bilocale;
//		private Labirinto trilocale;
//
//		@Before
//		public void setUp() {
//			this.labirinto=Labirinto.LabirintoBuilder.newBuilder();
//		}
//		@Test
//		public void testAddStanza() {
//			labirinto.addStanza("salone");
//			assertEquals("salone",this.labirinto.getLastStanzaAggiunta().getNome());
//		}
//		@Test
//		public void testAddStanzaIniziale() {
//			labirinto.addStanza("seconda");
//			labirinto.AddIniziale("iniziale");
//			assertEquals("iniziale",this.labirinto.GetStanzaIniziale().getNome());
//		}
//		@Test
//		public void testAddStanzaVincente() {
//			labirinto.SetStanzaVincente("salone");
//			assertEquals("salone",this.labirinto.GetStanzaVincente().getNome());
//		}
//		@Test
//		public void testAddAttrezzoUlitmaStanzaAggiunta() {
//			this.labirinto.addStanza("atrio");
//			this.labirinto.addStanza("salone");
//			this.labirinto.addStanza("cucina");
//			this.labirinto.addStanza("Biblioteca");
//			this.labirinto.addAttrezzo("spada", 5);
//
//			assertEquals(false, this.labirinto.getStanza("atrio").hasAttrezzo("spada"));
//			assertEquals(false, this.labirinto.getStanza("salone").hasAttrezzo("spada"));
//			assertEquals(false, this.labirinto.getStanza("cucina").hasAttrezzo("spada"));
//			assertEquals(true, this.labirinto.getStanza("Biblioteca").hasAttrezzo("spada"));
//		}
//		@Test
//		public void testAddAdiacenza() {
//			this.labirinto.AddIniziale("cucina");
//			this.labirinto.addStanza("bagno");
//			this.labirinto.addAdiacenza("cucina", "bagno", Direzione.SUD);
//			this.labirinto.addAdiacenza("bagno", "cucina", Direzione.NORD);
//			assertEquals("bagno", this.labirinto.GetStanzaIniziale().getStanzaAdiacente(Direzione.SUD).getNome());
//		}
//		
//		
//		@Test
//		public void testMonolocale() {
//			this.monolocale = new LabirintoBuilder()
//					.AddIniziale("salotto") 
//					.SetStanzaVincente(new Stanza("salotto")) ;
//			
//			assertSame("salotto",this.monolocale.GetStanzaVincente().getNome());
//			assertSame("salotto",this.monolocale.GetStanzaIniziale().getNome());
//		}
//
//		@Test
//		public void testBilocale() {
//			this.bilocale= new LabirintoBuilder()
//					.AddIniziale("salotto")
//					.addAttrezzo("divano",10) 
//					.SetStanzaVincente(new Stanza("camera"))
//					.addAdiacenza("salotto", "camera", DirezioniValide.NORD)
//					.GetLabirinto();
//			assertSame("salotto",this.bilocale.GetStanzaIniziale().getNome());
//			assertSame("camera",this.bilocale.GetStanzaVincente().getNome());
//			assertTrue(this.bilocale.GetStanzaCorrente().hasAttrezzo("divano"));
//			assertSame("camera",this.bilocale.GetStanzaIniziale().getStanzaAdiacenteMappa(DirezioniValide.NORD).getNome());
//			assertSame("salotto",this.bilocale.GetStanzaVincente().getStanzaAdiacenteMappa(DirezioniValide.SUD).getNome());
//		}
//		@Test
//		public void testTrilocale() {
//				this.trilocale = new LabirintoBuilder()
//						.AddIniziale("salotto")
//						.SetStanzaVincente("camera")
//						.addStanza("cucina")
//						.addAttrezzo("pentola",1)
//						.addAdiacenza("salotto", "cucina", Direzione.NORD)
//						.addAdiacenza("cucina", "camera", Direzione.EST)
//						.getLabirinto();
//				assertSame("salotto",this.trilocale.GetStanzaIniziale().getNome());
//				assertSame("camera",this.trilocale.GetStanzaVincente().getNome());
//				assertTrue(this.trilocale.getStanza("cucina").hasAttrezzo("pentola"));
//				assertSame("cucina",this.trilocale.GetStanzaIniziale().getStanzaAdiacente(Direzione.NORD).getNome());
//				assertSame("camera",this.trilocale.getLastStanzaAggiunta().getStanzaAdiacente(Direzione.EST).getNome());
//		}
//
//	
//	}
//
//
