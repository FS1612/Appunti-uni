package test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.DirezioniValide;
import it.uniroma3.diadia.ambienti.Labirinto;
import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.giocatore.Strega;

public class StregaTest {
	private static final String INIZIALE="Iniziale";
	private static final String STANZA_OVEST_1_ATTREZZO="stanzaOvest1Attrezzo";
	private static final String STANZA_EST_2_ATTREZZI="stanzaEst2Attrezzi";
	private static final String STANZA_NORD_3_ATTREZZI="stanzaNord3Attrezzi";
	private static final DirezioniValide EST=DirezioniValide.EST;
	private static final DirezioniValide OVEST=DirezioniValide.OVEST;
	private static final DirezioniValide NORD=DirezioniValide.NORD;
	private static final DirezioniValide SUD=DirezioniValide.SUD;
	private Partita partita;
	private Strega strega;

	@Before
	public void setUp() throws Exception{
		Labirinto lab=  new Labirinto.LabirintoBuilder()
				.AddIniziale(INIZIALE)
				.addStanza(STANZA_EST_2_ATTREZZI)
				.addAdiacenza(INIZIALE, STANZA_EST_2_ATTREZZI, EST)
				.addStanza(STANZA_OVEST_1_ATTREZZO)
				.addAdiacenza(INIZIALE, STANZA_OVEST_1_ATTREZZO, OVEST)
				.addStanza(STANZA_NORD_3_ATTREZZI)
				.addAdiacenza(INIZIALE, STANZA_NORD_3_ATTREZZI, NORD)
				.GetLabirinto();
		lab.SetStanzaCorrente(lab.GetStanzaIniziale());
		lab.getStanza(STANZA_EST_2_ATTREZZI)
		.addAttrezzoListe(new Attrezzo("attrezzo1", 1));
		lab.getStanza(STANZA_EST_2_ATTREZZI).addAttrezzoListe(new Attrezzo("attrezzo4",3));
		lab.getStanza(STANZA_OVEST_1_ATTREZZO).addAttrezzoListe(new Attrezzo("attrezzo3",3));
		lab.getStanza(STANZA_NORD_3_ATTREZZI)
		.addAttrezzoListe(new Attrezzo("attrezzo4",4));
		lab.getStanza(STANZA_NORD_3_ATTREZZI).addAttrezzoListe(new Attrezzo("attrezzo5",5));
		lab.getStanza(STANZA_NORD_3_ATTREZZI).addAttrezzoListe(new Attrezzo("attrezzo6",6));
		this.partita=new Partita(lab);
		this.strega=new Strega();
	}
	@Test
	public void testAgisciSenzaSalutare() {
		this.strega.agisci(this.partita);
		assertEquals(STANZA_OVEST_1_ATTREZZO,this.partita.getStanzaCorrente().getNome());
	}
	@Test
	public void testAgisciSaluta() {
		this.strega.saluta();
		this.strega.agisci(partita);
		assertEquals(STANZA_NORD_3_ATTREZZI,this.partita.getStanzaCorrente().getNome());
	}
	@Test
	public void testRiceviRegalo() {
		this.strega.riceviRegalo(new Attrezzo("test",1), this.partita);
		assertFalse(this.partita.getStanzaCorrente().hasAttrezzo("test"));
		assertFalse(this.partita.GetGiocatore().GetBorsa().hasAttrezzoLista("test"));
	}
}