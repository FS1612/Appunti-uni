package it.uniroma3.diadia.fixture;
import java.util.List;

import it.uniroma3.diadia.DiaDia;

import it.uniroma3.diadia.ambienti.LabirintoPredefinito;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class Fixture {
	
	public static it.uniroma3.diadia.IOSimulator creaSimulazionePartitaEGioca(List<String> righeDaLeggere) throws Exception {
		it.uniroma3.diadia.IOSimulator io = new it.uniroma3.diadia.IOSimulator(righeDaLeggere);
		LabirintoPredefinito lab=new LabirintoPredefinito();
		new DiaDia(lab,io).gioca();
		return io;
	}
	
	public static Attrezzo creaAttrezzoEAggiungiAStanza(Stanza stanzaDaRiempire, String nomeAttrezzo, int peso) {
		Attrezzo attrezzo = new Attrezzo(nomeAttrezzo, peso);
		stanzaDaRiempire.addAttrezzo(attrezzo);
		return attrezzo;
	}
}