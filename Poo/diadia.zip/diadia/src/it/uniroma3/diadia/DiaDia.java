package it.uniroma3.diadia; 






import it.uniroma3.diadia.ambienti.DirezioniValide;
import it.uniroma3.diadia.ambienti.Labirinto;

import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.comandi.Comandi;
//import it.uniroma3.diadia.comandi.FabbricaDiComandiFisarmonica;
import it.uniroma3.diadia.comandi.FabbricaDiComandiRiflessiva;

/**
 * Classe principale di diadia, un semplice gioco di ruolo ambientato al dia.
 * Per giocare crea un'istanza di questa classe e invoca il letodo gioca
 *
 * Questa e' la classe principale crea e istanzia tutte le altre
 *
 * @author  docente di POO 
 *         (da un'idea di Michael Kolling and David J. Barnes) 
 *          
 * @version base
 */

public class DiaDia {

	public static final  String MESSAGGIO_BENVENUTO = ""+
			"Ti trovi nell'Universita', ma oggi e' diversa dal solito...\n" +
			"Meglio andare al piu' presto in biblioteca a studiare. Ma dov'e'?\n"+
			"I locali sono popolati da strani personaggi, " +
			"alcuni amici, altri... chissa!\n"+
			"Ci sono attrezzi che potrebbero servirti nell'impresa:\n"+
			"puoi raccoglierli, usarli, posarli quando ti sembrano inutili\n" +
			"o regalarli se pensi che possano ingraziarti qualcuno.\n\n"+
			"Per conoscere le istruzioni usa il comando 'aiuto'.";
	static final public String OUTPUT_VITTORIA= "Hai vinto!";
	
	static final public String OUTPUT_PARTITA_FINITA="Grazie di aver giocato!";
	

	private Partita partita;
private IO Io;
	public DiaDia(Labirinto labirinto,IO io)  {
		this.partita = new Partita(labirinto);
		this.Io=io;
	
	}

	public void gioca() throws Exception {
		String istruzione; 
		


		this.Io.mostraMessaggio(MESSAGGIO_BENVENUTO);	
		
		do		
			istruzione= this.Io.leggiRiga();
		while (!processaIstruzione(istruzione));
	}   
	

	/**
	 * Processa una istruzione 
	 *
	 * @return true se l'istruzione e' eseguita e il gioco continua, false altrimenti
	 */
	private boolean processaIstruzione(String istruzione) {

		Comandi comandoDaEseguire;
		FabbricaDiComandiRiflessiva factory = new FabbricaDiComandiRiflessiva();
		
		 comandoDaEseguire=factory.costruisciComando(istruzione, Io);
		 comandoDaEseguire.SetIO(Io);
		 comandoDaEseguire.esegui(this.partita);
 if(istruzione.startsWith("fine")) return true;
		if (this.partita.vinta()){			
			this.Io.mostraMessaggio(OUTPUT_VITTORIA);
			 
		} 
		else if(this.partita.getCfu()==0){
			this.Io.mostraMessaggio(OUTPUT_PARTITA_FINITA);
			return true;
		}
		return this.partita.isFinita();
	}   
	public Partita getPartita() {
		return this.partita;
	}
	
	public static void main(String[] argc) throws Exception {
		IO io = new IoConsole();

		
		Labirinto labirinto = new Labirinto.LabirintoBuilder()
				.AddIniziale("LabCampusOne")			
				.addAttrezzo("pc", 2)
				.addStanza("bagno")
				.addAttrezzo("lanterna", 1)
				.addAttrezzo("lampadario", 3)
				.addAttrezzo("osso", 2)
				.addStrega("LabCampusOne")
				.addAdiacenza("LabCampusOne", "bagno", DirezioniValide.EST)
				.addStanza("cucina")
				.addAttrezzo("cucchiaio", 2)
				.addCane("cucina", new Attrezzo("palla",1), "osso")
				
				.addAdiacenza("LabCampusOne", "cucina", DirezioniValide.NORD)
				.AddStanzaBuia("lanterna", "sgabuzzino")
				.addAttrezzo("spadino", 1)
				.addAttrezzo("telecomando", 5)
				.addAdiacenza("LabCampusOne", "sgabuzzino", DirezioniValide.SUD)
				.AddStanzaBloccata("tunnel", "spadino", DirezioniValide.NORD)
				.addAdiacenza("sgabuzzino", "tunnel", DirezioniValide.EST)
				.AddStanzaMagica("narnia", 2)
				.addAdiacenza("tunnel", "narnia", DirezioniValide.NORD)
				.addStanza("Biblioteca")
				.addMago("sgabuzzino",new Attrezzo("spatola",5))
				.addAdiacenza("Biblioteca", "narnia", DirezioniValide.NORD)
				.addAdiacenza("LabCampusOne","Biblioteca",DirezioniValide.OVEST)
				.addAttrezzo("corda", 3)
				.AddFinale("Biblioteca")
				.GetLabirinto();//* method chaining su labirinto
		DiaDia gioco = new DiaDia(labirinto,io);
		
		gioco.gioca();
		
	}
}