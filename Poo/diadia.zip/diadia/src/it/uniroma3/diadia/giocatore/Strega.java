/**
 * 
 */
package it.uniroma3.diadia.giocatore;

import java.util.Collections;

import java.util.List;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;

/**
 * @author francesco
 *
 */
public  class Strega extends AbstractPersonaggio  {
private final static String nome="Strega";
private final static String Presentazione="Sono una strega, non farmi arrabbiare";
private Attrezzo attrezzoRicevuto;
private final String attrezzoAccettato="questo � il mio tessoro AHAHAHAHAHAH";
private final String attrezzoNonAccettato="Dammi qualcosa di meglio";
private final String StanzaModificataMenoOggetti="Tu non mi hai salutato, per punizione sarai spostato in una stanza con pochi strumenti";
private final String StanzaModificataPiuOggetti="Tu  mi hai salutato, per ringraziarti ti sposto in una stanza con molti strumenti";
/**
	 * 
	 */

	public Strega() {
		super(nome,Presentazione);
	}

	@Override
	public String agisci(Partita partita) {
		StringBuilder out= new StringBuilder();
		//*lista la cui prima stanza ha piu elementi, l'ultma meno
		//*indici [0-(size-1)]
		List<Stanza>a=OrdinaStanze(partita );

		if(!super.GetSalutato()) {
			Stanza DaImpostare=a.get(a.size()-1);
//			System.out.println("Prima Stanza"+OrdinaStanze(partita ).get(0).getNome());
			partita.setStanzaCorrente(DaImpostare);
				out.append(StanzaModificataMenoOggetti);

		}
		else {
			Stanza DaImpostare=a.get(0);
			partita.setStanzaCorrente(DaImpostare);
			out.append(StanzaModificataPiuOggetti);
		}
		return out.toString();
		
		
	
		
	}
private List<Stanza> OrdinaStanze(Partita part){
//	TreeSet<Stanza> stanzeOrdinate=new TreeSet<Stanza>(new ComparatoreNumeroAttrezzi());
	//*usare sempre iteratori sulle liste/mappe/set	
//			Iterator<Stanza> it =  part.getStanzaCorrente().GetStanzeAdiacentiStanze().iterator();
//			while(it.hasNext()) {
//				Stanza stanza=it.next();
//		
//				stanzeOrdinate.add(stanza);
//			}
	List<Stanza>s=part.getStanzaCorrente().GetStanzeAdiacentiStanze();
	Collections.sort(s,new ComparatoreAttrezzi());
	return s;
//return stanzeOrdinate;
}

@Override
public String riceviRegalo(Attrezzo attrezzo, Partita partita) {
	StringBuilder out= new StringBuilder();
	if(attrezzo!=null) {
		setAttrezzoRicevuto(attrezzo);
		out.append(attrezzoAccettato);
		partita.getStanzaCorrente().setPersonaggio(null);
	}
	else {
		out.append(attrezzoNonAccettato);
	}
	return out.toString();
}

public Attrezzo getAttrezzoRicevuto() {
	return attrezzoRicevuto;
}

public void setAttrezzoRicevuto(Attrezzo attrezzoRicevuto) {
	this.attrezzoRicevuto = attrezzoRicevuto;
}

@Override
public void setCiboPreferito(String ciboPreferito) {
	return;
	
}

@Override
public void setAttrezzo(Attrezzo attrezzo) {
	return;
	
}
}
