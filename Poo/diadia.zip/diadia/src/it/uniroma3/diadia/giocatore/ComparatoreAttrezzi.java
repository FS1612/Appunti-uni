package it.uniroma3.diadia.giocatore;

import java.util.Comparator;

import it.uniroma3.diadia.ambienti.Stanza;

public class ComparatoreAttrezzi implements Comparator<Stanza> {

	
	@Override
	public int compare(Stanza o1, Stanza o2) {
		
		return o2.GetListeAttrezzi().size()-o1.GetListeAttrezzi().size();
	}

}
