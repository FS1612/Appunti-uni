package it.uniroma3.diadia.giocatore;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public abstract class AbstractPersonaggio {
	private  String nome;
	private static String SalutiIniziali="Salve, piacere di conoscerti, io sono: ";
	private  String presentazione;
	private static String RispostaPerSalutiEffettuati="Ciao di nuovo, sono sempre io ";
	private boolean salutato;
	public AbstractPersonaggio(String nome, String Presentazione) {
		this.nome=nome;
		this.presentazione=Presentazione;
		this.salutato=false; 
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getPresentazione() {
		return presentazione;
	}
	public void setPresentazione(String presentazione) {
		this.presentazione = presentazione;
	}
	public String saluta() {
		StringBuilder out = new StringBuilder();
		if(!salutato)
		{
			out.append(SalutiIniziali+this.getNome()).append("s"+this.presentazione);
			this.salutato=true;
			}
		else {
			out.append(RispostaPerSalutiEffettuati+this.getNome()).append("\s"+".");
		}
		return out.toString();
		}
	abstract public String agisci(Partita partita);
	public String toString() {
		return this.getNome();
		}
	public boolean GetSalutato() {
		return this.salutato;
	}
	public abstract String riceviRegalo(Attrezzo attrezzo, Partita partita);
	abstract public void setCiboPreferito(String ciboPreferito);
	abstract public void setAttrezzo(Attrezzo attrezzo);
}
