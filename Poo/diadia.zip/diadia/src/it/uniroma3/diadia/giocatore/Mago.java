package it.uniroma3.diadia.giocatore;

import it.uniroma3.diadia.Partita;

import it.uniroma3.diadia.attrezzi.Attrezzo;

public class Mago extends AbstractPersonaggio {
	private Attrezzo attrezzoRicevuto;
	private final String attrezzoAccettato="Grazie per il regalo, ma non posso accettarlo. Ecco a te il tuo Strumento:";
	private final String attrezzoNonAccettato="Dammi qualcosa di meglio";
	private final static String nome="Mago";
	private final static String Presentazione="Sono una mago qualsiasi, metti alla prova i miei umili poteri.";
	private final static String strumentoAggiunto="Ho aggiunto alla stanza corrente il seguente attrezzo:\s";
	private Attrezzo a;
	public Mago(Attrezzo attrezzo) {
		super(nome, Presentazione);
		 a=attrezzo;
	}
	public Mago() {
	super(nome, Presentazione);
	}
	@Override
	public String agisci(Partita partita) {
		
		partita.getStanzaCorrente().addAttrezzoListe(a);
		String out=strumentoAggiunto+"\s"+a;
		a=null;
		
		return out;
	}

	@Override
	public String riceviRegalo(Attrezzo attrezzo, Partita partita) {
		StringBuilder out= new StringBuilder();
		if(attrezzo!=null) {
			
			
			setAttrezzoRicevuto(attrezzo);
			
			int peso=attrezzo.getPeso();
			attrezzoRicevuto.setPeso(peso/2);
			partita.getStanzaCorrente().addAttrezzoListe(attrezzoRicevuto);
			out.append("\s"+attrezzoAccettato+attrezzoRicevuto.getNome()+"\s"+ peso/2+"(kg)");
			this.setAttrezzoRicevuto(null);
		}
		else {
			out.append(attrezzoNonAccettato);
		}
		return out.toString();
	}
	public Attrezzo getAttrezzoRicevuto() {
		return attrezzoRicevuto;
	}

	public void setAttrezzoRicevuto(Attrezzo attrezzoRicevuto) {
		this.attrezzoRicevuto = attrezzoRicevuto;
	}

	@Override
	public void setCiboPreferito(String ciboPreferito) {
		return;
		
	}

	@Override
	public void setAttrezzo(Attrezzo attrezzo) {
		this.a=attrezzo;
		
	}
}
