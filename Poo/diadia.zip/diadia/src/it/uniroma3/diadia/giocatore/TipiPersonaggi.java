package it.uniroma3.diadia.giocatore;

public enum TipiPersonaggi {
	Cane,
	Mago,
	Strega;

}