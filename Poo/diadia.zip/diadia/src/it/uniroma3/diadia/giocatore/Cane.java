package it.uniroma3.diadia.giocatore;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.attrezzi.Attrezzo;

/**
 * @author francesco
 *Classe Che modella un cane.
 */
public class Cane extends AbstractPersonaggio{
	private final static String nome="Cane";
	private final static String Presentazione="Sono un cane, Bau bau";
	private final static String regalononaccettato="ARGHHHH";
	private final static String regaloaccettato="grazie del regalo, sembra molto gustoso";
	private final static String strumentoAggiunto="Ho aggiunto alla stanza corrente il seguente attrezzo:\s";
	private Attrezzo a;
	private Attrezzo nomeAttrezzo;
	private String cibo;
	/**
     * 
     * @param Attrezzo da restituire, Stringa contenente il nome del cibo preferito
     */
	public Cane(Attrezzo attrezzo,String preferito) {
		super(nome, Presentazione);
		 this.a=attrezzo;
		 this.cibo=preferito;
	}
	public Cane() {
		super(nome, Presentazione);
	}
	@Override
	public String agisci(Partita partita) {
		String out= new String();
		
		if(nomeAttrezzo!=null) {
			if(nomeAttrezzo.getNome().equals(cibo)) {
				out="Bau, bau";
			}
		}
		else {
			int cfu=	partita.GetGiocatore().GetCfu();
			cfu=cfu-1;
			partita.GetGiocatore().SetCfu(cfu);
			out="ora ti mordo";
		}
		return out;
	}

	@Override
	public String riceviRegalo(Attrezzo attrezzo, Partita partita) {
		this.nomeAttrezzo=attrezzo;
		StringBuilder out= new StringBuilder();
		if(attrezzo.getNome().equals(cibo)) {
			out.append(regaloaccettato);
			partita.getStanzaCorrente().addAttrezzoListe(a);
		out.append(strumentoAggiunto+"\s"+a);
		}
		else {
			out.append(regalononaccettato);
		}
		return out.toString();
	}

	@Override
	public void setCiboPreferito(String ciboPreferito) {
		this.cibo=ciboPreferito;
		
	}

	@Override
	public void setAttrezzo(Attrezzo attrezzo) {
		this.a=attrezzo;
		
	}
	
}
