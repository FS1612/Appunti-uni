/**
 * 
 */
package it.uniroma3.diadia;

import java.util.Scanner;

/**
 * @author francesco
 *
 */
public class IoConsole implements IO{
	private Scanner scannerDiLinee;
	
	public IoConsole() {
		this.scannerDiLinee=new Scanner(System.in);
	}
	
	public IoConsole(Scanner scannerDiLinee) {
		this.scannerDiLinee=scannerDiLinee;
	}

	public void mostraMessaggio(String msg) {
		System.out.println(msg);
	}
	public String leggiRiga() {
		this.scannerDiLinee = new Scanner(System.in);
		String riga = scannerDiLinee.nextLine();
		return riga;
	}
}