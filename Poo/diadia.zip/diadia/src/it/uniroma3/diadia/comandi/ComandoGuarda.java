package it.uniroma3.diadia.comandi;

//import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.Partita;

import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.giocatore.Borsa;

public class ComandoGuarda extends AbstractComando {
//private IO io;
private  String NOME="Guarda";

	public ComandoGuarda() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void esegui(Partita partita) {
		Stanza Corrente= partita.getStanzaCorrente();
		Borsa borsa= partita.GetGiocatore().GetBorsa();
		super.GetIo().mostraMessaggio("Stato Partita :"+"\n"+"con "+ (20-partita.getCfu()) 
				+ " mosse hai raggiunto: "+"\n"+ Corrente +"\n"+"con "+ partita.getCfu()+" cfu"
				+"\n"+borsa);
	}

//	@Override
//	public void setParametro(String parametro) {
//		// TODO Auto-generated method stub
//
//	}

	@Override
	public String getNome() {
		
		return this.NOME;
	}

	

//	@Override
//	public String getParametro() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public void SetIO(IO Io) {
//		this.io=Io;
//
//	}

}
