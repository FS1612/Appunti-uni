/**
 * 
 */

package it.uniroma3.diadia.comandi;

import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.Partita;


/**
 * @author francesco
 *
 */
public interface Comandi {

	public void esegui(Partita partita);
	public void setParametro(String nord);

	public String getNome();
	public String getParametro();
	public void SetIO(IO Io);
}

