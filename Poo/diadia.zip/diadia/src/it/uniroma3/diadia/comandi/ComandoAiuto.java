package it.uniroma3.diadia.comandi;

//import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.Partita;


public class ComandoAiuto extends AbstractComando {
//private IO io;
//private String parametro;
private String NOME= "aiuto";
static final private String[] elencoComandi = {"vai", "aiuto", "fine","prendi","posa","guarda","interagisci","saluta"};
//	public ComandoAiuto() {
//		// TODO Auto-generated constructor stub
//	}
//
	@Override
	public void esegui(Partita partita) {
		
		super.GetIo().mostraMessaggio("comandi a disposizione : " );
		for(int i=0; i< elencoComandi.length; i++) 
			super.GetIo().mostraMessaggio(elencoComandi[i]+" ");
		super.GetIo().mostraMessaggio("\n");
	}
//
//	@Override
//	public void setParametro(String parametro) {
//		this.parametro=parametro;
//
//	}
//
	@Override
	public String getNome() {
		
		return this.NOME;
	}
//
//	@Override
//	public String getParametro() {
//		
//		return this.parametro;
//	}
//
//	@Override
//	public void SetIO(IO Io) {
//		this.io=Io;
//
//	}
	
	

}
