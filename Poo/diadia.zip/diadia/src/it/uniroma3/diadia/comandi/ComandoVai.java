package it.uniroma3.diadia.comandi;

//import it.uniroma3.diadia.IO;

import it.uniroma3.diadia.Partita;
import it.uniroma3.diadia.ambienti.DirezioniValide;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.ambienti.StanzaBloccata;

public class ComandoVai extends AbstractComando {
// private String direzione;
//	private IO io;
	private  String NOME="vai";
	public static final String OUTPUT_DIREZIONE_INESISTENTE="Non Puoi Andare li: direzione inesistente";
	public static final String OUTPUT_VAI_SENZA_DIREZIONE="Dove vuoi andare?";
	@Override
	public void esegui(Partita partita) {
		Stanza StanzaCorrente =partita.getStanzaCorrente();
		Stanza Prossima=null;
		if(super.getParametro()!=null) { 
		if(parseDir(super.getParametro())==null) {
		super.GetIo().mostraMessaggio(OUTPUT_VAI_SENZA_DIREZIONE);
		return;
	}
		
	Prossima=StanzaCorrente.getStanzaAdiacenteMappa(parseDir(super.getParametro()));
		}

	if(Prossima==null) {
		super.GetIo().mostraMessaggio(partita.getStanzaCorrente().getDescrizione());
		super.GetIo().mostraMessaggio(OUTPUT_DIREZIONE_INESISTENTE);
		
	}
	else if(Prossima.getDescrizione().equals("stanza bloccata")){
		StanzaBloccata Stanzabloccata =(StanzaBloccata) Prossima;
		super.GetIo().mostraMessaggio(Stanzabloccata.getDescrizione());
		super.GetIo().mostraMessaggio("Ti trovi ancora in:"+"\n"+partita.getStanzaCorrente().getDescrizione()+
				"\n"+"Hai "+partita.GetGiocatore().GetCfu()+" cfu"+"\n"+partita.GetGiocatore().GetBorsa().toString());
		
	}
	
	else {
		partita.setStanzaCorrente(Prossima);
		
		int cfu=partita.GetGiocatore().GetCfu();
		partita.GetGiocatore().SetCfu(cfu-1);
		super.GetIo().mostraMessaggio("Ti trovi in:"+"\n"+partita.getStanzaCorrente().getDescrizione()+
				"\n"+"Hai "+partita.GetGiocatore().GetCfu()+" cfu"+"\n"+partita.GetGiocatore().GetBorsa().toString());

		
	}
		
	}

//	@Override
//	public void setParametro(String parametro) {
//		this.direzione=parametro;
//		
//	}

	
	public String getNome() {
		
		return this.NOME;
	}

	

	
//	public String getParametro() {
//		
//		return this.direzione;
//	}
//	
//	public void SetIO(IO Io) {
//		this.io=Io;
//		
//	}
private DirezioniValide parseDir(String dir) {
	DirezioniValide out=null;
	if(dir.equals("nord")) {
		out=DirezioniValide.NORD;}
	if(dir.equals("sud")) {
		out=DirezioniValide.SUD;
	}
	if(dir.equals("est")) {
		out=DirezioniValide.EST;
	}
	if(dir.equals("ovest")) {
		out=DirezioniValide.OVEST;
	}
	return out;
}
}
