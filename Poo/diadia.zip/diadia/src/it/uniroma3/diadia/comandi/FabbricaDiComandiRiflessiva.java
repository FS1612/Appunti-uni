package it.uniroma3.diadia.comandi;

import java.util.Scanner;

import it.uniroma3.diadia.IO;



public class FabbricaDiComandiRiflessiva implements FabbricaDiComandi {
	public Comandi costruisciComando(String istruzione,IO Io) {
		@SuppressWarnings("resource")
		Scanner scannerDiParole = new Scanner(istruzione);
		String nomeComando = null; 
		String parametro = null;
		Comandi comando = null;
//		System.out.println("Eseguo");
		if (scannerDiParole.hasNext()) {
			nomeComando = scannerDiParole.next(); // prima parola: nome del comando
//			System.out.println(nomeComando);
			}
			
		if (scannerDiParole.hasNext()) {
			parametro = scannerDiParole.next();// seconda parola: eventuale parametro
//			System.out.println(parametro);
			}
		try {
			String nomeClasse = "it.uniroma3.diadia.comandi.Comando";
			nomeClasse += Character.toUpperCase(nomeComando.charAt(0));
//			System.out.println(nomeClasse);
			nomeClasse += nomeComando.substring(1);
//			System.out.println(nomeClasse);
			comando = (Comandi)Class.forName(nomeClasse).getConstructor().newInstance();
//			System.out.println(comando);
			comando.setParametro(parametro);
			comando.setParametro(parametro);
//			System.out.println(comando.getParametro());
		} catch (Exception e) { 
			comando = new ComandoNonValido();
			comando.setParametro("Comando inesistente");
		}
		return comando;
	}

	


}
