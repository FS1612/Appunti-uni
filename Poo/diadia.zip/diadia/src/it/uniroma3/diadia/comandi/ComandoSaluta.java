/**
 * 
 */
package it.uniroma3.diadia.comandi;

import it.uniroma3.diadia.Partita;


/**
 * @author francesco
 *
 */
public class ComandoSaluta extends AbstractComando{
private final String Nome= "saluta";
	/**
	 * 
	 */
	

	@Override
	public void esegui(Partita partita) {
		partita.getStanzaCorrente().getPersonaggio().saluta();
		
	}

	@Override
	public String getNome() {
		
		return this.Nome;
	}


}
