package it.uniroma3.diadia.comandi;

//import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.Partita;

import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.giocatore.Borsa;

public class ComandoPosa extends AbstractComando {
//private String parametro;
//private IO io;
	public static final String OUTPUT_NON_TROVATO="Oggetto non trovato in borsa";
	public static  String OUTPUT_POSATO="";
	
private String Nome="Posa";
	public ComandoPosa() {
		// TODO Auto-generated constructor stub
	}


	@Override
	public void esegui(Partita partita) {
		Attrezzo Darimuovere=partita.GetGiocatore().GetBorsa().getAttrezzoLista(super.getParametro());
		Borsa borsa =partita.GetGiocatore().GetBorsa();
		Stanza Corrente=partita.getStanzaCorrente();
       if(borsa.hasAttrezzoLista(super.getParametro())) {
    	   OUTPUT_POSATO=OUTPUT_POSATO.concat("Cfu Attuali:"+"\t"+partita.getCfu()+"\n"+"ti trovi in:"+"\n"+Corrente
				+"\n"+partita.GetGiocatore().GetBorsa().toString());
    	   Corrente.addAttrezzoListe(Darimuovere);
    	   borsa.removeAttrezzoLista(super.getParametro());
    	   
    	   super.GetIo().mostraMessaggio(OUTPUT_POSATO);

       }
       else {
    	   super.GetIo().mostraMessaggio(OUTPUT_NON_TROVATO);
    	   super.GetIo().mostraMessaggio("Cfu Attuali:"+"\t"+partita.getCfu()+"\n"+"ti trovi in:"+"\n"+Corrente
   				+"\n"+partita.GetGiocatore().GetBorsa().toString());
       }
    	 
	}
	/****************************LISTA*************************************************/
//	@Override
//	public void setParametro(String parametro) {
//		this.parametro=parametro;
//
//	}

	@Override
	public String getNome() {
		
		return this.Nome;
	}



//	@Override
//	public String getParametro() {
//		
//		return this.parametro;
//	}
//
//	@Override
//	public void SetIO(IO Io) {
//		this.io=Io;
//
//	}

}
