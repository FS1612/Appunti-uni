/**
 * 
 */
package it.uniroma3.diadia.comandi;

import it.uniroma3.diadia.Partita;

import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.giocatore.Borsa;

/**
 * @author francesco
 *
 */
public class ComandoRegala extends AbstractComando{
private final String Nome ="regala";
Borsa borsa;
	/**
	 * 
	 */
	

	@Override
	public void esegui(Partita partita) {
		borsa=partita.GetGiocatore().GetBorsa();
		String nomeAttrezzo=super.getParametro();
		Attrezzo a=borsa.getAttrezzoLista(nomeAttrezzo);
		if(this.borsa.hasAttrezzoLista(nomeAttrezzo)&&partita.getStanzaCorrente().getPersonaggio()!=null) {
			borsa.removeAttrezzoLista(nomeAttrezzo);
			
			super.GetIo().mostraMessaggio(partita.getStanzaCorrente().getPersonaggio().riceviRegalo(a, partita));
			
			
		}
		else if(!this.borsa.hasAttrezzoLista(nomeAttrezzo)&&partita.getStanzaCorrente().getPersonaggio()!=null){
			super.GetIo().mostraMessaggio("l'attrezzo: "+nomeAttrezzo+" non � presente nella borsa. Puoi regalare solo attrezzi estitenti.");
		}
		else {
			super.GetIo().mostraMessaggio("nella stanza non ci sta alcun personaggio\n");
		}
		
	}

	@Override
	public String getNome() {
		
		return this.Nome;
	}

	

}
