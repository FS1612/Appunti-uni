package it.uniroma3.diadia.comandi;

import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.Partita;


public abstract class AbstractComando implements Comandi {
	private IO io;
	private String parametro;

	public AbstractComando() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public abstract void esegui(Partita partita) ;
	@Override
	public void setParametro(String parametro) {
		this.parametro=parametro;

	}

	@Override
	public abstract String getNome();
		
	

	@Override
	public String getParametro() {
		
		return this.parametro;
	}

	@Override
	public void SetIO(IO Io) {
		this.io=Io;

	}
	public IO GetIo() {
		return this.io;
	}

	

}
