package it.uniroma3.diadia.comandi;

//import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.Partita;

import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.attrezzi.Attrezzo;

public class ComandoPrendi extends AbstractComando {
	public static final String OUTPUT_SUCCESSO="Attrezzo messo in borsa";
	public static final String OUTPUT_NON_TROVATO_PRENDI="Attezzo non presente nella stanza";
	public static final String OUTPUT_PRENDI_SENZA_PARAMETRO= "Quale attrezzo vuoi prendere?";


//private String parametro;
private String Nome ="Prendi";
//private IO io;
	public ComandoPrendi() {
		// TODO Auto-generated constructor stub
	}


	/***********************************lista*************************/
	
	@Override
	public void esegui(Partita partita) {
		
		
		Stanza StanzaCorrente=partita.getStanzaCorrente();
		
		if(StanzaCorrente.hasAttrezzoListe(super.getParametro())) {
			Attrezzo Darimuovere=StanzaCorrente.getAttrezzoListe(super.getParametro());
			
			
	if(	partita.GetGiocatore().GetBorsa().addAttrezzoLista(Darimuovere)) {
		StanzaCorrente.removeAttrezzoListe(Darimuovere);
	}
	
		
		super.GetIo().mostraMessaggio(OUTPUT_SUCCESSO);
		}
		else {
			super.GetIo().mostraMessaggio(OUTPUT_NON_TROVATO_PRENDI);
//			super.GetIo().mostraMessaggio("Cfu Attuali:"+"\t"+partita.getCfu()+"\n"+"ti trovi in:"+"\n"+StanzaCorrente
//				+"\n"+partita.GetGiocatore().GetBorsa().toString());
		}
		}
	
	/***********************************lista*************************/
//	@Override
//	public void setParametro(String parametro) {
//		this.parametro=parametro;
//
//	}

	@Override
	public String getNome() {
		
		return this.Nome;
	}


	

//	@Override
//	public String getParametro() {
//		
//		return this.parametro;
//	}

//	@Override
//	public void SetIO(IO Io) {
//		this.io=Io;
//
//	}

}
