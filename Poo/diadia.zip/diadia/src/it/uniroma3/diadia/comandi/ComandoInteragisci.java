/**
 * 
 */
package it.uniroma3.diadia.comandi;

import it.uniroma3.diadia.Partita;

import it.uniroma3.diadia.giocatore.AbstractPersonaggio;

/**
 * @author francesco
 *
 */
public class ComandoInteragisci extends AbstractComando {

	/**
	 * 
	 */
	private final  String Nome="interagisci";
	public ComandoInteragisci() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void esegui(Partita partita) {
		 AbstractPersonaggio personaggio;
		 
		personaggio=partita.getStanzaCorrente().getPersonaggio();
		//* passo partita perche mi serve saper nella stanza della partita quali sono gli strumenti e quali sono le stanze adiacenti
		super.GetIo().mostraMessaggio(personaggio.agisci(partita));
	}

	@Override
	public String getNome() {
		
		return this.Nome;
	}

	

}
