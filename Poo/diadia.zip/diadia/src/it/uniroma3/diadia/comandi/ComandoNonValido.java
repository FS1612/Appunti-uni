package it.uniroma3.diadia.comandi;

//import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.Partita;


;

public class ComandoNonValido extends AbstractComando {
//private IO io;
private String Nome="non valido";
public static final String OUTPUT_NON_VALIDO = "Comando non valido!";
	public ComandoNonValido() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void esegui(Partita partita) {
		super.GetIo().mostraMessaggio("Comando non valido");

	}

	

//	@Override
//	public void setParametro(String parametro) {
//		// TODO Auto-generated method stub
//
//	}

	@Override
	public String getNome() {
		return this.Nome;
	}
//
//	@Override
//	public String getParametro() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public void SetIO(IO Io) {
//		this.io=Io;
//
//	}

	
}
