
package  it.uniroma3.diadia;
import java.util.ArrayList;
import java.util.List;

import it.uniroma3.diadia.ambienti.Labirinto;
import it.uniroma3.diadia.ambienti.LabirintoPredefinito;
import it.uniroma3.diadia.ambienti.Stanza;
import it.uniroma3.diadia.giocatore.Borsa;
import it.uniroma3.diadia.giocatore.Giocatore;

/**
 * Questa classe modella una partita del gioco
 *
 * @author  docente di POO
 * @see Stanza
 * @version base
 */

public class Partita {
 Labirinto lab;
 Giocatore giocatore;
 private Stanza Corrente;
	private Stanza Vincente;
	private boolean finita;
	private List<String> percorso;
	public Partita() {
		this(new LabirintoPredefinito());
	}

	public Partita(Labirinto labirinto){
		this.lab=labirinto;
		giocatore =new Giocatore();
		Vincente = this.lab.GetStanzaVincente();
		Corrente = this.lab.GetStanzaIniziale();
		this.finita = false;
		this.percorso=new ArrayList<String>();

	}

	public Stanza getStanzaVincente() {

		return this.Vincente;
	}

	public void setStanzaCorrente(Stanza stanzaCorrente) {
		this.Corrente = stanzaCorrente;
		this.percorso.add(stanzaCorrente.toString());
//		this.lab.SetStanzaCorrente(stanzaCorrente); 
	}

	public Stanza getStanzaCorrente() {

		return this.Corrente;
	}
	
	/**
	 * Restituisce vero se e solo se la partita e' stata vinta
	 * @return vero se partita vinta
	 */
	public boolean vinta() {
		return this.getStanzaCorrente()==this.getStanzaVincente()
;	}
	
	

	/**
	 * Restituisce vero se e solo se la partita e' finita
	 * @return vero se partita finita
	 */
	public boolean isFinita() {
		 
		 return (finita || vinta() || (this.giocatore.GetCfu() == 0));
//		
		
	}

	/**
	 * Imposta la partita come finita
	 *
	 */
	public void setFinita() {
		this.finita = true;
	}

	public int getCfu() {
		return this.giocatore.GetCfu();
	}

	public void setCfu(int cfu) {
		this.giocatore.SetCfu(cfu); 	
	}	
	public Giocatore GetGiocatore() {
		return this.giocatore;
	}
	public void SetStanzaVincente(Stanza v) {
		this.Vincente=v;
	}
	public void SetGiocatore(Giocatore giocatore) {
		this.giocatore=giocatore;
	}
	public void SetBorsa(Borsa borsa) {
		this.giocatore.SetBorsa(borsa);;
	}
	public void setLabirinto(Labirinto labirinto) {
		this.lab=labirinto;
	}
	public String getPercorso(int tappe) {
		return this.percorso.get(tappe);
	}
}
