package it.uniroma3.diadia.ambienti;

public enum DirezioniValide {
	NORD,
	SUD,
	EST,
	OVEST;
}
