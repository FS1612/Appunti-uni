package it.uniroma3.diadia.ambienti;

import java.util.Iterator;
import java.util.LinkedList;

import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.giocatore.AbstractPersonaggio;
import it.uniroma3.diadia.giocatore.Cane;
import it.uniroma3.diadia.giocatore.Mago;
import it.uniroma3.diadia.giocatore.Strega;

public interface Labirinto {
	

	public void CreaStanze();
	public Stanza GetStanzaIniziale();
	public void SetStanzaIniziale(Stanza c);
	public void SetStanzaCorrente(Stanza c);
	public Stanza GetStanzaCorrente();
	public void SetStanzaVincente(Stanza v);
	public Stanza GetStanzaVincente();
	public void setStanzaIniziale();
	public Stanza getStanza(String nomeStanza);

	static  class LabirintoBuilder implements Labirinto {
		public static LabirintoBuilder newBuilder() {
			return new LabirintoBuilder();
		}
		private Stanza Ingresso;
		private Stanza Fine;
		private Stanza Corrente;
		private Stanza ultimaStanzaAggiunta;
		private LinkedList<Stanza> labirintoCostruito;
		public LabirintoBuilder() {
			CreaStanze();
		}

		@Override
		public void CreaStanze() {
			labirintoCostruito= new LinkedList<Stanza>();

		}

		public LabirintoBuilder AddIniziale(String i) {

			this.Ingresso=new Stanza(i);		
			this.labirintoCostruito.add(Ingresso);
			this.Corrente=Ingresso;
			return this;
		}
		public LabirintoBuilder AddFinale(String f) {

			this.Fine=new Stanza(f);
			this.labirintoCostruito.add(Fine);
			return this;
		}
		public LabirintoBuilder addAttrezzo(String nomeAttrezzo,int peso) {
			if(labirintoCostruito.isEmpty() ) 
				this.Fine.addAttrezzoListe(new Attrezzo(nomeAttrezzo,peso));
			else 
				labirintoCostruito.get(labirintoCostruito.size()-1).addAttrezzoListe(new Attrezzo(nomeAttrezzo,peso));
			return this;
		}
		public LabirintoBuilder addAttrezzoStanza(String nomeStanza,String nomeAttrezzo, int pesoAttrezzo) {
			@SuppressWarnings("unused")
			Stanza a= null;
			int i=0;
				for(Stanza c:labirintoCostruito) {
					if(c.getNome().equals(nomeStanza)) {
						a=c;
						i++;
					}
				}
				this.labirintoCostruito.get(i).
				addAttrezzoListe(new Attrezzo(nomeAttrezzo,pesoAttrezzo));
			
			return this;
		}
		public LabirintoBuilder addStanza(String nomeStanza) {
			Stanza nuovaStanza=new Stanza(nomeStanza);
			labirintoCostruito.add(nuovaStanza);
			ultimaStanzaAggiunta=nuovaStanza;
			return this;
		}
		public LabirintoBuilder addAdiacenza(String nomeStanza, String nomeAdiacenza, DirezioniValide direzioniValide) {

			this.getStanza(nomeStanza);

			int index=labirintoCostruito.indexOf(this.getStanza(nomeStanza));


			Stanza stanza= labirintoCostruito.get(index);
			index=labirintoCostruito.indexOf(this.getStanza(nomeAdiacenza));

			Stanza stanzaAdiacente=labirintoCostruito.get(index);
			if(stanza!=null && stanzaAdiacente!=null) {
				stanza.impostaStanzaAdiacenteMappa(direzioniValide, stanzaAdiacente);
				stanzaAdiacente.impostaStanzaAdiacenteMappa(getDirezioneOpposta(direzioniValide), stanza);
			}






			return this;

		}
		
		private DirezioniValide getDirezioneOpposta(DirezioniValide direzione) {
			
			if(direzione.equals(DirezioniValide.NORD))
				return DirezioniValide.SUD;
			if(direzione.equals(DirezioniValide.SUD))
				return DirezioniValide.NORD;
			if(direzione.equals(DirezioniValide.EST))
				return DirezioniValide.OVEST;
			return DirezioniValide.EST;
		}
		@Override
		public Stanza GetStanzaIniziale() {

			return this.Ingresso;
		}

		@Override
		public void SetStanzaIniziale(Stanza c) {
			this.Ingresso=c;

		}

		@Override
		public void SetStanzaCorrente(Stanza c) {
			this.Corrente=c;

		}

		@Override
		public Stanza GetStanzaCorrente() {

			return this.Corrente;
		}

		@Override
		public void SetStanzaVincente(Stanza v) {
			this.Fine=v;

		}

		@Override
		public Stanza GetStanzaVincente() {

			return this.Fine;
		}
		public LabirintoBuilder AddStanzaMagica(String m,int soglia) {
			Stanza magica =new StanzaMagica(m,soglia);
			this.labirintoCostruito.add(magica);
			ultimaStanzaAggiunta=magica;
			return this;
		}
		public LabirintoBuilder AddStanzaBloccata(String m,String oggetto, DirezioniValide sud) {
			Stanza Bloccata =new StanzaBloccata(m).setChiave(oggetto).setDirezione(sud);
			this.labirintoCostruito.add(Bloccata);
			ultimaStanzaAggiunta=Bloccata;
			return this;
		}
		public LabirintoBuilder AddStanzaBloccata(String m,String direzione, String attrezzo) {
			Stanza Bloccata =new StanzaBloccata(m,direzione, attrezzo);
			this.labirintoCostruito.add(Bloccata);
			ultimaStanzaAggiunta=Bloccata;
			return this;
		}
		public LabirintoBuilder AddStanzaBuia(String oggetto,String nome) {
			Stanza Buia =new StanzaBuia(oggetto, nome);
			this.labirintoCostruito.add(Buia);
			ultimaStanzaAggiunta=Buia;
			return this;
		}
		public Labirinto GetLabirinto() {
			return this;
		}
		
		public LabirintoBuilder addStrega(String nomeStanza) {
			AbstractPersonaggio Strega =new Strega();

			Stanza a=this.getStanza(nomeStanza);

			a.setPersonaggio(Strega);
			return this;
		}
		public LabirintoBuilder addMago(String nomeStanza,Attrezzo b) {
			AbstractPersonaggio Mago= new Mago(b);
			Stanza a=this.getStanza(nomeStanza);
			a.setPersonaggio(Mago);
			return this;
		}
		public LabirintoBuilder addCane(String nomeStanza,Attrezzo b,String cibo) {
			AbstractPersonaggio Cane= new Cane(b,cibo);
			Stanza a=this.getStanza(nomeStanza);
			a.setPersonaggio(Cane);
			return this;
		}
		public LabirintoBuilder addAdiacenza2(String nomeStanza, String nomeAdiacenza, DirezioniValide direzione) {

			this.getStanza(nomeStanza);

			int index=labirintoCostruito.indexOf(this.getStanza(nomeStanza));


			Stanza stanza= labirintoCostruito.get(index);
			index=labirintoCostruito.indexOf(this.getStanza(nomeAdiacenza));

			Stanza stanzaAdiacente=labirintoCostruito.get(index);
			if(stanza!=null && stanzaAdiacente!=null) {
				stanza.impostaStanzaAdiacenteMappa(direzione, stanzaAdiacente);
			}






			return this;

		}

		
		 public void setStanzaIniziale() {
				this.Ingresso=this.labirintoCostruito.get(0);
			}
		 public void setStanzaVincenteBuilder() {
				this.Fine=ultimaStanzaAggiunta;
				
			}

		@Override
		public Stanza getStanza(String nomeStanza) {
			Stanza ricercata=null;
			Iterator<Stanza> it= labirintoCostruito.iterator();
			while(it.hasNext()) {
				Stanza Corrente=it.next();
				if(Corrente.getNome().equals(nomeStanza)) {
					ricercata=Corrente;
		}
	}
			return ricercata;
}
	}
}