/**
 * 
 */
package it.uniroma3.diadia.ambienti;


import it.uniroma3.diadia.attrezzi.Attrezzo;

/**
 * @author francesco
 *
 */
public class LabirintoPredefinito implements Labirinto{
	private Stanza StanzaIniziale;
	
	private Stanza stanzaCorrente;
	private Stanza stanzaVincente;
	public LabirintoPredefinito () {

		CreaStanze();
	}

	@Override
	public void CreaStanze() {
		/* crea stanze del labirinto */
		Stanza atrio = new Stanza("Atrio");
		Stanza aulaN11 = new Stanza("Aula N11");
		Stanza aulaN10 = new Stanza("Aula N10");
		Stanza laboratorio = new Stanza("Laboratorio Campus");
		Stanza biblioteca = new Stanza("Biblioteca");
		/* collega le stanze */
		atrio.impostaStanzaAdiacenteMappa(DirezioniValide.NORD, biblioteca);
		atrio.impostaStanzaAdiacenteMappa(DirezioniValide.EST, aulaN11);
		atrio.impostaStanzaAdiacenteMappa(DirezioniValide.SUD, aulaN10);
		atrio.impostaStanzaAdiacenteMappa(DirezioniValide.OVEST, laboratorio);
		aulaN11.impostaStanzaAdiacenteMappa(DirezioniValide.EST, laboratorio);
		aulaN11.impostaStanzaAdiacenteMappa(DirezioniValide.OVEST, atrio);
		aulaN10.impostaStanzaAdiacenteMappa(DirezioniValide.NORD, atrio);
		aulaN10.impostaStanzaAdiacenteMappa(DirezioniValide.EST, aulaN11);
		aulaN10.impostaStanzaAdiacenteMappa(DirezioniValide.OVEST, laboratorio);
		laboratorio.impostaStanzaAdiacenteMappa(DirezioniValide.EST, atrio);
		laboratorio.impostaStanzaAdiacenteMappa(DirezioniValide.OVEST, aulaN11);
		biblioteca.impostaStanzaAdiacenteMappa(DirezioniValide.SUD, atrio);
		/* pone gli attrezzi nelle stanze */
		Attrezzo lanterna =new Attrezzo("lanterna",10);
		Attrezzo osso =new Attrezzo("osso",1);
		
		Attrezzo attrezzo1 =new Attrezzo("attrezzo1",4);
		Attrezzo attrezzo2 =new Attrezzo("attrezzo2",14);
		
		
		
		aulaN10.addAttrezzoListe(lanterna);

		atrio.addAttrezzoListe(osso);
		atrio.addAttrezzoListe(attrezzo1);
		atrio.addAttrezzoListe(attrezzo2);
		// il gioco comincia nell'atrio
		stanzaCorrente = atrio;  
		stanzaVincente = biblioteca;
		StanzaIniziale=atrio;
	}

	public Stanza GetStanzaIniziale() {
		return this.StanzaIniziale;
	}
	public void SetStanzaIniziale(Stanza c) {
		 this.StanzaIniziale=c;
	}
	
	public void SetStanzaCorrente(Stanza c) {
		 this.stanzaCorrente=c;
	}
	public Stanza GetStanzaCorrente() {
		return this.stanzaCorrente;
	}
	public void SetStanzaVincente(Stanza v) {
		 this.stanzaVincente=v;
	}
	public Stanza GetStanzaVincente() {
		return this.stanzaVincente;
	}
	public boolean GetVinta() {
		return this.GetStanzaCorrente()== this.GetStanzaVincente();
		
	}

	@Override
	public void setStanzaIniziale() {
		return;
		
	}

	@Override
	public Stanza getStanza(String nomeStanza) {
		return this.getStanza(nomeStanza);
}
	}


	

