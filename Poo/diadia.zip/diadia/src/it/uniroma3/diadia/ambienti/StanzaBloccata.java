package it.uniroma3.diadia.ambienti;

public class StanzaBloccata extends Stanza{
private DirezioniValide Direzionechiusa;
	private String DirezioneBloccata;
	private String AttrezzoSblocco;
	public StanzaBloccata(String nome, String direzione, String attrezzo) {
		super(nome);
		this.DirezioneBloccata=direzione;
		this.AttrezzoSblocco=attrezzo;
	}
	public StanzaBloccata(String nome) {
		super(nome);
		setDirezionechiusa(null);
		AttrezzoSblocco=null;
	}
@Override
public Stanza getStanzaAdiacenteMappa(DirezioniValide direzione) {

	if(!CalcolaDirezione( direzione).equals(DirezioneBloccata))
    	return super.getStanzaAdiacenteMappa(direzione);
    else
    	
    return  this;
}
@Override
public String getDescrizione() {
	if(super.hasAttrezzoListe(AttrezzoSblocco)) 
		return super.getDescrizione();
	else  
	return "stanza bloccata";
}
private DirezioniValide CalcolaDirezione(DirezioniValide dir) {
	DirezioniValide risultato = null;
	if(dir.equals(DirezioniValide.NORD)) {
		risultato=DirezioniValide.SUD; 
	}
	else if(dir.equals(DirezioniValide.SUD)) {
		risultato=DirezioniValide.NORD; 
	}
	else if(dir.equals(DirezioniValide.EST)) {
		risultato=DirezioniValide.OVEST; 
	}
	if(dir.equals(DirezioniValide.OVEST)) {
		risultato=DirezioniValide.EST; 
	}
	return risultato;
}
public StanzaBloccata setChiave(String c) {
	this.AttrezzoSblocco=c;
	return this;
	
}
public StanzaBloccata setDirezione(DirezioniValide n) {
	this.setDirezionechiusa(n);
	return this;
}
public DirezioniValide getDirezionechiusa() {
	return Direzionechiusa;
}
public void setDirezionechiusa(DirezioniValide direzionechiusa) {
	Direzionechiusa = direzionechiusa;
}
}
