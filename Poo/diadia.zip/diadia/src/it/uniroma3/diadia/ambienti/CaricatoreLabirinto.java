package it.uniroma3.diadia.ambienti;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;

import java.util.HashSet;

import java.util.Scanner;
import java.util.Set;

import it.uniroma3.diadia.ambienti.Labirinto.LabirintoBuilder;
import it.uniroma3.diadia.attrezzi.Attrezzo;
import it.uniroma3.diadia.giocatore.AbstractPersonaggio;
import it.uniroma3.diadia.giocatore.TipiPersonaggi;


public class CaricatoreLabirinto {
	private final String  STANZE   = "Stanze:";
	private final String  ESTREMI  = "Estremi:";
	private final String  ATTREZZI = "Attrezzi:";
	private final String  USCITE   = "Uscite:";
	private final String  BUIE   = "Buie:";
	private final String  BLOCCATE   = "Bloccate:";
	private final String  MAGICHE = "Magiche:";
	private final String PERSONAGGI="Personaggi:";

	private BufferedReader reader;
	private Set<String> stanze;

	private int numeroLinea;
	private LabirintoBuilder builder;

	public CaricatoreLabirinto(String nomeFile) {
		this.stanze = new HashSet<String>();
		this.numeroLinea = 0;
		this.builder = new Labirinto.LabirintoBuilder();
		try {
			this.reader = new BufferedReader(new FileReader(nomeFile));
		} catch (FileNotFoundException e) {
			System.err.println("File " + nomeFile + " non trovato");
			e.printStackTrace();
		}
	}

	public CaricatoreLabirinto(StringReader lettoreString) throws FormatoFileNonValidoException{
		this.stanze = new HashSet<String>();
		this.numeroLinea = 0;
		this.reader = new BufferedReader(lettoreString);
		this.builder = new LabirintoBuilder();
	}

	public void carica() {
		try {
			
			this.leggiStanze();
			
			this.leggiStanzeMagiche();
			this.leggiStanzeBuie();
			this.leggiStanzeBloccate();
			this.leggiPersonaggio();
			this.leggiInizialeEvincente();
			this.leggiAttrezzi();
			this.leggiUscite();
		} catch (FormatoFileNonValidoException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				this.reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	
	private void leggiPersonaggio() throws FormatoFileNonValidoException {
		String tipoPersonaggio=null;		
		String ciboPreferito=null;
		String stanzaAssegnata=null;
		Attrezzo attrezzo=null;
		AbstractPersonaggio personaggio=null;
		String rigaLetta=this.leggiRiga(reader);
		while(!rigaLetta.equals(ESTREMI)) {
			StringBuilder s=new StringBuilder(rigaLetta);
			if(s.charAt(0)<='z'  && s.charAt(0)>='a') {
				s.setCharAt(0,(char)(rigaLetta.charAt(0)-32));
			}
			try {
				tipoPersonaggio=rigaLetta;
				stanzaAssegnata=this.leggiRiga(reader);
				if(!(stanzaValida(stanzaAssegnata)))
					throw new FormatoFileNonValidoException("Definizione Stanza  errata [" + this.numeroLinea + "]" + ": stanza " + stanzaAssegnata + " inesistente");
				@SuppressWarnings("unchecked")
				Class<AbstractPersonaggio> temp= (Class<AbstractPersonaggio>) Class.forName("it.uniroma3.diadia.giocatore."+s.toString());
				personaggio=temp.getConstructor().newInstance();
				this.builder.getStanza(stanzaAssegnata).setPersonaggio(personaggio);
			} 
			catch (Exception e) {
				throw new FormatoFileNonValidoException("Formato file non valido [" + this.numeroLinea + "]:");
			}
			try {
				
				if(tipoPersonaggio.equals(TipiPersonaggi.Cane.toString())) {
					String rigaAttrezzo= this.leggiRiga(reader);
					int peso=this.parseStringToInt(rigaAttrezzo);
					String nomeAttrezzo=this.parseNome(rigaAttrezzo);
					attrezzo=new Attrezzo(nomeAttrezzo, peso); 
					personaggio.setAttrezzo(attrezzo);
					personaggio.setCiboPreferito(ciboPreferito);
					rigaLetta=this.leggiRiga(reader);
					tipoPersonaggio=rigaLetta;
				}
				if(tipoPersonaggio.equals(TipiPersonaggi.Mago.toString())) {
					
					String rigaAttrezzo= this.leggiRiga(reader);
					int peso=this.parseStringToInt(rigaAttrezzo);
					String nomeAttrezzo=this.parseNome(rigaAttrezzo);
					attrezzo=new Attrezzo(nomeAttrezzo, peso);
					personaggio.setAttrezzo(attrezzo);
					rigaLetta=this.leggiRiga(reader);
					tipoPersonaggio=rigaLetta;
				}
				if(tipoPersonaggio.equals(TipiPersonaggi.Strega.toString())) {
					
					
					this.builder.getStanza(stanzaAssegnata).setPersonaggio(personaggio);
				}
			} catch (Exception e) {
				throw new FormatoFileNonValidoException("Formato file non valido [" + this.numeroLinea + "]:");
			}

		}
	}


	private String parseNome(String rigaAttrezzo) {

		return rigaAttrezzo.replaceAll("\\d", "").trim();
	}

	private int parseStringToInt(String rigaAttrezzo) {
		String supporto=rigaAttrezzo.replaceAll("[^\\d]", "");
		supporto=supporto.trim();
		return Integer.valueOf(supporto);
	}


	private String leggiRiga(BufferedReader reader) throws FormatoFileNonValidoException {
		try {
			this.numeroLinea++;
			String riga = reader.readLine();
			System.err.println("Letta riga "+ this.numeroLinea + ": "+ riga);
			return riga;
		} catch (IOException e) {
			throw new FormatoFileNonValidoException("Problemi lettura file [" + this.numeroLinea + "]");
		}
	}

	private void leggiInizialeEvincente() throws FormatoFileNonValidoException {
		String nomeStanzaIniziale=null;
		nomeStanzaIniziale= this.leggiRiga(this.reader);
		this.stanze.add(nomeStanzaIniziale);
		this.builder.addStanza(nomeStanzaIniziale);
		String nomeStanzaVincente = this.leggiRiga(reader);
		this.stanze.add(nomeStanzaVincente);
		this.builder.addStanza(nomeStanzaVincente);
		if (!this.stanzaValida(nomeStanzaVincente))
			throw new FormatoFileNonValidoException("Formato file non valido [" + this.numeroLinea + "]: stanza"+ nomeStanzaVincente+" non definita");
		String token= this.leggiRiga(reader);
		if(!token.equals(ATTREZZI))
			throw new FormatoFileNonValidoException("Formato file non valido [" + this.numeroLinea + "]:"+ATTREZZI);

	}

	private void leggiStanze() throws FormatoFileNonValidoException  {
		String nomeStanza = null;

		nomeStanza=this.leggiRiga(reader);

		if (!nomeStanza.equals(this.STANZE)) 
			throw new FormatoFileNonValidoException("Formato file non valido [" + this.numeroLinea + "]"+": "+ STANZE +" non trovato");
		nomeStanza=this.leggiRiga(reader);
		while(!nomeStanza.equals(MAGICHE)) {
			if (nomeStanza == null) 
				throw new FormatoFileNonValidoException("Termine inaspettata del file [" + this.numeroLinea + "].");
			this.builder.addStanza(nomeStanza);
			this.stanze.add(nomeStanza);
			nomeStanza=this.leggiRiga(reader);
		}
	}

	@SuppressWarnings("unused")
	private void leggiStanzeBloccate() throws FormatoFileNonValidoException  {
		String nomeStanza = null;
		String nomeAttrezzo = null;
		String direzioneBloccata = null;
		String rigaStanze = this.leggiRiga(this.reader);
		while(!rigaStanze.equals(PERSONAGGI)){
			nomeStanza=rigaStanze;
			if(nomeStanza==null)
				throw new FormatoFileNonValidoException("Termine inaspettata del file [" + this.numeroLinea + "].");
			direzioneBloccata=this.leggiRiga(reader);
			if(direzioneBloccata==null)
				throw new FormatoFileNonValidoException("Termine inaspettata del file [" + this.numeroLinea + "].");
			nomeAttrezzo=this.leggiRiga(reader);
			if(nomeAttrezzo==null)
				throw new FormatoFileNonValidoException("Termine inaspettata del file [" + this.numeroLinea + "].");
			this.builder.AddStanzaBloccata(nomeStanza, nomeAttrezzo, DirezioniValide.valueOf(direzioneBloccata.toUpperCase()));
			rigaStanze=this.leggiRiga(reader);
		}
	}
	private void leggiStanzeMagiche() throws FormatoFileNonValidoException  {
		String nomeStanza = null;

		nomeStanza=this.leggiRiga(reader);
		while(!nomeStanza.equals(this.BUIE)) {
			if (nomeStanza == null) 
				throw new FormatoFileNonValidoException("Termine inaspettata del file [" + this.numeroLinea + "].");

			this.builder.AddStanzaMagica(nomeStanza, numeroLinea);
			this.stanze.add(nomeStanza);
			nomeStanza=this.leggiRiga(reader);
		}
	}
	private void leggiStanzeBuie() throws FormatoFileNonValidoException  {
		String nomeStanza = null;
		String nomeAttrezzo=null;
		String rigaLetta=this.leggiRiga(reader);
		
		while(!rigaLetta.equals(BLOCCATE)) {
			nomeStanza=rigaLetta;
			if (nomeStanza == null) 
				throw new FormatoFileNonValidoException("Termine inaspettata del file [" + this.numeroLinea + "].");
			nomeAttrezzo=this.leggiRiga(reader);
			if (nomeAttrezzo == null) 
				throw new FormatoFileNonValidoException("Termine inaspettata del file [" + this.numeroLinea + "].");
			this.builder.AddStanzaBuia(nomeStanza,nomeAttrezzo);
			this.stanze.add(nomeStanza);
			rigaLetta=this.leggiRiga(reader);
		}
	}
	private void leggiAttrezzi() throws FormatoFileNonValidoException {
		String nomeAttrezzo = null;
		String pesoAttrezzo = null;
		String nomeStanza = null; 
		String definizioneAttrezzo=this.leggiRiga(reader);

		while (!definizioneAttrezzo.equals(USCITE)) {
			int peso;
			Scanner scannerLinea= new Scanner(definizioneAttrezzo);
			nomeAttrezzo=scannerLinea.next();
			if (nomeAttrezzo == null) 
				throw new FormatoFileNonValidoException("Termine inaspettata del file [" + this.numeroLinea + "].");
			pesoAttrezzo = scannerLinea.next();
			try {
				peso = Integer.parseInt(pesoAttrezzo);

			} catch (NumberFormatException e) {
				throw new FormatoFileNonValidoException("Peso attrezzo "+ nomeAttrezzo +" non valido [" + this.numeroLinea + "].");
			}
			nomeStanza = scannerLinea.next();
			if (!stanzaValida(nomeStanza))
				throw new FormatoFileNonValidoException("Definizione attrezzo "+ nomeAttrezzo+" errata [" + this.numeroLinea + "]" + ": stanza " + nomeStanza + " inesistente");
			posaAttrezzo(nomeStanza,nomeAttrezzo,peso);
			definizioneAttrezzo=this.leggiRiga(reader);
		}
	}

	private void posaAttrezzo(String nomeStanza,String nomeAttrezzo, int pesoAttrezzo) {
		this.builder.addAttrezzoStanza( nomeStanza, nomeAttrezzo,  pesoAttrezzo);
	}

	
	private boolean stanzaValida(String nomeStanza) {
		return this.stanze.contains(nomeStanza);
	}

	private void leggiUscite() throws FormatoFileNonValidoException {
		String nomeStanzaPartenza  =null;
		String nomeUscita = null;
		String nomeStanzaDestinazione= null;
		String datiUscita= this.leggiRiga(this.reader);
		while(datiUscita!=null) {
			Scanner scannerDiLinea=new Scanner(datiUscita);
			while(scannerDiLinea.hasNext()) {
				nomeStanzaPartenza=scannerDiLinea.next();
				nomeUscita=scannerDiLinea.next();
				nomeStanzaDestinazione=scannerDiLinea.next();
				if(!stanzaValida(nomeStanzaPartenza))
					throw new FormatoFileNonValidoException("Definizione errata uscita [" + this.numeroLinea + "]" + nomeUscita);
				if(!stanzaValida(nomeStanzaDestinazione))
					throw new FormatoFileNonValidoException("Definizione errata uscita [" + this.numeroLinea + "]" + nomeUscita);
				impostaUscita(nomeUscita,nomeStanzaPartenza,nomeStanzaDestinazione);
			}
			datiUscita=this.leggiRiga(reader);
		}

	}
	private void impostaUscita(String nomeUscita, String nomeStanzaPartenza, String nomeStanzaDestinazione) {
		this.builder.addAdiacenza(nomeStanzaPartenza, nomeStanzaDestinazione, DirezioniValide.valueOf(nomeUscita.toUpperCase()));

	}

	public Labirinto getLabirinto() {
		this.builder.setStanzaIniziale();
		this.builder.setStanzaVincenteBuilder();
		return this.builder.GetLabirinto();
	}
}
